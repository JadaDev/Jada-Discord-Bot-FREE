import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone

class UserInfoCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="userinfo", description="Get information about a user")
    @app_commands.describe(member="The member to get information about (defaults to yourself)")
    async def userinfo_command(self, interaction: discord.Interaction, member: discord.Member = None):
        """
        Display detailed information about a user
        """
        try:
            if member is None:
                member = interaction.user
            
            # Calculate account age
            account_created = member.created_at
            account_age = datetime.now(timezone.utc) - account_created
            
            # Calculate join date
            joined_at = member.joined_at
            join_age = datetime.now(timezone.utc) - joined_at if joined_at else None
            
            # Create main embed
            embed = discord.Embed(
                title=f"User Information - {member.display_name}",
                color=member.color if member.color != discord.Color.default() else discord.Color.blue(),
                timestamp=interaction.created_at
            )
            
            # Set thumbnail to user's avatar
            embed.set_thumbnail(url=member.display_avatar.url)
            
            # Basic information
            embed.add_field(name="👤 Username", value=f"{member.name}#{member.discriminator}", inline=True)
            embed.add_field(name="🆔 User ID", value=member.id, inline=True)
            embed.add_field(name="📱 Mention", value=member.mention, inline=True)
            
            # Account creation date
            embed.add_field(
                name="📅 Account Created", 
                value=f"{account_created.strftime('%B %d, %Y')}\n({account_age.days} days ago)", 
                inline=True
            )
            
            # Server join date
            if joined_at:
                embed.add_field(
                    name="🏠 Joined Server", 
                    value=f"{joined_at.strftime('%B %d, %Y')}\n({join_age.days} days ago)", 
                    inline=True
                )
            else:
                embed.add_field(name="🏠 Joined Server", value="Unknown", inline=True)
            
            # Status
            status_emoji = {
                'online': '🟢',
                'idle': '🟡',
                'dnd': '🔴',
                'offline': '⚫'
            }
            embed.add_field(
                name="📶 Status", 
                value=f"{status_emoji.get(str(member.status), '❓')} {str(member.status).title()}", 
                inline=True
            )
            
            # Roles (limit to prevent embed from being too long)
            roles = [role.mention for role in member.roles[1:]]  # Exclude @everyone
            if roles:
                roles_text = ", ".join(roles[:10])  # Limit to first 10 roles
                if len(member.roles) > 11:
                    roles_text += f" ... (+{len(member.roles) - 11} more)"
                embed.add_field(name=f"🏷️ Roles ({len(member.roles) - 1})", value=roles_text, inline=False)
            else:
                embed.add_field(name="🏷️ Roles", value="None", inline=False)
            
            # Permissions (show key permissions only)
            perms = member.guild_permissions
            key_perms = []
            
            if perms.administrator:
                key_perms.append("Administrator")
            else:
                if perms.manage_guild:
                    key_perms.append("Manage Server")
                if perms.manage_channels:
                    key_perms.append("Manage Channels")
                if perms.manage_messages:
                    key_perms.append("Manage Messages")
                if perms.kick_members:
                    key_perms.append("Kick Members")
                if perms.ban_members:
                    key_perms.append("Ban Members")
                if perms.manage_roles:
                    key_perms.append("Manage Roles")
            
            if key_perms:
                embed.add_field(name="🔑 Key Permissions", value=", ".join(key_perms), inline=False)
            
            # Activity/Custom Status
            if member.activities:
                activity = member.activities[0]  # Get first activity
                activity_text = ""
                
                if isinstance(activity, discord.Game):
                    activity_text = f"🎮 Playing {activity.name}"
                elif isinstance(activity, discord.Streaming):
                    activity_text = f"📺 Streaming {activity.name}"
                elif isinstance(activity, discord.Listening):
                    activity_text = f"🎵 Listening to {activity.name}"
                elif isinstance(activity, discord.Watching):
                    activity_text = f"👀 Watching {activity.name}"
                elif isinstance(activity, discord.CustomActivity):
                    activity_text = f"💭 {activity.name}" if activity.name else "Custom Status"
                
                if activity_text:
                    embed.add_field(name="🎯 Activity", value=activity_text, inline=False)
            
            # Boosting information
            if member.premium_since:
                embed.add_field(
                    name="💎 Nitro Boost",
                    value=f"Since {member.premium_since.strftime('%B %d, %Y')}",
                    inline=True
                )
            
            # Avatar URL for easy access
            if member.avatar:
                embed.add_field(name="🖼️ Avatar URL", value=f"[Click Here]({member.display_avatar.url})", inline=True)
            
            # Fetch and show banner if exists
            banner = None
            try:
                banner = await member.fetch_banner()
            except:
                pass
            
            if banner:
                embed.set_image(url=banner.url)
            
            embed.set_footer(
                text='Made by JadaDev • Userinfo',
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(UserInfoCommand(bot))
    print('Loaded userinfo command')
