import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional
import random

class JokeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

        # A collection of dad jokes
        self.jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "Why did the scarecrow win an award? Because he was outstanding in his field!",
            "Why don't eggs tell jokes? They'd crack each other up!",
            "What do you call fake spaghetti? An impasta!",
            "Why can't you give Elsa a balloon? Because she will let it go!",
            "Why did the golfer bring two pairs of pants? In case he got a hole in one!",
            "Why did the math book look sad? Because of all its problems!",
            "What do you call a dinosaur with an extensive vocabulary? A thesaurus!",
            "Why did the bicycle fall over? It was two-tired!",
            "What did the grape say when it got stepped on? Nothing, it just let out a little wine!",
            "Why don't skeletons fight each other? They don't have the guts!",
            "What do you call a bear with no teeth? A gummy bear!",
            "Why did the tomato turn red? Because it saw the salad dressing!",
            "How do you organize a space party? You planet!",
            "Why was the broom late? It over-swept!",
            "What do you call cheese that isn't yours? Nacho cheese!",
            "Why did the computer go to the doctor? Because it had a virus!",
            "What did the buffalo say when his son left for college? Bison!",
            "Why did the coffee file a police report? It got mugged!",
            "What do you call a fish wearing a bowtie? Sofishticated!"
        ]

    @app_commands.command(name="joke", description="Get a random dad joke")
    async def joke_command(self, interaction: discord.Interaction):
        """
        Send a random dad joke
        """
        try:
            # Get a random joke
            joke = random.choice(self.jokes)

            # Create embed
            embed = discord.Embed(
                title="😄 Dad Joke",
                description=joke,
                color=discord.Color.gold(),
                timestamp=interaction.created_at
            )

            embed.set_footer(
                text=f"Made by JadaDev • Joke #{random.randint(1, 10000)} • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(JokeCommand(bot))
    print('Loaded joke command')
