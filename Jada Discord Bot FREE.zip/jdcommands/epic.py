import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
from datetime import datetime, timezone

class EpicCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    epic_group = app_commands.Group(name="epic", description="Epic Games Store free games commands")

    @epic_group.command(
        name="all", description="Get all free games (both current and upcoming)"
    )
    async def epic_all(self, interaction: discord.Interaction):
        await self._fetch_epic_games(interaction, filter_type="all")

    @epic_group.command(
        name="now", description="Get games that are free right now"
    )
    async def epic_now(self, interaction: discord.Interaction):
        await self._fetch_epic_games(interaction, filter_type="now")

    @epic_group.command(
        name="upcoming", description="Get games that will be free soon"
    )
    async def epic_upcoming(self, interaction: discord.Interaction):
        await self._fetch_epic_games(interaction, filter_type="upcoming")

    async def _fetch_epic_games(self, interaction: discord.Interaction, filter_type: str = "all"):
        try:
            await interaction.response.defer()  # Defer to allow processing

            async with aiohttp.ClientSession() as session:
                url = "https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions"
                headers = {
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/91.0.4472.124 Safari/537.36"
                    )
                }

                async with session.get(url, headers=headers) as resp:
                    if resp.status != 200:
                        await interaction.followup.send(
                            "❌ Could not fetch Epic Games data!", ephemeral=True
                        )
                        return
                    data = await resp.json()

            free_games = []
            elements = data.get("data", {}).get("Catalog", {}).get("searchStore", {}).get("elements", [])
            now = datetime.now(timezone.utc)

            for game in elements:
                # Skip if no title
                if not game.get("title"):
                    continue

                promotions = game.get("promotions")
                if not promotions:
                    continue

                # Check both current and upcoming promotional offers
                promotional_offers = promotions.get("promotionalOffers", [])
                upcoming_offers = promotions.get("upcomingPromotionalOffers", [])

                current_free = False
                upcoming_free = False
                end_date = None
                start_date = None

                # Check current offers
                for offer_group in promotional_offers:
                    for offer in offer_group.get("promotionalOffers", []):
                        discount_pct = offer.get("discountSetting", {}).get("discountPercentage", 0)
                        if discount_pct == 0:  # Free game
                            current_free = True
                            end_date_str = offer.get("endDate")
                            if end_date_str:
                                end_date = datetime.fromisoformat(end_date_str.replace("Z", "+00:00"))

                # Check upcoming offers
                for offer_group in upcoming_offers:
                    for offer in offer_group.get("promotionalOffers", []):
                        discount_pct = offer.get("discountSetting", {}).get("discountPercentage", 0)
                        if discount_pct == 0:  # Free game
                            upcoming_free = True
                            start_date_str = offer.get("startDate")
                            end_date_str = offer.get("endDate")
                            if start_date_str:
                                start_date = datetime.fromisoformat(start_date_str.replace("Z", "+00:00"))
                            if end_date_str:
                                end_date = datetime.fromisoformat(end_date_str.replace("Z", "+00:00"))

                # Skip if not free
                if not current_free and not upcoming_free:
                    continue

                # Determine status
                if current_free and (not end_date or now <= end_date):
                    status = "✅ Free Now"
                elif upcoming_free and start_date and now < start_date:
                    status = "🕑 Coming Soon"
                else:
                    continue

                # Apply filter based on subcommand
                if filter_type == "now" and status != "✅ Free Now":
                    continue
                elif filter_type == "upcoming" and status != "🕑 Coming Soon":
                    continue

                # Extract price information
                price_info = game.get("price", {}).get("totalPrice", {})
                original_price_cents = price_info.get("originalPrice", 0)
                discount_price_cents = price_info.get("discountPrice", 0)

                original_price = f"${original_price_cents / 100:.2f}" if original_price_cents else "Free"
                current_price = f"${discount_price_cents / 100:.2f}" if discount_price_cents else "Free"

                # Get thumbnail image
                thumb_url = None
                key_images = game.get("keyImages", [])
                
                # Priority order for images
                image_priorities = ["Thumbnail", "OfferImageWide", "DieselStoreFrontWide", "featuredMedia"]
                
                for priority_type in image_priorities:
                    for img in key_images:
                        if img.get("type") == priority_type:
                            thumb_url = img.get("url")
                            break
                    if thumb_url:
                        break
                
                # Fallback to first available image
                if not thumb_url and key_images:
                    thumb_url = key_images[0].get("url")

                # Extract developer/publisher from custom attributes
                custom_attrs = {}
                for attr in game.get('customAttributes', []):
                    if attr.get('key') and attr.get('value'):
                        custom_attrs[attr['key']] = attr['value']

                developer = custom_attrs.get('developerName')
                publisher = custom_attrs.get('publisherName')

                # Extract categories/genres
                categories_list = []
                for category in game.get('categories', []):
                    if category.get('path'):
                        # Clean up category names
                        cat_name = category['path'].split('/')[-1].replace('_', ' ').title()
                        categories_list.append(cat_name)

                categories = ", ".join(categories_list[:3]) if categories_list else None  # Limit to 3 categories

                # Game description (truncate if too long)
                description = game.get("description", "")
                if len(description) > 300:
                    description = description[:300] + "..."

                # Game URL
                product_slug = game.get("catalogNs", {}).get("mappings", [])
                game_url = None
                
                if product_slug:
                    # Try to get the slug from mappings
                    for mapping in product_slug:
                        if mapping.get("pageSlug"):
                            game_url = f"https://www.epicgames.com/store/en-US/p/{mapping['pageSlug']}"
                            break
                        elif mapping.get("pageType") == "productHome":
                            slug = game.get('productSlug', '')
                            if slug:
                                game_url = f"https://www.epicgames.com/store/en-US/p/{slug}"
                            break

                # If no URL found, try productSlug directly
                if not game_url and game.get("productSlug"):
                    slug = game['productSlug']
                    game_url = f"https://www.epicgames.com/store/en-US/p/{slug}"

                # Format end date
                end_str = None
                if end_date:
                    end_str = end_date.strftime("%B %d, %Y at %I:%M %p UTC")
                elif start_date and status == "🕑 Coming Soon":
                    end_str = start_date.strftime("%B %d, %Y at %I:%M %p UTC")

                free_games.append({
                    "title": game.get("title"),
                    "thumb": thumb_url,
                    "original_price": original_price,
                    "current_price": current_price,
                    "developer": developer,
                    "publisher": publisher,
                    "categories": categories,
                    "description": description,
                    "end_date": end_str,
                    "url": game_url,
                    "status": status
                })

            if not free_games:
                if filter_type == "now":
                    await interaction.followup.send("❓ No games are free right now. Check back later!")
                elif filter_type == "upcoming":
                    await interaction.followup.send("❓ No upcoming free games found. Check back later!")
                else:
                    await interaction.followup.send("❓ No free games available right now. Check back later!")
                return

            # Create initial response with filter-specific message
            embed_count = len(free_games[:5])  # Limit to 5 games to avoid spam
            
            if filter_type == "now":
                title_msg = f"🎮 **Found {embed_count} game{'s' if embed_count != 1 else ''} free RIGHT NOW on Epic Games Store!**"
            elif filter_type == "upcoming":
                title_msg = f"🕑 **Found {embed_count} upcoming free game{'s' if embed_count != 1 else ''} on Epic Games Store!**"
            else:
                title_msg = f"🎮 **Found {embed_count} free game{'s' if embed_count != 1 else ''} on Epic Games Store!**"
            
            await interaction.followup.send(title_msg)

            # Send each game as its own embed
            for i, game in enumerate(free_games[:5]):
                desc_lines = []
                
                # Add description if available
                if game["description"]:
                    desc_lines.append(f"📝 {game['description']}")
                    desc_lines.append("")  # Empty line for spacing

                # Status and price
                desc_lines.append(f"{game['status']}")
                if game['current_price'] != game['original_price']:
                    desc_lines.append(f"💰 **Free** (Originally: {game['original_price']})")
                else:
                    desc_lines.append(f"💰 **Free**")
                
                # Developer and publisher
                if game["developer"]:
                    desc_lines.append(f"👨‍💻 **Developer:** {game['developer']}")
                if game["publisher"] and game["publisher"] != game["developer"]:
                    desc_lines.append(f"🏢 **Publisher:** {game['publisher']}")
                
                # Categories
                if game["categories"]:
                    desc_lines.append(f"🎯 **Genres:** {game['categories']}")
                
                # End date
                if game["end_date"]:
                    if game["status"] == "✅ Free Now":
                        desc_lines.append(f"⏰ **Ends:** {game['end_date']}")
                    elif game["status"] == "🕑 Coming Soon":
                        desc_lines.append(f"🕑 **Starts:** {game['end_date']}")

                # Create embed
                embed = discord.Embed(
                    title=f"🎮 {game['title']}",
                    url=game["url"] if game["url"] else None,
                    color=discord.Color.from_rgb(0, 188, 212),  # Epic Games blue
                    description="\n".join(desc_lines),
                    timestamp=datetime.now(timezone.utc)
                )

                # Set thumbnail
                if game["thumb"]:
                    embed.set_image(url=game["thumb"])

                # Create button for game website link
                view = None
                if game["url"]:
                    view = discord.ui.View(timeout=None)
                    website_button = discord.ui.Button(
                        style=discord.ButtonStyle.link,
                        label="🎮 Get Game on Epic Store",
                        url=game["url"]
                    )
                    view.add_item(website_button)
                    
                    # Add instruction for Epic Games Launcher users
                    embed.add_field(
                        name="💡 Pro Tip",
                        value="Click the button above to open in browser, then click 'Get' to open in Epic Games Launcher!",
                        inline=False
                    )

                # Footer
                embed.set_footer(
                    text="Made by JadaDev • Data from Epic Games Store",
                    icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s"
                )

                # Send with button
                await interaction.channel.send(embed=embed, view=view)

        except Exception as e:
            print(f"Error in epic command: {e}")  # For debugging
            await interaction.followup.send(
                f"❌ An error occurred while fetching Epic Games data. Please try again later."
            )


async def setup(bot):
    await bot.add_cog(EpicCommand(bot))
    print("Loaded epic command with subcommands")
