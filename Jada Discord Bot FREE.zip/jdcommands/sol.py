import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json
from datetime import datetime

class SolCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="sol", description="Get detailed information about a Solana wallet")
    @app_commands.describe(wallet="The Solana wallet address to look up")
    async def sol_command(self, interaction: discord.Interaction, wallet: str):
        """
        Get detailed information about a Solana wallet
        """
        await interaction.response.defer()  # Allow for longer processing time
        
        try:
            url = "https://api.mainnet-beta.solana.com"
            headers = {"Content-Type": "application/json"}
            
            # Multiple API calls for comprehensive data
            async with aiohttp.ClientSession() as session:
                # Get balance
                balance_payload = {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "getBalance",
                    "params": [wallet]
                }
                
                # Get account info
                account_payload = {
                    "jsonrpc": "2.0",
                    "id": 2,
                    "method": "getAccountInfo",
                    "params": [
                        wallet,
                        {"encoding": "base64", "commitment": "confirmed"}
                    ]
                }
                
                # Get transaction signatures (recent activity)
                signatures_payload = {
                    "jsonrpc": "2.0",
                    "id": 3,
                    "method": "getSignaturesForAddress",
                    "params": [
                        wallet,
                        {"limit": 10}
                    ]
                }
                
                # Get token accounts
                token_payload = {
                    "jsonrpc": "2.0",
                    "id": 4,
                    "method": "getTokenAccountsByOwner",
                    "params": [
                        wallet,
                        {"programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"},
                        {"encoding": "jsonParsed"}
                    ]
                }
                
                # Execute all requests
                balance_resp = await session.post(url, json=balance_payload, headers=headers)
                account_resp = await session.post(url, json=account_payload, headers=headers)
                signatures_resp = await session.post(url, json=signatures_payload, headers=headers)
                token_resp = await session.post(url, json=token_payload, headers=headers)
                
                balance_data = await balance_resp.json()
                account_data = await account_resp.json()
                signatures_data = await signatures_resp.json()
                token_data = await token_resp.json()
            
            # Process balance data
            if "result" not in balance_data:
                await interaction.followup.send("❌ Could not fetch wallet data. Invalid wallet address.", ephemeral=True)
                return
                
            lamports = balance_data["result"]["value"]
            sol_balance = lamports / 1_000_000_000  # 1 SOL = 1e9 lamports
            
            # Process account info
            account_info = account_data.get("result", {}).get("value")
            account_exists = account_info is not None
            
            # Get rent exempt minimum
            rent_payload = {
                "jsonrpc": "2.0",
                "id": 5,
                "method": "getMinimumBalanceForRentExemption",
                "params": [0]
            }
            async with aiohttp.ClientSession() as session:
                rent_resp = await session.post(url, json=rent_payload, headers=headers)
                rent_data = await rent_resp.json()
            
            rent_exempt_min = rent_data.get("result", 0) / 1_000_000_000
            
            # Process transaction signatures
            signatures = signatures_data.get("result", [])
            transaction_count = len(signatures)
            
            # Process token accounts
            token_accounts = token_data.get("result", {}).get("value", [])
            
            # Create embed
            embed = discord.Embed(
                title="🌟 Solana Wallet Information",
                color=0x9945FF,  # Solana purple
                timestamp=datetime.utcnow()
            )
            
            # Wallet basic info
            embed.add_field(
                name="📜 Wallet Address",
                value=f"```{wallet[:8]}...{wallet[-8:]}```",
                inline=False
            )
            
            # Balance information
            balance_text = f"**{sol_balance:.6f} SOL**\n"
            balance_text += f"*({lamports:,} lamports)*\n"
            if sol_balance < rent_exempt_min:
                balance_text += f"⚠️ Below rent-exempt minimum ({rent_exempt_min:.6f} SOL)"
            else:
                balance_text += f"✅ Above rent-exempt minimum"
                
            embed.add_field(
                name="💰 SOL Balance",
                value=balance_text,
                inline=True
            )
            
            # Account status
            status_text = "✅ Active" if account_exists else "❌ Not created"
            if account_exists and account_info:
                owner = account_info.get("owner", "Unknown")
                executable = account_info.get("executable", False)
                data_size = len(account_info.get("data", [""]))
                
                status_text += f"\n**Owner:** {owner[:8]}...{owner[-8:]}" if len(owner) > 16 else f"\n**Owner:** {owner}"
                status_text += f"\n**Executable:** {'Yes' if executable else 'No'}"
                status_text += f"\n**Data Size:** {data_size} bytes"
            
            embed.add_field(
                name="🔍 Account Status",
                value=status_text,
                inline=True
            )
            
            # Recent activity
            if signatures:
                latest_tx = signatures[0]
                latest_time = datetime.fromtimestamp(latest_tx.get("blockTime", 0))
                activity_text = f"**Last Transaction:**\n{latest_time.strftime('%Y-%m-%d %H:%M UTC')}\n"
                activity_text += f"**Recent Transactions:** {transaction_count}/10\n"
                
                # Check for errors in recent transactions
                error_count = sum(1 for sig in signatures if sig.get("err") is not None)
                if error_count > 0:
                    activity_text += f"⚠️ {error_count} failed transactions"
                else:
                    activity_text += "✅ No recent failures"
            else:
                activity_text = "No recent transactions found"
                
            embed.add_field(
                name="📈 Recent Activity",
                value=activity_text,
                inline=True
            )
            
            # Token holdings
            if token_accounts:
                token_text = f"**Total Token Accounts:** {len(token_accounts)}\n"
                
                # Show top 5 token balances
                token_balances = []
                for account in token_accounts[:5]:
                    account_data = account.get("account", {}).get("data", {}).get("parsed", {}).get("info", {})
                    token_amount = account_data.get("tokenAmount", {})
                    mint = account_data.get("mint", "Unknown")
                    ui_amount = token_amount.get("uiAmount", 0)
                    
                    if ui_amount and ui_amount > 0:
                        token_balances.append(f"• {mint[:8]}...{mint[-8:]}: {ui_amount}")
                
                if token_balances:
                    token_text += "\n**Top Holdings:**\n" + "\n".join(token_balances[:3])
                else:
                    token_text += "\n*No tokens with balance found*"
            else:
                token_text = "No token accounts found"
                
            embed.add_field(
                name="🪙 Token Information",
                value=token_text,
                inline=True
            )
            
            # Network info
            network_text = "**Network:** Mainnet Beta\n"
            network_text += f"**Rent Exempt Min:** {rent_exempt_min:.6f} SOL\n"
            network_text += f"**Query Time:** {datetime.utcnow().strftime('%H:%M:%S UTC')}"
            
            embed.add_field(
                name="🌐 Network Info",
                value=network_text,
                inline=True
            )
            
            # Wallet health score
            health_score = 100
            health_reasons = []
            
            if sol_balance < rent_exempt_min:
                health_score -= 30
                health_reasons.append("Below rent-exempt minimum")
            
            if not account_exists:
                health_score -= 20
                health_reasons.append("Account not created")
                
            if transaction_count == 0:
                health_score -= 15
                health_reasons.append("No recent activity")
                
            error_count = sum(1 for sig in signatures if sig.get("err") is not None) if signatures else 0
            if error_count > 3:
                health_score -= 25
                health_reasons.append("High transaction failure rate")
            
            health_color = "🟢" if health_score >= 80 else "🟡" if health_score >= 60 else "🔴"
            health_text = f"{health_color} **{health_score}/100**"
            if health_reasons:
                health_text += f"\n*Issues: {', '.join(health_reasons)}*"
            
            embed.add_field(
                name="💊 Wallet Health",
                value=health_text,
                inline=True
            )
            
            # Footer with additional info
            embed.set_footer(
                text=f"Solana Mainnet Beta • Requested by {interaction.user.display_name}",
                icon_url="https://cryptologos.cc/logos/solana-sol-logo.png"
            )
            
            await interaction.followup.send(embed=embed)
            
        except json.JSONDecodeError:
            await interaction.followup.send("❌ Invalid response from Solana API.", ephemeral=True)
        except aiohttp.ClientError:
            await interaction.followup.send("❌ Network error while fetching data.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Unexpected error: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(SolCommand(bot))
    print('Loaded Sol command')