import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional, List
import random
import asyncio

class TriviaCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_games = {}  # Store active trivia games

        # Trivia questions database
        self.questions = [
            {
                "question": "What is the capital of France?",
                "answers": ["Paris", "London", "Berlin", "Madrid"],
                "correct": 0,
                "category": "Geography"
            },
            {
                "question": "Who painted the Mona Lisa?",
                "answers": ["Leonardo da Vinci", "Pablo Picasso", "Vincent van Gogh", "Michelangelo"],
                "correct": 0,
                "category": "Art"
            },
            {
                "question": "What is the largest planet in our solar system?",
                "answers": ["Jupiter", "Saturn", "Mars", "Earth"],
                "correct": 0,
                "category": "Science"
            },
            {
                "question": "Which programming language is named after a snake?",
                "answers": ["Python", "Java", "Cobra", "Anaconda"],
                "correct": 0,
                "category": "Programming"
            },
            {
                "question": "What was the first video game console?",
                "answers": ["Magnavox Odyssey", "Atari 2600", "Nintendo NES", "Sega Genesis"],
                "correct": 0,
                "category": "Gaming"
            },
            {
                "question": "Who wrote Romeo and Juliet?",
                "answers": ["William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain"],
                "correct": 0,
                "category": "Literature"
            },
            {
                "question": "What is the chemical symbol for gold?",
                "answers": ["Au", "Ag", "Fe", "Cu"],
                "correct": 0,
                "category": "Science"
            },
            {
                "question": "Which continent is known as the 'Dark Continent'?",
                "answers": ["Africa", "Asia", "South America", "Australia"],
                "correct": 0,
                "category": "Geography"
            },
            {
                "question": "What is the most visited tourist attraction in the world?",
                "answers": ["Great Wall of China", "Eiffel Tower", "Machu Picchu", "Pyramids of Giza"],
                "correct": 0,
                "category": "History"
            },
            {
                "question": "Which company created the iPhone?",
                "answers": ["Apple", "Samsung", "Google", "Microsoft"],
                "correct": 0,
                "category": "Technology"
            }
        ]

    @app_commands.command(name="trivia", description="Start a trivia game with reactions")
    @app_commands.describe(category="Question category (optional)")
    async def trivia_command(self, interaction: discord.Interaction, category: Optional[str] = None):
        """
        Interactive trivia game using Discord reactions
        """
        await interaction.response.defer()
        try:
            user_id = interaction.user.id
            guild_id = interaction.guild.id if interaction.guild else "dm"
            game_key = f"{guild_id}_{user_id}"

            # Start new trivia game
            await self._start_trivia(interaction, game_key, category)

        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)}", ephemeral=True)

    @app_commands.command(name="trivias", description="Trivia game commands")
    @app_commands.describe(action="skip, end")
    async def trivia_secondary_command(self, interaction: discord.Interaction, action: str):
        """
        Secondary trivia commands for skip/end
        """
        await interaction.response.defer()
        try:
            user_id = interaction.user.id
            guild_id = interaction.guild.id if interaction.guild else "dm"
            game_key = f"{guild_id}_{user_id}"

            action = action.lower().strip()

            if action == "skip" or action == "s":
                await self._skip_question(interaction, game_key)

            elif action == "end" or action == "stop":
                await self._end_game(interaction, game_key)

            else:
                await interaction.followup.send("❌ Invalid action! Use: skip or end", ephemeral=True)

        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)}", ephemeral=True)

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        """Handle reaction answers for trivia games"""
        # Only process if not from the bot
        if payload.user_id == self.bot.user.id:
            return

        # Check if this reaction is on a trivia question
        emoji = payload.emoji.name
        reaction_mapping = {'🇦': 'a', '🇧': 'b', '🇨': 'c', '🇩': 'd'}

        if emoji not in reaction_mapping:
            return

        # Find the game for this channel/message
        for game_key, game_data in self.active_games.items():
            if (game_data.get('message_id') == payload.message_id and
                game_data.get('channel_id') == payload.channel_id and
                f"{payload.guild_id or 'dm'}_{payload.user_id}" == game_key):

                # Process the reaction as an answer
                user_choice = reaction_mapping[emoji]
                await self._process_reaction_answer(payload, game_key, user_choice)
                break

    async def _start_trivia(self, interaction: discord.Interaction, game_key: str, category: Optional[str] = None):
        """Start a new trivia game"""

        # End any existing game
        if game_key in self.active_games:
            await self._end_game(interaction, game_key, silent=True)

        # Get questions by category
        available_questions = self.questions
        if category:
            category = category.lower().strip()
            available_questions = [q for q in self.questions if category in q['category'].lower()]

        if len(available_questions) < 3:
            available_questions = self.questions  # Fallback to all questions

        # Initialize game
        self.active_games[game_key] = {
            'questions': random.sample(available_questions, min(len(available_questions), 10)),
            'current_index': 0,
            'score': 0,
            'user': interaction.user,
            'channel': interaction.channel,
            'last_score_time': discord.utils.utcnow()
        }

        await self._send_question(interaction, game_key)

    async def _send_question(self, interaction: discord.Interaction, game_key: str):
        """Send the next question with reaction options"""
        if game_key not in self.active_games:
            await interaction.followup.send("❌ No active trivia game!", ephemeral=True)
            return

        game = self.active_games[game_key]
        if game['current_index'] >= len(game['questions']):
            await self._end_game(interaction, game_key)
            return

        question = game['questions'][game['current_index']]

        embed = discord.Embed(
            title="❓ Trivia Question",
            description=f"{question['question']}\n\n⚠️ **Click the letter reaction below to answer!** ⚠️",
            color=discord.Color.blue(),
            timestamp=interaction.created_at
        )

        # Display answer options
        option_emojis = ['🇦', '🇧', '🇨', '🇩']
        for i, option in enumerate(question['answers']):
            embed.add_field(
                name=f"{option_emojis[i]} {chr(65+i)})",  # 🇦 A), 🇧 B), etc.
                value=f"**{option}**",
                inline=False
            )

        embed.set_footer(
            text=f"Made by JadaDev • Trivia • Score: {game['score']} • Question {game['current_index']+1}/{len(game['questions'])} • Category: {question['category']}",
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        # Send message and store for reaction handling
        message = await interaction.followup.send(embed=embed, wait=True)

        # Store message ID in game session
        game['message_id'] = message.id
        game['channel_id'] = message.channel.id

        # Add reactions for answers
        for emoji in option_emojis:
            await message.add_reaction(emoji)

    async def _answer_question(self, interaction: discord.Interaction, game_key: str, user_answer: str):
        """Check user's answer"""
        if game_key not in self.active_games:
            await interaction.followup.send("❌ No active trivia game!", ephemeral=True)
            return

        game = self.active_games[game_key]
        question = game['questions'][game['current_index']]

        # Check answer format
        user_answer = user_answer.lower().strip()

        # Accept both letter (a, b, c, d) and position (1, 2, 3, 4)
        try:
            if user_answer in ['a', 'b', 'c', 'd']:
                answer_index = ord(user_answer) - ord('a')
            elif user_answer in ['1', '2', '3', '4']:
                answer_index = int(user_answer) - 1
            else:
                # Try to match full answer text
                for i, answer in enumerate(question['answers']):
                    if user_answer.lower() in answer.lower() or answer.lower() in user_answer.lower():
                        answer_index = i
                        break
                else:
                    answer_index = -1

            # Check if answer is correct
            if answer_index == question['correct']:
                game['score'] += 10
                color = discord.Color.green()
                result = "✅ Correct!"
            else:
                color = discord.Color.red()
                result = f"❌ Wrong! The correct answer was **{question['answers'][question['correct']]}**"

        except (ValueError, IndexError):
            result = "❌ Invalid answer format! Use A/B/C/D or 1/2/3/4"
            color = discord.Color.red()

        # Move to next question after 3 seconds
        game['current_index'] += 1

        embed = discord.Embed(
            title=result,
            color=color,
            timestamp=interaction.created_at
        )

        embed.add_field(name="Question", value=question['question'], inline=False)

        if color == discord.Color.green():
            embed.add_field(name="Current Score", value=f"**{game['score']} points**", inline=False)

        embed.set_footer(
            text='Made by JadaDev • Trivia',
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        await interaction.followup.send(embed=embed)

        # Auto-send next question after a brief delay
        await asyncio.sleep(2)
        await self._send_question(interaction, game_key)

    async def _process_reaction_answer(self, payload, game_key: str, user_choice: str):
        """Process reaction-based answers"""
        if game_key not in self.active_games:
            return

        game = self.active_games[game_key]
        question = game['questions'][game['current_index']]

        # Convert reaction choice to answer index
        try:
            answer_index = ord(user_choice) - ord('a')

            # Check if answer is correct
            if answer_index == question['correct']:
                game['score'] += 10
                result = "✅ Correct!"
                emoji = "🎉"
            else:
                result = f"❌ Wrong! The correct answer was **{question['answers'][question['correct']]}**"
                emoji = "😢"

        except (ValueError, IndexError):
            result = "❌ Invalid choice!"
            emoji = "❓"

        # Move to next question
        game['current_index'] += 1

        # Create channel object to send response
        try:
            channel = await self.bot.fetch_channel(payload.channel_id)
            if channel:
                embed = discord.Embed(
                    title=f"{emoji} {result}",
                    description=f"**Question**: {question['question']}\n**Your Score**: {game['score']} points",
                    color=discord.Color.green() if game['score'] > game['score']-10 else discord.Color.red(),
                    timestamp=discord.utils.utcnow()
                )

                embed.set_footer(
                    text='Made by JadaDev • Trivia',
                    icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
                )

                await channel.send(embed=embed)

                # Continue with next question after delay
                await asyncio.sleep(3)
                await self._send_question_via_channel(game, channel)
        except Exception as e:
            print(f"Error processing reaction: {e}")

    async def _send_question_via_channel(self, game, channel):
        """Send next question to channel (for reaction-based games)"""
        game_key = list(self.active_games.keys())[list(self.active_games.values()).index(game)]

        if game['current_index'] >= len(game['questions']):
            await self._end_game_via_channel(game, channel)
            return

        question = game['questions'][game['current_index']]

        embed = discord.Embed(
            title="❓ Trivia Question",
            description=f"{question['question']}\n\n⚠️ **Click the letter reaction below to answer!** ⚠️",
            color=discord.Color.blue(),
            timestamp=discord.utils.utcnow()
        )

        # Display answer options with emoji flags
        option_emojis = ['🇦', '🇧', '🇨', '🇩']
        for i, option in enumerate(question['answers']):
            embed.add_field(
                name=f"{option_emojis[i]} {chr(65+i)})",
                value=f"**{option}**",
                inline=False
            )

        embed.set_footer(
            text=f"Made by JadaDev • Trivia • Score: {game['score']} • Question {game['current_index']+1}/{len(game['questions'])} • Category: {question['category']}",
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        # Send message and add reactions
        try:
            message = await channel.send(embed=embed)

            # Update game with new message info
            game['message_id'] = message.id
            game['channel_id'] = channel.id

            # Add reactions for answers
            for emoji in option_emojis:
                await message.add_reaction(emoji)
        except Exception as e:
            print(f"Error sending question via channel: {e}")

    async def _end_game_via_channel(self, game, channel):
        """End the trivia game via channel message"""
        score = game['score']
        total_questions = len(game['questions'])

        embed = discord.Embed(
            title="🏁 Trivia Game Ended",
            description=f"Final Score: **{score}/{total_questions}** points",
            color=discord.Color.purple(),
            timestamp=discord.utils.utcnow()
        )

        embed.add_field(
            name="Percentage",
            value=f"{(score / total_questions) * 100:.2f}%" if total_questions > 0 else "0.00%",
            inline=True
        )

        embed.set_footer(
            text=f"Made by JadaDev • Trivia • Game for {game['user'].display_name}",
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        try:
            await channel.send(embed=embed)
        except Exception as e:
            print(f"Error sending game end: {e}")

        # Remove this game from active games
        game_key = list(self.active_games.keys())[list(self.active_games.values()).index(game)]
        if game_key in self.active_games:
            del self.active_games[game_key]

    async def _skip_question(self, interaction: discord.Interaction, game_key: str):
        """Skip current question"""
        if game_key not in self.active_games:
            await interaction.followup.send("❌ No active trivia game!", ephemeral=True)
            return

        game = self.active_games[game_key]
        question = game['questions'][game['current_index']]

        embed = discord.Embed(
            title="🚶 Question Skipped",
            description=f"The correct answer was **{question['answers'][question['correct']]}**",
            color=discord.Color.orange(),
            timestamp=interaction.created_at
        )

        embed.set_footer(
            text='Made by JadaDev • Trivia',
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        game['current_index'] += 1

        await interaction.followup.send(embed=embed)

        # Continue with next question
        await asyncio.sleep(1)
        await self._send_question(interaction, game_key)

    async def _end_game(self, interaction: discord.Interaction, game_key: str, silent: bool = False):
        """End the trivia game"""
        if game_key not in self.active_games:
            if not silent:
                await interaction.followup.send("❌ No active trivia game!", ephemeral=True)
            return

        game = self.active_games[game_key]
        score = game['score']
        total_questions = len(game['questions'])

        embed = discord.Embed(
            title="🏁 Trivia Game Ended",
            description=f"Final Score: **{score}/{total_questions}** points",
            color=discord.Color.purple(),
            timestamp=interaction.created_at
        )

        embed.add_field(
            name="Percentage",
            value=f"{(score / total_questions) * 100:.2f}%" if total_questions > 0 else "0.00%",
            inline=True
        )

        embed.set_footer(
            text=f"Made by JadaDev • Trivia • Game for {game['user'].display_name}",
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        await interaction.followup.send(embed=embed)
        del self.active_games[game_key]

async def setup(bot):
    await bot.add_cog(TriviaCommand(bot))
    print('Loaded trivia command')
