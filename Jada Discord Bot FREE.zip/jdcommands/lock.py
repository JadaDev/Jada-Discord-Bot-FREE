import discord
from discord.ext import commands
from discord import app_commands

class LockCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="lock", description="Lock or unlock a channel")
    @app_commands.describe(
        channel="The channel to lock/unlock",
        action="Enable (lock) or disable (unlock) the channel"
    )
    @app_commands.choices(action=[
        app_commands.Choice(name="Enable (Lock)", value="lock"),
        app_commands.Choice(name="Disable (Unlock)", value="unlock")
    ])
    async def lock_command(self, interaction: discord.Interaction, channel: discord.TextChannel, action: str):
        """
        Lock/unlock command with proper permission checks
        """
        try:
            # Check if the user has manage channels permissions
            if not interaction.user.guild_permissions.manage_channels:
                await interaction.response.send_message("❌ You don't have permission to manage channels!", ephemeral=True)
                return
            
            # Check if the bot has manage channels permissions
            if not interaction.guild.me.guild_permissions.manage_channels:
                await interaction.response.send_message("❌ I don't have permission to manage channels!", ephemeral=True)
                return
            
            # Get the @everyone role
            everyone_role = interaction.guild.default_role
            
            if action == "lock":
                # Lock the channel (deny send messages for @everyone)
                await channel.set_permissions(everyone_role, send_messages=False)
                action_text = "🔒 Locked"
                color = discord.Color.red()
                description = f"Channel {channel.mention} has been locked"
            else:
                # Unlock the channel (allow send messages for @everyone or reset to None)
                await channel.set_permissions(everyone_role, send_messages=None)
                action_text = "🔓 Unlocked"
                color = discord.Color.green()
                description = f"Channel {channel.mention} has been unlocked"
            
            # Create embed response
            embed = discord.Embed(
                title=action_text,
                description=description,
                color=color,
                timestamp=interaction.created_at
            )
            embed.add_field(name="Channel", value=channel.mention, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)
                
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to modify this channel!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(LockCommand(bot))
    print('Loaded lock command')