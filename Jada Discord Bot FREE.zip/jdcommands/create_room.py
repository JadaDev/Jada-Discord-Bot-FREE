import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import asyncio

CREATE_ROOM_FILE = "create_room.json"

if not os.path.exists(CREATE_ROOM_FILE):
    with open(CREATE_ROOM_FILE, "w", encoding="utf-8") as f:
        json.dump({}, f, indent=4)


class ControlView(discord.ui.View):
    def __init__(self, owner_id: int, vc_id: int, text_id: int, parent_cog):
        super().__init__(timeout=None)
        self.owner_id = owner_id
        self.vc_id = vc_id
        self.text_id = text_id
        self.parent_cog = parent_cog

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "❌ Only the room owner can use this control panel.",
                ephemeral=True
            )
            return False
        return True

    @property
    def vc(self) -> discord.VoiceChannel | None:
        return self.parent_cog.bot.get_channel(self.vc_id)

    @discord.ui.button(label="Lock Room", style=discord.ButtonStyle.red, custom_id="lock")
    async def lock(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.vc:
            return
        await self.vc.set_permissions(interaction.guild.default_role, connect=False)
        await interaction.response.send_message("🔒 Room locked!", ephemeral=True)

    @discord.ui.button(label="Unlock Room", style=discord.ButtonStyle.green, custom_id="unlock")
    async def unlock(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.vc:
            return
        await self.vc.set_permissions(interaction.guild.default_role, connect=True)
        await interaction.response.send_message("🔓 Room unlocked!", ephemeral=True)

    @discord.ui.button(label="Rename Room", style=discord.ButtonStyle.blurple, custom_id="rename")
    async def rename(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.vc:
            return
        modal = discord.ui.Modal(title="Rename Room")

        name_input = discord.ui.TextInput(
            label="New Room Name", placeholder="Enter a new name", max_length=50
        )
        modal.add_item(name_input)

        async def on_submit(modal_inter: discord.Interaction):
            await self.vc.edit(name=str(name_input))
            await modal_inter.response.send_message(
                f"✅ Room renamed to **{name_input}**!", ephemeral=True
            )

        modal.on_submit = on_submit
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Hide Room", style=discord.ButtonStyle.red, custom_id="hide")
    async def hide(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.vc:
            return
        await self.vc.set_permissions(interaction.guild.default_role, view_channel=False)
        await interaction.response.send_message("🙈 Room hidden!", ephemeral=True)

    @discord.ui.button(label="Show Room", style=discord.ButtonStyle.green, custom_id="show")
    async def show(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.vc:
            return
        await self.vc.set_permissions(interaction.guild.default_role, view_channel=True)
        await interaction.response.send_message("👀 Room visible!", ephemeral=True)

    @discord.ui.button(label="Kick All", style=discord.ButtonStyle.red, custom_id="kickall")
    async def kick_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.vc:
            return
        for member in list(self.vc.members):
            await member.move_to(None)
        await interaction.response.send_message("👢 All members kicked from the room!", ephemeral=True)

    @discord.ui.button(label="Delete Room", style=discord.ButtonStyle.grey, custom_id="delete")
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.vc:
            try:
                await self.vc.delete()
            except:
                pass
        text_channel = interaction.guild.get_channel(self.text_id)
        if text_channel:
            try:
                await text_channel.delete()
            except:
                pass

        # Remove from JSON
        for msg_id, data in self.parent_cog.rooms.items():
            if str(self.owner_id) in data.get("users", {}):
                del data["users"][str(self.owner_id)]
                self.parent_cog.save_data()
                break

        await interaction.response.send_message("🗑️ Room deleted!", ephemeral=True)


class CreateRoomCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.rooms = self.load_data()

        # Re-add persistent views on startup
        for msg_id, data in self.rooms.items():
            for user_id, room in data.get("users", {}).items():
                view = ControlView(
                    int(user_id),
                    room["voice_channel"],
                    room["text_channel"],
                    self
                )
                self.bot.add_view(view, message_id=room.get("control_message", None))

    def load_data(self):
        with open(CREATE_ROOM_FILE, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_data(self):
        with open(CREATE_ROOM_FILE, "w", encoding="utf-8") as f:
            json.dump(self.rooms, f, indent=4)

    @app_commands.command(
        name="create_room",
        description="Create a reaction message to generate temporary private voice rooms"
    )
    async def create_room_command(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            await interaction.response.send_message(
                "❌ This command can only be used in a server.",
                ephemeral=True
            )
            return

        embed = discord.Embed(
            title="🎤 Create Your Private Room",
            description="React with 🔊 to create a temporary voice room.\n"
                        "You will have full control over the room.",
            color=discord.Color.green()
        )
        message = await interaction.channel.send(embed=embed)
        await message.add_reaction("🔊")

        # Save message ID for tracking
        self.rooms[str(message.id)] = {"guild_id": guild.id, "users": {}}
        self.save_data()

        await interaction.response.send_message(
            "✅ Room creation message sent!", ephemeral=True
        )

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if str(payload.message_id) not in self.rooms:
            return
        if str(payload.emoji) != "🔊":
            return

        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return

        member = guild.get_member(payload.user_id)
        if not member or member.bot:
            return

        category = discord.utils.get(guild.categories, name="Temporary Rooms")
        if not category:
            category = await guild.create_category("Temporary Rooms")

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(connect=False),
            member: discord.PermissionOverwrite(
                connect=True,
                manage_channels=True,
                move_members=True,
                mute_members=True,
                deafen_members=True
            )
        }
        vc = await guild.create_voice_channel(
            name=f"{member.display_name}'s Room",
            category=category,
            overwrites=overwrites
        )

        text_overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            member: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True)
        }
        text_channel = await guild.create_text_channel(
            name=f"{member.display_name}-chat",
            category=category,
            overwrites=text_overwrites,
            topic=f"Control panel for {member.display_name}'s voice room"
        )

        # Send control panel
        view = ControlView(member.id, vc.id, text_channel.id, self)
        embed = discord.Embed(
            title="🎛️ Room Control Panel",
            description="Use the buttons below to manage your voice room.",
            color=discord.Color.purple()
        )
        control_message = await text_channel.send(embed=embed, view=view)

        # Save room info with control message
        self.rooms[str(payload.message_id)]["users"][str(member.id)] = {
            "voice_channel": vc.id,
            "text_channel": text_channel.id,
            "control_message": control_message.id
        }
        self.save_data()

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        if str(payload.message_id) not in self.rooms:
            return
        if str(payload.emoji) != "🔊":
            return

        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return

        user_id = str(payload.user_id)
        user_data = self.rooms[str(payload.message_id)].get("users", {})
        if user_id not in user_data:
            return

        vc_id = user_data[user_id]["voice_channel"]
        text_id = user_data[user_id]["text_channel"]
        vc = guild.get_channel(vc_id)
        text_channel = guild.get_channel(text_id)

        if vc:
            try:
                await vc.delete()
            except:
                pass
        if text_channel:
            try:
                await text_channel.delete()
            except:
                pass

        del user_data[user_id]
        self.save_data()


async def setup(bot):
    await bot.add_cog(CreateRoomCommand(bot))
    print("Loaded create_room command")
