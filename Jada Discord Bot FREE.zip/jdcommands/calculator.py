import discord
from discord.ext import commands
from discord import app_commands
import re
from typing import Optional

class CalculatorCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="calculate", description="Calculate a mathematical expression")
    @app_commands.describe(expression="The mathematical expression to calculate")
    async def calculate_command(self, interaction: discord.Interaction, expression: str):
        """
        Simple calculator for basic math operations
        """
        try:
            # Clean the expression
            expression = expression.replace(" ", "").strip()

            # Basic validation - only allow safe characters
            if not re.match(r'^[0-9+\-*/().%]+$', expression):
                await interaction.response.send_message("❌ Invalid characters in expression! Only numbers, +, -, *, /, ( ), . , and % are allowed.", ephemeral=True)
                return

            # Simple security: check for potentially dangerous patterns
            dangerous_patterns = [
                r'\*{2}',  # **
                r'_{2}',   # __
                r'import', # import
                r'eval',   # eval
                r'exec',   # exec
                r'__'      # double underscore
            ]

            if any(re.search(pattern, expression) for pattern in dangerous_patterns):
                await interaction.response.send_message("❌ Unsafe expression detected!", ephemeral=True)
                return

            # Replace % with /100 * for percentage calculations
            expression = expression.replace('%', '/100')

            # Evaluate the expression safely
            try:
                # Use a limited eval for safety
                allowed_names = {
                    'abs': abs,
                    'max': max,
                    'min': min,
                    'round': round,
                    'int': int,
                    'float': float
                }

                result = eval(expression, {"__builtins__": {}}, allowed_names)
            except (ValueError, ZeroDivisionError, SyntaxError) as calc_error:
                await interaction.response.send_message(f"❌ Calculation error: {str(calc_error)}", ephemeral=True)
                return

            # Check for infinity or very large numbers
            if isinstance(result, (int, float)):
                if abs(result) > 1e15:
                    await interaction.response.send_message("❌ Result too large to display!", ephemeral=True)
                    return
                result = round(result, 10)  # Limit decimal places

            # Create embed
            embed = discord.Embed(
                title="🧮 Calculator",
                color=discord.Color.green(),
                timestamp=interaction.created_at
            )

            embed.add_field(name="Expression", value=f"`{expression}`", inline=False)
            embed.add_field(name="Result", value=f"**{result}**", inline=False)

            embed.set_footer(
                text=f"Made by JadaDev • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(CalculatorCommand(bot))
    print('Loaded calculator command')
