import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional

class BannerCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="banner", description="Display a user's Discord banner")
    @app_commands.describe(member="The user to get banner for (defaults to yourself)")
    async def banner_command(self, interaction: discord.Interaction, member: Optional[discord.Member] = None):
        """
        Display a user's Discord banner (Nitro feature)
        """
        try:
            # Default to caller if no member specified
            if member is None:
                member = interaction.user

            # Check if user has a banner (Nitro feature)
            banner = None
            try:
                # Try to fetch user info to get banner URL
                if interaction.guild:
                    # In guild context, the member might have banner info directly
                    if hasattr(member, 'banner') and member.banner:
                        banner = member.banner
                    else:
                        # Fetch the user to check banner
                        user_info = await interaction.client.fetch_user(member.id)
                        banner = user_info.banner
                else:
                    # DM context - fetch user directly
                    user_info = await interaction.client.fetch_user(member.id)
                    banner = user_info.banner
            except Exception as fetch_error:
                print(f"Banner fetch error: {fetch_error}")
                # Try alternative methods
                if hasattr(member, 'banner'):
                    banner = member.banner

            if not banner:
                # No banner available
                embed = discord.Embed(
                    title=f"{member.display_name}'s Banner",
                    description="❌ This user doesn't have a Discord banner.\n\n**Banners are available to:**\n• Discord Nitro subscribers\n• Boosters in supported servers",
                    color=discord.Color.red(),
                    timestamp=interaction.created_at
                )

                embed.set_footer(
                    text=f"Made by JadaDev • Requested by {interaction.user.display_name}",
                    icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
                )
                await interaction.response.send_message(embed=embed)
                return

            # Get banner URL
            banner_url = banner.url if hasattr(banner, 'url') else str(banner)

            # Create embed
            embed = discord.Embed(
                title=f"🎨 {member.display_name}'s Banner",
                color=member.color if isinstance(member, discord.Member) and member.color != discord.Color.default() else discord.Color.blue(),
                timestamp=interaction.created_at
            )

            # Set the banner as the main image
            embed.set_image(url=banner_url)

            # Add banner info
            embed.add_field(
                name="👤 User Info",
                value=f"**Username:** {member.name}#{member.discriminator}\n**ID:** `{member.id}`",
                inline=True
            )

            embed.add_field(
                name="🖼️ Banner Info",
                value="Nitro-exclusive feature\nHigh-quality image available",
                inline=True
            )

            # Add download link
            embed.add_field(
                name="⬇️ Download",
                value=f"[Click Here]({banner_url})",
                inline=True
            )

            embed.set_footer(
                text=f"Made by JadaDev • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(BannerCommand(bot))
    print('Loaded banner command')
