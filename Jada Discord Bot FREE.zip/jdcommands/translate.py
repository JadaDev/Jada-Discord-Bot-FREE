import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import os
from typing import Optional

class TranslateCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Languages supported by Google Translate (subset of most common)
        self.languages = {
            'en': 'English',
            'es': 'Spanish',
            'fr': 'French',
            'de': 'German',
            'it': 'Italian',
            'pt': 'Portuguese',
            'ru': 'Russian',
            'ja': 'Japanese',
            'ko': 'Korean',
            'zh': 'Chinese',
            'ar': 'Arabic',
            'hi': 'Hindi',
            'tr': 'Turkish',
            'nl': 'Dutch',
            'sv': 'Swedish',
            'no': 'Norwegian',
            'da': 'Danish',
            'fi': 'Finnish',
            'pl': 'Polish',
            'cs': 'Czech'
        }

    @app_commands.command(name="translate", description="Translate text between languages")
    @app_commands.describe(
        text="Text to translate",
        to_lang="Target language code (e.g., es, fr, de)",
        from_lang="Source language code (auto-detect if omitted)"
    )
    async def translate_command(self, interaction: discord.Interaction, text: str, to_lang: str, from_lang: Optional[str] = None):
        """
        Translate text using Google Translate API
        """
        try:
            if not text or not text.strip():
                await interaction.response.send_message("❌ Please provide text to translate!", ephemeral=True)
                return

            text = text.strip()
            to_lang = to_lang.lower().strip()
            if from_lang:
                from_lang = from_lang.lower().strip()

            # Validate target language
            if to_lang not in self.languages:
                valid_langs = ", ".join(list(self.languages.keys())[:10])  # Show first 10
                await interaction.response.send_message(f"❌ Target language '{to_lang}' not supported! Valid options: {valid_langs}...", ephemeral=True)
                return

            # Validate source language if provided
            if from_lang and from_lang not in self.languages:
                await interaction.response.send_message(f"❌ Source language '{from_lang}' not supported!", ephemeral=True)
                return

            # Prepare API request
            api_url = "https://translate.googleapis.com/translate_a/single"
            params = {
                'client': 'gtx',  # Google Translate web client
                'sl': from_lang or 'auto',  # Source language or auto-detect
                'tl': to_lang,  # Target language
                'dt': 't',  # Return translated text
                'q': text
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(api_url, params=params) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message("❌ Translation service temporarily unavailable!", ephemeral=True)
                        return

                    data = await resp.json()

            # Parse Google Translate response
            if not data or not data[0]:
                await interaction.response.send_message("❌ Could not translate the text. Please try a different phrase.", ephemeral=True)
                return

            # Extract translation
            translated_text = data[0][0][0]
            detected_source = data[2] if len(data) > 2 and from_lang == 'auto' else from_lang

            if not translated_text:
                await interaction.response.send_message("❌ Translation failed. Please try again with different text.", ephemeral=True)
                return

            # Check if translation is the same as original (no translation needed)
            if translated_text.lower().strip() == text.lower().strip() and detected_source == to_lang:
                await interaction.response.send_message("ℹ️ The text is already in the target language!", ephemeral=True)
                return

            # Create embed
            source_lang_name = self.languages.get(detected_source, detected_source.upper() if detected_source else "Auto")
            target_lang_name = self.languages.get(to_lang, to_lang.upper())

            embed = discord.Embed(
                title="🌐 Text Translation",
                color=discord.Color.green(),
                timestamp=interaction.created_at
            )

            # Add fields for readability
            embed.add_field(
                name=f"📝 From {source_lang_name}",
                value=text[:500] + "..." if len(text) > 500 else text,
                inline=False
            )

            embed.add_field(
                name=f"🤖 To {target_lang_name}",
                value=translated_text[:500] + "..." if len(translated_text) > 500 else translated_text,
                inline=False
            )

            # Add character count if translation is significantly different
            if len(translated_text) != len(text):
                embed.add_field(
                    name="📊 Info",
                    value=f"Characters: {len(text)} → {len(translated_text)} | Languages: {source_lang_name} → {target_lang_name}",
                    inline=False
                )

            embed.set_footer(
                text=f"Made by JadaDev • Powered by Google Translate • {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(TranslateCommand(bot))
    print('Loaded translate command')
