import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button
import json
import os

ROLES_JSON = "roles_setup.json"

# Load or initialize the roles JSON
if os.path.exists(ROLES_JSON):
    with open(ROLES_JSON, "r") as f:
        ROLES_DATA = json.load(f)
else:
    ROLES_DATA = {}

def save_roles_data():
    with open(ROLES_JSON, "w") as f:
        json.dump(ROLES_DATA, f, indent=4)

class RoleButton(Button):
    def __init__(self, role: discord.Role):
        super().__init__(label=role.name, style=discord.ButtonStyle.primary)
        self.role_id = role.id

    async def callback(self, interaction: discord.Interaction):
        role = interaction.guild.get_role(self.role_id)
        if not role:
            return await interaction.response.send_message("⚠️ Role not found.", ephemeral=True)
        if role in interaction.user.roles:
            await interaction.user.remove_roles(role)
            await interaction.response.send_message(f"Removed role **{role.name}**", ephemeral=True)
        else:
            await interaction.user.add_roles(role)
            await interaction.response.send_message(f"Assigned role **{role.name}**", ephemeral=True)

class RoleView(View):
    def __init__(self, roles):
        super().__init__(timeout=None)
        for role in roles:
            self.add_item(RoleButton(role))

class RoleManager(commands.Cog):
    """Full persistent role menu system with autocomplete for embeds."""

    def __init__(self, bot):
        self.bot = bot

    # ------------------ Autocomplete for messages ------------------
    async def message_autocomplete(self, interaction: discord.Interaction, current: str):
        choices = []
        for msg_id, data in ROLES_DATA.items():
            channel = interaction.guild.get_channel(data["channel_id"])
            title = data.get("title", "No Title")
            display = f"{title} in #{channel.name}" if channel else title
            if current.lower() in display.lower():
                choices.append(app_commands.Choice(name=display, value=msg_id))
            if len(choices) >= 25:  # Discord limit
                break
        return choices

    # ------------------ /rolesetup ------------------
    @app_commands.command(name="rolesetup", description="Setup a role assignment embed")
    @app_commands.describe(
        channel="Channel to send the embed",
        title="Embed title",
        description="Embed description",
        image="Embed image URL (optional)",
        role1="Role 1",
        role2="Role 2",
        role3="Role 3",
        role4="Role 4",
        role5="Role 5",
        role6="Role 6",
        role7="Role 7",
        role8="Role 8",
        role9="Role 9",
        role10="Role 10"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def rolesetup(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        title: str,
        description: str,
        role1: discord.Role = None,
        role2: discord.Role = None,
        role3: discord.Role = None,
        role4: discord.Role = None,
        role5: discord.Role = None,
        role6: discord.Role = None,
        role7: discord.Role = None,
        role8: discord.Role = None,
        role9: discord.Role = None,
        role10: discord.Role = None,
        image: str = None
    ):
        await interaction.response.defer(ephemeral=True)
        try:
            roles = [r for r in [role1, role2, role3, role4, role5, role6, role7, role8, role9, role10] if r]
            if not roles:
                return await interaction.followup.send("⚠️ You must select at least one role.", ephemeral=True)

            embed = discord.Embed(title=title, description=description, color=discord.Color.blue())
            if image:
                embed.set_image(url=image)

            view = RoleView(roles)
            message = await channel.send(embed=embed, view=view)

            ROLES_DATA[str(message.id)] = {
                "channel_id": channel.id,
                "title": title,
                "description": description,
                "image": image,
                "roles": [r.id for r in roles]
            }
            save_roles_data()
            await interaction.followup.send(f"✅ Roles setup completed in {channel.mention}", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {e}", ephemeral=True)

    # ------------------ /roleedit ------------------
    @app_commands.command(name="roleedit", description="Edit title, description, or image of a role embed")
    @app_commands.describe(
        message="Select the role embed to edit",
        title="New title (optional)",
        description="New description (optional)",
        image="New image URL (optional)"
    )
    @app_commands.autocomplete(message=message_autocomplete)
    @app_commands.checks.has_permissions(administrator=True)
    async def roleedit(
        self,
        interaction: discord.Interaction,
        message: str,
        title: str = None,
        description: str = None,
        image: str = None
    ):
        await interaction.response.defer(ephemeral=True)
        try:
            if message not in ROLES_DATA:
                return await interaction.followup.send("⚠️ Message not found.", ephemeral=True)
            data = ROLES_DATA[message]
            channel = self.bot.get_channel(data["channel_id"])
            msg_obj = await channel.fetch_message(int(message))

            if title:
                data["title"] = title
            if description:
                data["description"] = description
            if image is not None:
                data["image"] = image

            embed = discord.Embed(title=data["title"], description=data["description"], color=discord.Color.blue())
            if data["image"]:
                embed.set_image(url=data["image"])

            roles = [channel.guild.get_role(rid) for rid in data["roles"] if channel.guild.get_role(rid)]
            view = RoleView(roles)
            await msg_obj.edit(embed=embed, view=view)
            save_roles_data()
            await interaction.followup.send("✅ Role embed updated.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {e}", ephemeral=True)

    # ------------------ /roleadd ------------------
    @app_commands.command(name="roleadd", description="Add a role to an existing role embed")
    @app_commands.describe(message="Select the embed", role="Role to add")
    @app_commands.autocomplete(message=message_autocomplete)
    @app_commands.checks.has_permissions(administrator=True)
    async def roleadd(self, interaction: discord.Interaction, message: str, role: discord.Role):
        await interaction.response.defer(ephemeral=True)
        try:
            if message not in ROLES_DATA:
                return await interaction.followup.send("⚠️ Message not found.", ephemeral=True)
            data = ROLES_DATA[message]
            if role.id not in data["roles"]:
                data["roles"].append(role.id)
            channel = self.bot.get_channel(data["channel_id"])
            msg_obj = await channel.fetch_message(int(message))
            roles = [channel.guild.get_role(rid) for rid in data["roles"] if channel.guild.get_role(rid)]
            view = RoleView(roles)
            await msg_obj.edit(view=view)
            save_roles_data()
            await interaction.followup.send(f"✅ Role {role.name} added.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {e}", ephemeral=True)

    # ------------------ /roleremove ------------------
    @app_commands.command(name="roleremove", description="Remove a role from an existing role embed")
    @app_commands.describe(message="Select the embed", role="Role to remove")
    @app_commands.autocomplete(message=message_autocomplete)
    @app_commands.checks.has_permissions(administrator=True)
    async def roleremove(self, interaction: discord.Interaction, message: str, role: discord.Role):
        await interaction.response.defer(ephemeral=True)
        try:
            if message not in ROLES_DATA:
                return await interaction.followup.send("⚠️ Message not found.", ephemeral=True)
            data = ROLES_DATA[message]
            if role.id in data["roles"]:
                data["roles"].remove(role.id)
            channel = self.bot.get_channel(data["channel_id"])
            msg_obj = await channel.fetch_message(int(message))
            roles = [channel.guild.get_role(rid) for rid in data["roles"] if channel.guild.get_role(rid)]
            view = RoleView(roles)
            await msg_obj.edit(view=view)
            save_roles_data()
            await interaction.followup.send(f"✅ Role {role.name} removed.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {e}", ephemeral=True)

    # ------------------ /roleremoveembed ------------------
    @app_commands.command(name="roleremoveembed", description="Delete the role embed entirely")
    @app_commands.describe(message="Select the embed to delete")
    @app_commands.autocomplete(message=message_autocomplete)
    @app_commands.checks.has_permissions(administrator=True)
    async def roleremoveembed(self, interaction: discord.Interaction, message: str):
        await interaction.response.defer(ephemeral=True)
        try:
            if message not in ROLES_DATA:
                return await interaction.followup.send("⚠️ Message not found.", ephemeral=True)
            data = ROLES_DATA.pop(message)
            channel = self.bot.get_channel(data["channel_id"])
            msg_obj = await channel.fetch_message(int(message))
            await msg_obj.delete()
            save_roles_data()
            await interaction.followup.send("✅ Role embed deleted.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {e}", ephemeral=True)

    # ------------------ Reload persistent views on bot startup ------------------
    @commands.Cog.listener()
    async def on_ready(self):
        for message_id, data in ROLES_DATA.items():
            try:
                channel = self.bot.get_channel(data["channel_id"])
                if not channel:
                    continue
                msg_obj = await channel.fetch_message(int(message_id))
                roles = [channel.guild.get_role(rid) for rid in data["roles"] if channel.guild.get_role(rid)]
                view = RoleView(roles)
                await msg_obj.edit(view=view)
            except:
                continue

async def setup(bot):
    await bot.add_cog(RoleManager(bot))
    print("Loaded role management command")
