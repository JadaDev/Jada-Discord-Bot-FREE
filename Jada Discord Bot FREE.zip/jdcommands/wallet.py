import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json
from datetime import datetime
import asyncio

class WalletCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
        self.chains = {
            "solana": {
                "name": "Solana",
                "symbol": "SOL", 
                "color": 0x9945FF,
                "icon_url": "https://cryptologos.cc/logos/solana-sol-logo.png"
            },
            "bitcoin": {
                "name": "Bitcoin",
                "symbol": "BTC",
                "color": 0xF7931A,
                "icon_url": "https://cryptologos.cc/logos/bitcoin-btc-logo.png"
            }
        }

    def is_valid_bitcoin_address(self, address):
        return len(address) >= 26 and len(address) <= 62 and (address.startswith('1') or address.startswith('3') or address.startswith('bc1'))

    def is_valid_solana_address(self, address):
        return len(address) >= 32 and len(address) <= 44 and not address.startswith('0x')

    def detect_wallet_type(self, address):
        if self.is_valid_bitcoin_address(address):
            return "bitcoin"
        elif self.is_valid_solana_address(address):
            return "solana"
        else:
            return "unknown"

    async def get_comprehensive_bitcoin_data(self, session, address):
        """Get comprehensive Bitcoin wallet data similar to Solana format"""
        try:
            base_url = "https://blockstream.info/api"
            
            # Get address info
            addr_resp = await session.get(f"{base_url}/address/{address}")
            if addr_resp.status != 200:
                return {"success": False, "error": f"HTTP {addr_resp.status}"}
            
            addr_data = await addr_resp.json()
            
            # Get transactions
            tx_resp = await session.get(f"{base_url}/address/{address}/txs")
            tx_data = await tx_resp.json() if tx_resp.status == 200 else []
            
            # Get UTXO info
            utxo_resp = await session.get(f"{base_url}/address/{address}/utxo")
            utxo_data = await utxo_resp.json() if utxo_resp.status == 200 else []
            
            return {
                "success": True,
                "address_data": addr_data,
                "transactions": tx_data,
                "utxos": utxo_data
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def get_comprehensive_solana_data(self, session, address):
        """Get comprehensive Solana wallet data"""
        try:
            url = "https://api.mainnet-beta.solana.com"
            headers = {"Content-Type": "application/json"}
            
            # Get balance
            balance_payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getBalance",
                "params": [address]
            }
            
            # Get account info
            account_payload = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "getAccountInfo",
                "params": [address, {"encoding": "base64", "commitment": "confirmed"}]
            }
            
            # Get transaction signatures
            signatures_payload = {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "getSignaturesForAddress",
                "params": [address, {"limit": 10}]
            }
            
            # Get token accounts
            token_payload = {
                "jsonrpc": "2.0",
                "id": 4,
                "method": "getTokenAccountsByOwner",
                "params": [
                    address,
                    {"programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"},
                    {"encoding": "jsonParsed"}
                ]
            }
            
            # Get rent exempt minimum
            rent_payload = {
                "jsonrpc": "2.0",
                "id": 5,
                "method": "getMinimumBalanceForRentExemption",
                "params": [0]
            }
            
            # Execute all requests
            balance_resp = await session.post(url, json=balance_payload, headers=headers)
            account_resp = await session.post(url, json=account_payload, headers=headers)
            signatures_resp = await session.post(url, json=signatures_payload, headers=headers)
            token_resp = await session.post(url, json=token_payload, headers=headers)
            rent_resp = await session.post(url, json=rent_payload, headers=headers)
            
            balance_data = await balance_resp.json()
            account_data = await account_resp.json()
            signatures_data = await signatures_resp.json()
            token_data = await token_resp.json()
            rent_data = await rent_resp.json()
            
            return {
                "success": True,
                "balance_data": balance_data,
                "account_data": account_data,
                "signatures_data": signatures_data,
                "token_data": token_data,
                "rent_data": rent_data
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def create_bitcoin_embed(self, wallet, data):
        """Create detailed Bitcoin embed similar to Solana format"""
        addr_data = data["address_data"]
        transactions = data["transactions"]
        utxos = data["utxos"]
        
        # Calculate balance
        funded = addr_data.get("chain_stats", {}).get("funded_txo_sum", 0)
        spent = addr_data.get("chain_stats", {}).get("spent_txo_sum", 0)
        balance_satoshi = funded - spent
        balance_btc = balance_satoshi / 100000000
        
        embed = discord.Embed(
            title="₿ Bitcoin Wallet Information",
            color=self.chains["bitcoin"]["color"],
            timestamp=datetime.utcnow()
        )
        
        # Wallet address
        embed.add_field(
            name="📜 Wallet Address",
            value=f"``````",
            inline=False
        )
        
        # Balance information
        balance_text = f"**{balance_btc:.8f} BTC**\n"
        balance_text += f"*({balance_satoshi:,} satoshi)*\n"
        if balance_btc > 0.001:
            balance_text += "✅ Significant balance"
        elif balance_btc > 0:
            balance_text += "⚠️ Dust balance"
        else:
            balance_text += "❌ No balance"
        
        embed.add_field(
            name="💰 BTC Balance",
            value=balance_text,
            inline=True
        )
        
        # Address status
        tx_count = addr_data.get("chain_stats", {}).get("tx_count", 0)
        status_text = "✅ Active" if tx_count > 0 else "❌ Unused"
        status_text += f"\n**Total Received:** {addr_data.get('chain_stats', {}).get('funded_txo_sum', 0) / 100000000:.8f} BTC"
        status_text += f"\n**Total Sent:** {addr_data.get('chain_stats', {}).get('spent_txo_sum', 0) / 100000000:.8f} BTC"
        status_text += f"\n**UTXOs:** {len(utxos)}"
        
        embed.add_field(
            name="🔍 Address Status",
            value=status_text,
            inline=True
        )
        
        # Recent activity
        if transactions:
            latest_tx = transactions[0]
            latest_time = datetime.fromtimestamp(latest_tx.get("status", {}).get("block_time", 0))
            activity_text = f"**Last Transaction:**\n{latest_time.strftime('%Y-%m-%d %H:%M UTC')}\n"
            activity_text += f"**Recent Transactions:** {len(transactions)}/25\n"
            
            # Check confirmations
            latest_confirmations = latest_tx.get("status", {}).get("confirmed", False)
            if latest_confirmations:
                activity_text += "✅ Latest TX confirmed"
            else:
                activity_text += "⚠️ Latest TX unconfirmed"
        else:
            activity_text = "No recent transactions found"
        
        embed.add_field(
            name="📈 Recent Activity",
            value=activity_text,
            inline=True
        )
        
        # UTXO information
        if utxos:
            utxo_text = f"**Total UTXOs:** {len(utxos)}\n"
            
            # Show largest UTXOs
            sorted_utxos = sorted(utxos, key=lambda x: x.get("value", 0), reverse=True)
            utxo_balances = []
            for utxo in sorted_utxos[:3]:
                value_btc = utxo.get("value", 0) / 100000000
                txid = utxo.get("txid", "Unknown")
                utxo_balances.append(f"• {txid[:8]}...: {value_btc:.8f} BTC")
            
            if utxo_balances:
                utxo_text += "\n**Largest UTXOs:**\n" + "\n".join(utxo_balances)
            else:
                utxo_text += "\n*No UTXOs found*"
        else:
            utxo_text = "No UTXOs found"
        
        embed.add_field(
            name="🧩 UTXO Information",
            value=utxo_text,
            inline=True
        )
        
        # Network info
        network_text = "**Network:** Bitcoin Mainnet\n"
        network_text += f"**Address Type:** {'P2PKH' if wallet.startswith('1') else 'P2SH' if wallet.startswith('3') else 'Bech32'}\n"
        network_text += f"**Query Time:** {datetime.utcnow().strftime('%H:%M:%S UTC')}"
        
        embed.add_field(
            name="🌐 Network Info",
            value=network_text,
            inline=True
        )
        
        # Wallet health score
        health_score = 100
        health_reasons = []
        
        if balance_btc == 0:
            health_score -= 40
            health_reasons.append("No current balance")
        
        if tx_count == 0:
            health_score -= 30
            health_reasons.append("No transaction history")
        elif tx_count < 5:
            health_score -= 15
            health_reasons.append("Limited transaction history")
        
        if len(utxos) == 0 and balance_btc > 0:
            health_score -= 25
            health_reasons.append("Balance without UTXOs (unusual)")
        
        health_color = "🟢" if health_score >= 80 else "🟡" if health_score >= 60 else "🔴"
        health_text = f"{health_color} **{health_score}/100**"
        if health_reasons:
            health_text += f"\n*Issues: {', '.join(health_reasons)}*"
        
        embed.add_field(
            name="💊 Wallet Health",
            value=health_text,
            inline=True
        )
        
        embed.set_footer(
            text=f"Bitcoin Mainnet • Requested by {interaction.user.display_name}",
            icon_url=self.chains["bitcoin"]["icon_url"]
        )
        
        return embed

    async def create_solana_embed(self, wallet, data, interaction):
        """Create detailed Solana embed matching the original format"""
        balance_data = data["balance_data"]
        account_data = data["account_data"]
        signatures_data = data["signatures_data"]
        token_data = data["token_data"]
        rent_data = data["rent_data"]
        
        # Process data
        if "result" not in balance_data:
            return None
        
        lamports = balance_data["result"]["value"]
        sol_balance = lamports / 1_000_000_000
        
        account_info = account_data.get("result", {}).get("value")
        account_exists = account_info is not None
        
        rent_exempt_min = rent_data.get("result", 0) / 1_000_000_000
        
        signatures = signatures_data.get("result", [])
        transaction_count = len(signatures)
        
        token_accounts = token_data.get("result", {}).get("value", [])
        
        # Create embed (exact copy of original format)
        embed = discord.Embed(
            title="🌟 Solana Wallet Information",
            color=0x9945FF,
            timestamp=datetime.utcnow()
        )
        
        embed.add_field(
            name="📜 Wallet Address",
            value=f"``````",
            inline=False
        )
        
        balance_text = f"**{sol_balance:.6f} SOL**\n"
        balance_text += f"*({lamports:,} lamports)*\n"
        if sol_balance < rent_exempt_min:
            balance_text += f"⚠️ Below rent-exempt minimum ({rent_exempt_min:.6f} SOL)"
        else:
            balance_text += f"✅ Above rent-exempt minimum"
        
        embed.add_field(
            name="💰 SOL Balance",
            value=balance_text,
            inline=True
        )
        
        status_text = "✅ Active" if account_exists else "❌ Not created"
        if account_exists and account_info:
            owner = account_info.get("owner", "Unknown")
            executable = account_info.get("executable", False)
            data_size = len(account_info.get("data", [""]))
            
            status_text += f"\n**Owner:** {owner[:8]}...{owner[-8:]}" if len(owner) > 16 else f"\n**Owner:** {owner}"
            status_text += f"\n**Executable:** {'Yes' if executable else 'No'}"
            status_text += f"\n**Data Size:** {data_size} bytes"
        
        embed.add_field(
            name="🔍 Account Status",
            value=status_text,
            inline=True
        )
        
        if signatures:
            latest_tx = signatures[0]
            latest_time = datetime.fromtimestamp(latest_tx.get("blockTime", 0))
            activity_text = f"**Last Transaction:**\n{latest_time.strftime('%Y-%m-%d %H:%M UTC')}\n"
            activity_text += f"**Recent Transactions:** {transaction_count}/10\n"
            
            error_count = sum(1 for sig in signatures if sig.get("err") is not None)
            if error_count > 0:
                activity_text += f"⚠️ {error_count} failed transactions"
            else:
                activity_text += "✅ No recent failures"
        else:
            activity_text = "No recent transactions found"
        
        embed.add_field(
            name="📈 Recent Activity",
            value=activity_text,
            inline=True
        )
        
        if token_accounts:
            token_text = f"**Total Token Accounts:** {len(token_accounts)}\n"
            
            token_balances = []
            for account in token_accounts[:5]:
                account_info = account.get("account", {}).get("data", {}).get("parsed", {}).get("info", {})
                token_amount = account_info.get("tokenAmount", {})
                mint = account_info.get("mint", "Unknown")
                ui_amount = token_amount.get("uiAmount", 0)
                
                if ui_amount and ui_amount > 0:
                    token_balances.append(f"• {mint[:8]}...{mint[-8:]}: {ui_amount}")
            
            if token_balances:
                token_text += "\n**Top Holdings:**\n" + "\n".join(token_balances[:3])
            else:
                token_text += "\n*No tokens with balance found*"
        else:
            token_text = "No token accounts found"
        
        embed.add_field(
            name="🪙 Token Information",
            value=token_text,
            inline=True
        )
        
        network_text = "**Network:** Mainnet Beta\n"
        network_text += f"**Rent Exempt Min:** {rent_exempt_min:.6f} SOL\n"
        network_text += f"**Query Time:** {datetime.utcnow().strftime('%H:%M:%S UTC')}"
        
        embed.add_field(
            name="🌐 Network Info",
            value=network_text,
            inline=True
        )
        
        health_score = 100
        health_reasons = []
        
        if sol_balance < rent_exempt_min:
            health_score -= 30
            health_reasons.append("Below rent-exempt minimum")
        
        if not account_exists:
            health_score -= 20
            health_reasons.append("Account not created")
        
        if transaction_count == 0:
            health_score -= 15
            health_reasons.append("No recent activity")
        
        error_count = sum(1 for sig in signatures if sig.get("err") is not None) if signatures else 0
        if error_count > 3:
            health_score -= 25
            health_reasons.append("High transaction failure rate")
        
        health_color = "🟢" if health_score >= 80 else "🟡" if health_score >= 60 else "🔴"
        health_text = f"{health_color} **{health_score}/100**"
        if health_reasons:
            health_text += f"\n*Issues: {', '.join(health_reasons)}*"
        
        embed.add_field(
            name="💊 Wallet Health",
            value=health_text,
            inline=True
        )
        
        embed.set_footer(
            text=f"Solana Mainnet Beta • Requested by {interaction.user.display_name}",
            icon_url="https://cryptologos.cc/logos/solana-sol-logo.png"
        )
        
        return embed

    @app_commands.command(name="wallet", description="Get detailed information about a Bitcoin or Solana wallet")
    @app_commands.describe(wallet="The wallet address to analyze")
    async def wallet_command(self, interaction: discord.Interaction, wallet: str):
        """Get detailed wallet information similar to the Solana command format"""
        await interaction.response.defer()
        
        wallet = wallet.strip()
        if len(wallet) < 26:
            await interaction.followup.send("❌ Could not fetch wallet data. Invalid wallet address.", ephemeral=True)
            return

        wallet_type = self.detect_wallet_type(wallet)
        
        if wallet_type == "unknown":
            await interaction.followup.send("❌ Unsupported wallet address format. Please provide a Bitcoin or Solana address.", ephemeral=True)
            return

        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible; Wallet-Analyzer/1.0)',
                'Accept': 'application/json'
            }
            
            timeout = aiohttp.ClientTimeout(total=20)
            
            async with aiohttp.ClientSession(headers=headers, timeout=timeout) as session:
                if wallet_type == "bitcoin":
                    result = await self.get_comprehensive_bitcoin_data(session, wallet)
                    if result.get("success"):
                        embed = await self.create_bitcoin_embed(wallet, result)
                        await interaction.followup.send(embed=embed)
                    else:
                        await interaction.followup.send(f"❌ Could not fetch Bitcoin wallet data. {result.get('error', 'Unknown error')}", ephemeral=True)
                
                elif wallet_type == "solana":
                    result = await self.get_comprehensive_solana_data(session, wallet)
                    if result.get("success"):
                        embed = await self.create_solana_embed(wallet, result, interaction)
                        if embed:
                            await interaction.followup.send(embed=embed)
                        else:
                            await interaction.followup.send("❌ Could not fetch wallet data. Invalid wallet address.", ephemeral=True)
                    else:
                        await interaction.followup.send(f"❌ Could not fetch Solana wallet data. {result.get('error', 'Unknown error')}", ephemeral=True)

        except asyncio.TimeoutError:
            await interaction.followup.send("❌ Network error while fetching data.", ephemeral=True)
        except aiohttp.ClientError:
            await interaction.followup.send("❌ Network error while fetching data.", ephemeral=True)
        except json.JSONDecodeError:
            await interaction.followup.send("❌ Invalid response from API.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Unexpected error: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(WalletCommand(bot))
    print('Loaded Wallet Command')
