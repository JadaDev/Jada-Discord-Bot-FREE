import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional
import random

class EightBallCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

        # Classic magic 8-ball responses
        self.responses = [
            # Positive answers (dark green)
            "It is certain.",
            "It is decidedly so.",
            "Without a doubt.",
            "Yes definitely.",
            "You may rely on it.",
            "As I see it, yes.",
            "Most likely.",
            "Outlook good.",
            "Yes.",
            "Signs point to yes.",
            # Neutral answers (gold)
            "Reply hazy, try again.",
            "Ask again later.",
            "Better not tell you now.",
            "Cannot predict now.",
            "Concentrate and ask again.",
            # Negative answers (red)
            "Don't count on it.",
            "My reply is no.",
            "My sources say no.",
            "Outlook not so good.",
            "Very doubtful."
        ]

    @app_commands.command(name="_8ball", description="Magic 8-ball predictions")
    @app_commands.describe(question="The question you want to ask")
    async def eightball_command(self, interaction: discord.Interaction, question: str):
        """
        Magic 8-ball makes predictions based on your question
        """
        try:
            # Get random response
            response = random.choice(self.responses)

            # Determine color based on response type
            if response in [
                "It is certain.", "It is decidedly so.", "Without a doubt.",
                "Yes definitely.", "You may rely on it."
            ]:
                color = discord.Color.green()
                emoji = "🟢"
            elif response in [
                "Reply hazy, try again.", "Ask again later.",
                "Better not tell you now.", "Cannot predict now.", "Concentrate and ask again."
            ]:
                color = discord.Color.gold()
                emoji = "🟡"
            elif response in [
                "Don't count on it.", "My reply is no.",
                "My sources say no.", "Outlook not so good.", "Very doubtful."
            ]:
                color = discord.Color.red()
                emoji = "🔴"
            else:
                color = discord.Color.blue()
                emoji = "🔮"

            # Create embed
            embed = discord.Embed(
                title="🔮 Magic 8-Ball",
                color=color,
                timestamp=interaction.created_at
            )

            embed.add_field(name="Your Question", value=f"❓ {question}", inline=False)
            embed.add_field(name="8-Ball Says", value=f"{emoji} ***{response}***", inline=False)

            embed.set_footer(
                text=f"Made by JadaDev • Magic 8-Ball • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(EightBallCommand(bot))
    print('Loaded 8-ball command')
