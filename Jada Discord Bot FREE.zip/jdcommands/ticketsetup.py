import discord
from discord.ext import commands
from discord import app_commands
import os
import json
import asyncio
from datetime import datetime

SETUP_FILE = "ticket_setup.json"
TRANSCRIPT_DIR = "transcripts"


class TicketSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ensure_files()
        self.config = self.load_setup()

    # ---------------- Ensure Files / Folders ----------------
    def ensure_files(self):
        if not os.path.exists(SETUP_FILE):
            with open(SETUP_FILE, "w", encoding="utf-8") as f:
                json.dump({}, f, indent=4)
        if not os.path.exists(TRANSCRIPT_DIR):
            os.makedirs(TRANSCRIPT_DIR)

    def load_setup(self):
        try:
            with open(SETUP_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_setup(self):
        with open(SETUP_FILE, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=4)

    # ---------------- Setup Command ----------------
    @app_commands.command(name="ticketsetup", description="Setup the ticket system for this server")
    @app_commands.describe(
        channel="Channel where ticket panel will be posted",
        open_category="Category for open tickets",
        closed_category="Category for closed tickets",
        image_url="Optional banner image for the ticket panel"
    )
    async def ticketsetup(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        open_category: discord.CategoryChannel,
        closed_category: discord.CategoryChannel,
        image_url: str = None
    ):
        guild_id = str(interaction.guild.id)

        self.config[guild_id] = {
            "ticket_channel": channel.id,
            "open_category": open_category.id,
            "closed_category": closed_category.id,
            "image_url": image_url or "https://i.imgur.com/En7X8oU.png",
            "ticket_counter": 0
        }
        self.save_setup()

        embed = discord.Embed(
            title="🎟️ Support Ticket System",
            description="Need help? Click the button below to open a private support ticket with our staff team.",
            color=discord.Color.blue()
        )
        embed.set_image(url=self.config[guild_id]["image_url"])
        embed.set_footer(text=f"{interaction.guild.name} • Ticket System")

        class TicketView(discord.ui.View):
            def __init__(self, cog):
                super().__init__(timeout=None)
                self.cog = cog

            @discord.ui.button(label="🎫 Create Ticket", style=discord.ButtonStyle.green, custom_id="create_ticket")
            async def create_ticket(self, itx: discord.Interaction, button: discord.ui.Button):
                await itx.response.send_modal(TicketModal(self.cog, itx.user))

        view = TicketView(self)
        await channel.send(embed=embed, view=view)

        await interaction.response.send_message(
            f"✅ Ticket system configured. Panel sent to {channel.mention}.",
            ephemeral=True
        )

    # ---------------- Ticket Creation ----------------
    async def handle_ticket_creation(self, interaction: discord.Interaction, category_choice: str, problem_desc: str):
        guild_id = str(interaction.guild.id)
        conf = self.config.get(guild_id)
        if not conf:
            await interaction.response.send_message("❌ Ticket system is not configured for this server.", ephemeral=True)
            return

        category = discord.utils.get(interaction.guild.categories, id=conf["open_category"])
        if not category:
            await interaction.response.send_message("❌ Ticket category not found.", ephemeral=True)
            return

        # Generate next ticket number
        ticket_number = conf.get("ticket_counter", 0) + 1
        self.config[guild_id]["ticket_counter"] = ticket_number
        self.save_setup()

        ticket_name = f"ticket-{ticket_number:04d}"

        # Create channel
        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True),
            interaction.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True),
        }
        ticket_channel = await interaction.guild.create_text_channel(
            name=ticket_name,
            category=category,
            overwrites=overwrites
        )

        await interaction.response.send_message(f"🎫 Ticket **#{ticket_number:04d}** created: {ticket_channel.mention}", ephemeral=True)

        embed = discord.Embed(
            title=f"🎟️ Support Ticket #{ticket_number:04d}",
            description=f"Opened by {interaction.user.mention}",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        if category_choice:
            embed.add_field(name="📂 Department", value=category_choice, inline=False)
        if problem_desc:
            embed.add_field(name="📝 Problem", value=problem_desc, inline=False)

        embed.add_field(
            name="Options",
            value="🔒 Close Ticket\n🗑️ Delete Ticket (Admin only)\n📑 Export Transcript",
            inline=False
        )

        class TicketOptions(discord.ui.View):
            def __init__(self, cog, user, channel, conf, number):
                super().__init__(timeout=None)
                self.cog = cog
                self.user = user
                self.channel = channel
                self.conf = conf
                self.number = number

            @discord.ui.button(label="🔒 Close Ticket", style=discord.ButtonStyle.blurple, custom_id="close_ticket")
            async def close_ticket(self, itx: discord.Interaction, button: discord.ui.Button):
                closed_cat = discord.utils.get(itx.guild.categories, id=self.conf["closed_category"])
                if not closed_cat:
                    await itx.response.send_message("❌ Closed category not found.", ephemeral=True)
                    return
                await self.channel.edit(category=closed_cat)
                await itx.response.send_message(f"✅ Ticket #{self.number:04d} closed.", ephemeral=True)

            @discord.ui.button(label="🗑️ Delete Ticket", style=discord.ButtonStyle.red, custom_id="delete_ticket")
            async def delete_ticket(self, itx: discord.Interaction, button: discord.ui.Button):
                if not itx.user.guild_permissions.administrator:
                    await itx.response.send_message("❌ Only admins can delete tickets.", ephemeral=True)
                    return
                await itx.response.send_message(f"🗑️ Ticket #{self.number:04d} will be deleted in 5 seconds...", ephemeral=True)
                await asyncio.sleep(5)
                await self.channel.delete()

            @discord.ui.button(label="📑 Export Transcript", style=discord.ButtonStyle.gray, custom_id="export_ticket")
            async def export_ticket(self, itx: discord.Interaction, button: discord.ui.Button):
                file_path = await self.cog.export_transcript(self.channel, self.number)
                file = discord.File(file_path, filename=os.path.basename(file_path))
                await itx.response.send_message(f"📑 Transcript for ticket #{self.number:04d} exported:", file=file, ephemeral=True)

        await ticket_channel.send(
            content=f"{interaction.user.mention} Welcome to your ticket!",
            embed=embed,
            view=TicketOptions(self, interaction.user, ticket_channel, conf, ticket_number)
        )

    # ---------------- Transcript Export ----------------
    async def export_transcript(self, channel: discord.TextChannel, ticket_number: int) -> str:
        self.ensure_files()
        messages = []
        async for msg in channel.history(limit=None, oldest_first=True):
            messages.append({
                "author": str(msg.author),
                "content": msg.content,
                "created_at": msg.created_at.isoformat()
            })

        file_path = os.path.join(
            TRANSCRIPT_DIR, f"ticket_{ticket_number:04d}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.json"
        )
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(messages, f, indent=4)

        return file_path


# ---------------- Ticket Modal ----------------
class TicketModal(discord.ui.Modal, title="🎫 Create a Support Ticket"):
    category_choice = discord.ui.TextInput(
        label="Department / Category",
        placeholder="Example: Billing, Support, Report...",
        required=False,
        max_length=100
    )
    problem_desc = discord.ui.TextInput(
        label="Describe your problem",
        style=discord.TextStyle.paragraph,
        placeholder="Write details here...",
        required=False,
        max_length=1000
    )

    def __init__(self, cog, user):
        super().__init__()
        self.cog = cog
        self.user = user

    async def on_submit(self, interaction: discord.Interaction):
        await self.cog.handle_ticket_creation(interaction, str(self.category_choice), str(self.problem_desc))


# ---------------- Setup Cog ----------------
async def setup(bot):
    await bot.add_cog(TicketSystem(bot))
    print("Loaded ticketsetup command")