import discord
from discord.ext import commands
from discord import app_commands
import os
import json
import asyncio
from datetime import datetime

SETUP_FILE = "ticket_setup.json"
TRANSCRIPT_DIR = "transcripts"


# ---------------- Ticket Modal ----------------
class TicketModal(discord.ui.Modal, title="🎫 Create a Support Ticket"):
    category_choice = discord.ui.TextInput(
        label="Department / Category",
        placeholder="Billing, Support, Report...",
        required=False,
        max_length=100
    )
    problem_desc = discord.ui.TextInput(
        label="Describe your problem",
        style=discord.TextStyle.paragraph,
        placeholder="Describe your issue here...",
        required=False,
        max_length=1000
    )

    def __init__(self, cog, user):
        super().__init__()
        self.cog = cog
        self.user = user

    async def on_submit(self, interaction: discord.Interaction):
        await self.cog.handle_ticket_creation(interaction, str(self.category_choice), str(self.problem_desc))


# ---------------- Ticket Panel View ----------------
class TicketPanelView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label="🎫 Create Ticket", style=discord.ButtonStyle.green, custom_id="create_ticket")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = TicketModal(self.cog, interaction.user)
        await interaction.response.send_modal(modal)


# ---------------- Ticket Controls View ----------------
class TicketControlsView(discord.ui.View):
    def __init__(self, cog, ticket_info, guild_conf):
        super().__init__(timeout=None)
        self.cog = cog
        self.ticket_info = ticket_info
        self.guild_conf = guild_conf

    async def refresh_embed(self, channel: discord.TextChannel):
        embed = discord.Embed(
            title=f"🎟️ Support Ticket #{self.ticket_info['number']:04d}",
            description=f"Opened by <@{self.ticket_info['creator_id']}>",
            color=discord.Color.green() if self.ticket_info['status'] == "open" else discord.Color.greyple(),
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Status", value=self.ticket_info['status'].capitalize(), inline=True)
        embed.add_field(
            name="Options",
            value="🔒 Close / 🟢 Open / 🗑 Delete / 📑 Export Transcript",
            inline=False
        )
        try:
            msg = await channel.fetch_message(self.ticket_info["message_id"])
            await msg.edit(embed=embed, view=self)
        except discord.NotFound:
            new_msg = await channel.send(embed=embed, view=self)
            self.ticket_info["message_id"] = new_msg.id
            self.cog.save_setup()

    @discord.ui.button(label="🔒 Close Ticket", style=discord.ButtonStyle.blurple, custom_id="close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.ticket_info['status'] == "closed":
            await interaction.response.send_message("❌ Ticket is already closed.", ephemeral=True)
            return

        closed_cat = discord.utils.get(interaction.guild.categories, id=self.guild_conf["closed_category"])
        if not closed_cat:
            await interaction.response.send_message("❌ Closed category not found.", ephemeral=True)
            return

        await interaction.channel.edit(category=closed_cat)
        self.ticket_info['status'] = "closed"
        self.cog.save_setup()
        await self.refresh_embed(interaction.channel)
        await interaction.response.send_message(f"✅ Ticket #{self.ticket_info['number']:04d} closed.", ephemeral=True)

    @discord.ui.button(label="🟢 Open Ticket", style=discord.ButtonStyle.green, custom_id="open_ticket")
    async def open_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.ticket_info['status'] == "open":
            await interaction.response.send_message("❌ Ticket is already open.", ephemeral=True)
            return

        open_cat = discord.utils.get(interaction.guild.categories, id=self.guild_conf["open_category"])
        if not open_cat:
            await interaction.response.send_message("❌ Open category not found.", ephemeral=True)
            return

        await interaction.channel.edit(category=open_cat)
        self.ticket_info['status'] = "open"
        self.cog.save_setup()
        await self.refresh_embed(interaction.channel)
        await interaction.response.send_message(f"✅ Ticket #{self.ticket_info['number']:04d} reopened.", ephemeral=True)

    @discord.ui.button(label="🗑 Delete Ticket", style=discord.ButtonStyle.red, custom_id="delete_ticket")
    async def delete_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Only admins can delete tickets.", ephemeral=True)
            return

        await interaction.response.send_message(f"🗑 Ticket #{self.ticket_info['number']:04d} will be deleted in 5s...", ephemeral=True)
        await asyncio.sleep(5)
        del self.cog.config[str(interaction.guild.id)]["tickets"][str(interaction.channel.id)]
        self.cog.save_setup()
        await interaction.channel.delete()

    @discord.ui.button(label="📑 Export Transcript", style=discord.ButtonStyle.gray, custom_id="export_ticket")
    async def export_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        file_path = await self.cog.export_transcript(interaction.channel, self.ticket_info['number'])
        file = discord.File(file_path, filename=os.path.basename(file_path))
        await interaction.response.send_message(f"📑 Transcript for ticket #{self.ticket_info['number']:04d} exported:", file=file, ephemeral=True)


# ---------------- Ticket System Cog ----------------
class TicketSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ensure_files()
        self.config = self.load_setup()
        self.bot.loop.create_task(self.recover_panels_and_tickets())

    # ---------------- File Handling ----------------
    def ensure_files(self):
        if not os.path.exists(SETUP_FILE):
            with open(SETUP_FILE, "w", encoding="utf-8") as f:
                json.dump({}, f, indent=4)
        if not os.path.exists(TRANSCRIPT_DIR):
            os.makedirs(TRANSCRIPT_DIR)

    def load_setup(self):
        try:
            return json.load(open(SETUP_FILE, "r", encoding="utf-8"))
        except Exception:
            return {}

    def save_setup(self):
        with open(SETUP_FILE, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=4)

    # ---------------- Setup Command ----------------
    @app_commands.command(name="ticketsetup", description="Setup the ticket system for this server")
    @app_commands.describe(
        channel="Channel where ticket panel will be posted",
        open_category="Category for open tickets",
        closed_category="Category for closed tickets",
        image_url="Optional banner image for the ticket panel"
    )
    async def ticketsetup(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        open_category: discord.CategoryChannel,
        closed_category: discord.CategoryChannel,
        image_url: str = None
    ):
        guild_id = str(interaction.guild.id)
        embed = discord.Embed(
            title="🎟️ Support Ticket System",
            description="Need help? Click the button below to open a private support ticket with our staff team.",
            color=discord.Color.blue()
        )
        embed.set_image(url=image_url or "https://i.imgur.com/En7X8oU.png")
        embed.set_footer(text=f"{interaction.guild.name} • Ticket System")

        panel_msg = await channel.send(embed=embed, view=TicketPanelView(self))

        self.config[guild_id] = {
            "ticket_channel": channel.id,
            "open_category": open_category.id,
            "closed_category": closed_category.id,
            "image_url": image_url or "https://i.imgur.com/En7X8oU.png",
            "ticket_counter": 0,
            "panel_message_id": panel_msg.id,
            "tickets": {}  # channel_id: ticket info
        }
        self.save_setup()
        await interaction.response.send_message(f"✅ Ticket system configured. Panel sent to {channel.mention}.", ephemeral=True)

    # ---------------- Handle Ticket Creation ----------------
    async def handle_ticket_creation(self, interaction: discord.Interaction, category_choice: str, problem_desc: str):
        guild_id = str(interaction.guild.id)
        conf = self.config.get(guild_id)
        if not conf:
            await interaction.response.send_message("❌ Ticket system not configured.", ephemeral=True)
            return

        category = discord.utils.get(interaction.guild.categories, id=conf["open_category"])
        if not category:
            await interaction.response.send_message("❌ Open category not found.", ephemeral=True)
            return

        ticket_number = conf.get("ticket_counter", 0) + 1
        self.config[guild_id]["ticket_counter"] = ticket_number

        ticket_name = f"ticket-{ticket_number:04d}"
        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True),
            interaction.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True)
        }

        ticket_channel = await interaction.guild.create_text_channel(
            name=ticket_name, category=category, overwrites=overwrites
        )

        # Save ticket info with message_id placeholder
        self.config[guild_id]["tickets"][str(ticket_channel.id)] = {
            "creator_id": interaction.user.id,
            "number": ticket_number,
            "status": "open",
            "message_id": None
        }
        self.save_setup()

        embed = discord.Embed(
            title=f"🎟️ Support Ticket #{ticket_number:04d}",
            description=f"Opened by {interaction.user.mention}",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Status", value="Open", inline=True)
        embed.add_field(
            name="Options",
            value="🔒 Close / 🟢 Open / 🗑 Delete / 📑 Export Transcript",
            inline=False
        )

        view = TicketControlsView(self, self.config[guild_id]["tickets"][str(ticket_channel.id)], conf)
        msg = await ticket_channel.send(content=f"{interaction.user.mention} Welcome to your ticket!", embed=embed, view=view)

        # Save message ID
        self.config[guild_id]["tickets"][str(ticket_channel.id)]["message_id"] = msg.id
        self.save_setup()
        await interaction.response.send_message(f"🎫 Ticket **#{ticket_number:04d}** created: {ticket_channel.mention}", ephemeral=True)

    # ---------------- Export Transcript ----------------
    async def export_transcript(self, channel: discord.TextChannel, ticket_number: int) -> str:
        self.ensure_files()
        messages = []
        async for msg in channel.history(limit=None, oldest_first=True):
            messages.append({
                "author": str(msg.author),
                "content": msg.content,
                "created_at": msg.created_at.isoformat()
            })

        file_path = os.path.join(
            TRANSCRIPT_DIR, f"ticket_{ticket_number:04d}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.json"
        )
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(messages, f, indent=4)
        return file_path

    # ---------------- Recover Panels & Tickets ----------------
    async def recover_panels_and_tickets(self):
        await self.bot.wait_until_ready()
        for guild_id, conf in self.config.items():
            guild = self.bot.get_guild(int(guild_id))
            if not guild:
                continue

            # Fix ticket panel
            channel = guild.get_channel(conf["ticket_channel"])
            if channel:
                panel_msg_id = conf.get("panel_message_id")
                embed = discord.Embed(
                    title="🎟️ Support Ticket System",
                    description="Need help? Click the button below to open a private support ticket with our staff team.",
                    color=discord.Color.blue()
                )
                embed.set_image(url=conf.get("image_url") or "https://i.imgur.com/En7X8oU.png")
                embed.set_footer(text=f"{guild.name} • Ticket System")

                try:
                    if panel_msg_id:
                        msg = await channel.fetch_message(panel_msg_id)
                        await msg.edit(embed=embed, view=TicketPanelView(self))
                    else:
                        new_msg = await channel.send(embed=embed, view=TicketPanelView(self))
                        self.config[guild_id]["panel_message_id"] = new_msg.id
                        self.save_setup()
                except discord.NotFound:
                    new_msg = await channel.send(embed=embed, view=TicketPanelView(self))
                    self.config[guild_id]["panel_message_id"] = new_msg.id
                    self.save_setup()

            # Recover existing tickets
            for ticket_channel_id, ticket_info in conf.get("tickets", {}).items():
                ticket_channel = guild.get_channel(int(ticket_channel_id))
                if not ticket_channel:
                    continue

                view = TicketControlsView(self, ticket_info, conf)

                if ticket_info.get("message_id"):
                    try:
                        msg = await ticket_channel.fetch_message(ticket_info["message_id"])
                        embed = discord.Embed(
                            title=f"🎟️ Support Ticket #{ticket_info['number']:04d}",
                            description=f"Opened by <@{ticket_info['creator_id']}>",
                            color=discord.Color.green() if ticket_info['status'] == "open" else discord.Color.greyple(),
                            timestamp=datetime.utcnow()
                        )
                        embed.add_field(name="Status", value=ticket_info['status'].capitalize(), inline=True)
                        embed.add_field(
                            name="Options",
                            value="🔒 Close / 🟢 Open / 🗑 Delete / 📑 Export Transcript",
                            inline=False
                        )
                        await msg.edit(embed=embed, view=view)
                    except discord.NotFound:
                        # Message deleted, send a new one
                        embed = discord.Embed(
                            title=f"🎟️ Support Ticket #{ticket_info['number']:04d}",
                            description=f"Opened by <@{ticket_info['creator_id']}>",
                            color=discord.Color.green() if ticket_info['status'] == "open" else discord.Color.greyple(),
                            timestamp=datetime.utcnow()
                        )
                        embed.add_field(name="Status", value=ticket_info['status'].capitalize(), inline=True)
                        embed.add_field(
                            name="Options",
                            value="🔒 Close / 🟢 Open / 🗑 Delete / 📑 Export Transcript",
                            inline=False
                        )
                        new_msg = await ticket_channel.send(embed=embed, view=view)
                        ticket_info["message_id"] = new_msg.id
                        self.save_setup()


# ---------------- Setup Cog ----------------
async def setup(bot):
    await bot.add_cog(TicketSystem(bot))
    print("Loaded ticketsetup command")
