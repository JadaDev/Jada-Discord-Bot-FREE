import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
from datetime import datetime, timezone

class TimezoneCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="timezone", description="Get current time in any city")
    @app_commands.describe(city="City name (e.g., London, New York, Tokyo)")
    async def timezone_command(self, interaction: discord.Interaction, city: str):
        await interaction.response.defer()
        try:
            # TimeAPI endpoint
            api_url = "https://timeapi.io/api/Time/current/zone"
            headers = {"User-Agent": "Mozilla/5.0"}

            # City to timezone mapping
            city_mappings = {
                "london": "Europe/London",
                "new york": "America/New_York",
                "tokyo": "Asia/Tokyo",
                "paris": "Europe/Paris",
                "sydney": "Australia/Sydney",
                "mumbai": "Asia/Kolkata",
                "los angeles": "America/Los_Angeles",
                "chicago": "America/Chicago",
                "berlin": "Europe/Berlin",
                "dubai": "Asia/Dubai",
                "toronto": "America/Toronto",
                "mexico city": "America/Mexico_City",
                "singapore": "Asia/Singapore"
            }

            city_lower = city.lower()
            timezone_name = city_mappings.get(city_lower)

            if not timezone_name:
                embed = discord.Embed(
                    title="❌ City Not Found",
                    description=f"Could not find timezone for **{city}**.\n"
                                f"Try major cities like `London`, `New York`, `Tokyo`.",
                    color=discord.Color.red()
                )
                embed.set_footer(text="Made by JadaDev • Timezone Command")
                await interaction.followup.send(embed=embed)
                return

            # Request current time from TimeAPI
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{api_url}?timeZone={timezone_name}", headers=headers) as resp:
                    if resp.status != 200:
                        raise Exception("Could not retrieve time data.")
                    data = await resp.json()

            # Parse datetime safely
            dt_str = data.get("dateTime")
            if not dt_str:
                raise Exception("Invalid datetime received from API.")

            try:
                dt = datetime.fromisoformat(dt_str)
                # Ensure timezone-aware (fixes naive vs aware error)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            except Exception:
                raise Exception("Failed to parse datetime from API.")

            # Format outputs
            time_12hr = dt.strftime("%I:%M:%S %p")
            time_24hr = dt.strftime("%H:%M:%S")
            date_str = dt.strftime("%A, %B %d, %Y")
            tz_name = data.get("timeZone", timezone_name)
            dst = "Yes" if data.get("dstActive", False) else "No"

            # UTC comparison
            utc_now = datetime.now(timezone.utc)
            hours_diff = round((dt - utc_now).total_seconds() / 3600, 1)
            comparison = f"{hours_diff:+.1f} hours relative to UTC"

            display_city = tz_name.split("/")[-1].replace("_", " ")

            embed = discord.Embed(
                title="🗺️ Current Time",
                color=discord.Color.blue(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="Location", value=display_city, inline=True)
            embed.add_field(name="Timezone", value=tz_name, inline=True)
            embed.add_field(name="12-Hour Format", value=f"🕐 {time_12hr}", inline=True)
            embed.add_field(name="24-Hour Format", value=f"🕐 {time_24hr}", inline=True)
            embed.add_field(name="Daylight Saving", value=dst, inline=True)
            embed.add_field(name="Date", value=f"📅 {date_str}", inline=False)
            embed.add_field(name="UTC Comparison", value=comparison, inline=True)
            embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
            embed.set_footer(text="Made by JadaDev • Timezone Command • Data from TimeAPI.io")

            await interaction.followup.send(embed=embed)

        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: **{str(e)}**",
                color=discord.Color.red()
            )
            embed.set_footer(text="Made by JadaDev • Timezone Command")
            await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(TimezoneCommand(bot))
    print("Loaded timezone command")
