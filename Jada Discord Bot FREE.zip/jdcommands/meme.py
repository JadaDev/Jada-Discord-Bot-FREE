import discord
from discord.ext import commands
from discord import app_commands
import random
import aiohttp
from typing import Optional

class MemeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="meme", description="Get a random meme")
    @app_commands.describe(subreddit="Meme subreddit (optional, defaults to r/memes)")
    async def meme_command(self, interaction: discord.Interaction, subreddit: Optional[str] = None):
        """
        Fetch random meme from Reddit (no API key required)
        """
        try:
            # Set default subreddit and validate
            target_subreddit = subreddit or "memes"

            # Remove 'r/' prefix if present
            if target_subreddit.startswith('r/'):
                target_subreddit = target_subreddit[2:]

            # Limit subreddit to prevent abuse
            allowed_subreddits = ['memes', 'dankmemes', 'funny', 'wholesomememes']
            if target_subreddit not in allowed_subreddits:
                target_subreddit = "memes"

            # Reddit JSON API endpoint
            url = f"https://www.reddit.com/r/{target_subreddit}/hot.json?limit=50"

            async with aiohttp.ClientSession() as session:
                # Use Reddit's JSON API (no API key needed)
                headers = {
                    'User-Agent': 'DiscordBot/1.0 (by /u/yourusername)'
                }

                async with session.get(url, headers=headers) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message(f"❌ Could not fetch memes from r/{target_subreddit}", ephemeral=True)
                        return

                    data = await resp.json()

            # Extract posts from response
            posts = []
            if 'data' in data and 'children' in data['data']:
                posts = [post['data'] for post in data['data']['children'] if post['data'].get('url')]

            if not posts:
                await interaction.response.send_message("❌ No memes available right now!", ephemeral=True)
                return

            # Get random post
            post = random.choice(posts)

            # Get image URL (prefer Reddit hosted images)
            image_url = None
            if 'url' in post:
                url = post['url']
                # Check for Reddit hosted image
                if url.startswith('https://i.redd.it/'):
                    image_url = url

            # Get title and author
            title = post.get('title', 'Untitled Meme')
            author = post.get('author', 'Unknown')

            # Create embed
            embed = discord.Embed(
                title=title[:256],  # Discord title limit
                color=discord.Color.dark_purple(),
                timestamp=interaction.created_at
            )

            if image_url:
                embed.set_image(url=image_url)

            # Add some stats
            score = post.get('score', 0)
            num_comments = post.get('num_comments', 0)

            embed.set_footer(
                text=f"Made by JadaDev • 👍 {score} upvotes • 💬 {num_comments} comments • r/{target_subreddit} • u/{author}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(MemeCommand(bot))
    print('Loaded meme command')
