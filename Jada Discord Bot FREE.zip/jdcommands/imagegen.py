import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import random
from typing import Optional

class ImageGenCommand(commands.Cog):
    """
    Image generator using stable, no-API-key public endpoints.
    Uses Openverse, Flickr public feed, and Picsum for consistent images.
    """
    def __init__(self, bot):
        self.bot = bot
        self.W = 800
        self.H = 600

    @app_commands.command(
        name="imagegen",
        description="Generate random images from various categories (no API keys required)"
    )
    @app_commands.describe(category="Category of image to generate")
    @app_commands.choices(category=[
        app_commands.Choice(name="Random/Abstract", value="random"),
        app_commands.Choice(name="Nature", value="nature"),
        app_commands.Choice(name="Animals", value="animals"),
        app_commands.Choice(name="Space", value="space"),
        app_commands.Choice(name="City/Architecture", value="city"),
        app_commands.Choice(name="Food", value="food"),
        app_commands.Choice(name="Technology", value="tech"),
        app_commands.Choice(name="Art", value="art")
    ])
    async def imagegen_command(self, interaction: discord.Interaction, category: str = "random"):
        await interaction.response.defer()
        try:
            # Generate a seed for consistent image results
            seed = random.randint(1, 999999)
            w, h = self.W, self.H

            # Mapping categories to stable endpoints
            sources = {
                "random": [
                    lambda: f"https://picsum.photos/seed/random{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=random&size=large",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=random",
                ],
                "nature": [
                    lambda: f"https://picsum.photos/seed/nature{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=nature,landscape&size=large",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=nature,landscape",
                ],
                "animals": [
                    lambda: f"https://picsum.photos/seed/animals{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=animals,pets&size=large",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=animals,pets",
                    lambda: f"https://placekitten.com/{w}/{h}",
                    lambda: f"https://cataas.com/cat?width={w}&height={h}&rand={seed}",
                ],
                "space": [
                    lambda: f"https://picsum.photos/seed/space{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=space,galaxy,stars&size=large",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=space,galaxy,stars",
                ],
                "city": [
                    lambda: f"https://picsum.photos/seed/city{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=city,architecture&size=large",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=city,architecture",
                ],
                "food": [
                    lambda: f"https://picsum.photos/seed/food{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=food,meal&size=large",
                    lambda: f"https://foodish-api.herokuapp.com/api/",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=food,meal",
                ],
                "tech": [
                    lambda: f"https://picsum.photos/seed/tech{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=technology,gadgets&size=large",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=technology,gadgets",
                ],
                "art": [
                    lambda: f"https://picsum.photos/seed/art{seed}/{w}/{h}",
                    lambda: f"https://api.openverse.engineering/v1/images/?q=art,painting&size=large",
                    lambda: f"https://collectionapi.metmuseum.org/public/collection/v1/objects/{random.randint(1, 10000)}",
                    lambda: f"https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=art,painting",
                ],
            }

            # Choose endpoints for category
            endpoints = sources.get(category, sources["random"])

            # Try a few times selecting random endpoints
            image_url: Optional[str] = None
            attempts = min(len(endpoints), 5)
            for _ in range(attempts):
                candidate = random.choice(endpoints)()
                image_url = await self._resolve_image_url(candidate)
                if image_url:
                    break

            # Final fallback (very reliable)
            if not image_url:
                image_url = f"https://picsum.photos/seed/fallback{seed}/{w}/{h}"

            category_names = {
                "random": "Random/Abstract",
                "nature": "Nature & Landscapes",
                "animals": "Animals & Pets",
                "space": "Space & Universe",
                "city": "City & Architecture",
                "food": "Food & Cooking",
                "tech": "Technology",
                "art": "Art & Creative"
            }
            category_display = category_names.get(category, "Random")

            embed = discord.Embed(
                title="🖼️ Image Generated (no API key)",
                description=f"**Category:** {category_display}",
                color=discord.Color.blurple(),
                timestamp=interaction.created_at
            )
            embed.set_image(url=image_url)
            embed.add_field(name="Resolution", value=f"{w} x {h}", inline=True)
            embed.add_field(name="Source", value="Stable public image endpoints (Openverse, Flickr, Picsum)", inline=True)
            embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)

            fun_facts = [
                "Openverse provides open-licensed images from multiple sources, ensuring stability.",
                "Flickr’s public feed offers category-specific images without an API key.",
                "Picsum Photos with seeds ensures consistent images for the same URL.",
                "No API keys means easy access to high-quality images for everyone."
            ]
            embed.add_field(name="💡 Fun Fact", value=random.choice(fun_facts), inline=False)
            embed.set_footer(text='Made by JadaDev • ImageGen (no-key)')

            await interaction.followup.send(embed=embed)

        except Exception as exc:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {exc}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed)

    async def _resolve_image_url(self, url: str) -> Optional[str]:
        """
        Resolve the provided URL into a direct image URL.
        - Handles direct images (Picsum, PlaceKitten).
        - Parses JSON from Openverse, Flickr, Foodish, and Met Museum APIs.
        """
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, allow_redirects=True) as resp:
                    if resp.status != 200:
                        return None

                    content_type = (resp.headers.get("Content-Type") or "").lower()

                    if content_type.startswith("image/"):
                        return str(resp.url)

                    # Handle JSON responses (Openverse, Flickr, Foodish, Met Museum)
                    try:
                        data = await resp.json()
                        if isinstance(data, dict):
                            # Openverse API
                            if "results" in data and data["results"]:
                                result = random.choice(data["results"])
                                if "url" in result and result["url"].startswith("http"):
                                    return result["url"]
                            # Flickr public feed
                            if "items" in data and data["items"]:
                                item = random.choice(data["items"])
                                if "media" in item and "m" in item["media"]:
                                    return item["media"]["m"].replace("_m", "")  # Get full-size image
                            # Foodish API
                            if "image" in data:
                                return data["image"]
                            # Met Museum API
                            if "primaryImage" in data and data["primaryImage"]:
                                return data["primaryImage"]
                            # Other common keys
                            for key in ("url", "src", "link", "photo"):
                                val = data.get(key)
                                if isinstance(val, str) and val.startswith("http"):
                                    return val
                        if isinstance(data, str) and data.startswith("http"):
                            return data
                    except Exception:
                        # Fallback: check if URL looks like an image
                        final = str(resp.url)
                        if final.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".webp")):
                            return final

            return None
        except Exception:
            return None


async def setup(bot):
    await bot.add_cog(ImageGenCommand(bot))
    print("Loaded imagegen (no-key) command")