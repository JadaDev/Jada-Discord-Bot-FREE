import discord
from discord.ext import commands
from discord import app_commands

class KickCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.describe(
        member="The member to kick",
        reason="Reason for kicking the member"
    )
    async def kick_command(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """
        Kick command with proper permission checks
        """
        try:
            # Check if the user has kick permissions
            if not interaction.user.guild_permissions.kick_members:
                await interaction.response.send_message("❌ You don't have permission to kick members!", ephemeral=True)
                return
            
            # Check if the bot has kick permissions
            if not interaction.guild.me.guild_permissions.kick_members:
                await interaction.response.send_message("❌ I don't have permission to kick members!", ephemeral=True)
                return
            
            # Check role hierarchy
            if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
                await interaction.response.send_message("❌ You cannot kick someone with a higher or equal role!", ephemeral=True)
                return
            
            if member.top_role >= interaction.guild.me.top_role:
                await interaction.response.send_message("❌ I cannot kick someone with a higher or equal role than me!", ephemeral=True)
                return
            
            # Cannot kick the server owner
            if member == interaction.guild.owner:
                await interaction.response.send_message("❌ Cannot kick the server owner!", ephemeral=True)
                return
            
            # Perform the kick
            await member.kick(reason=f"Kicked by {interaction.user} - {reason}")
            
            # Create embed response
            embed = discord.Embed(
                title="👢 Member Kicked",
                color=discord.Color.orange(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="Member", value=f"{member.mention} ({member})", inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)
            
            # Try to DM the kicked member
            try:
                dm_embed = discord.Embed(
                    title="You have been kicked",
                    description=f"You were kicked from {interaction.guild.name}",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
                dm_embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled or blocked the bot
                
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to kick this member!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(KickCommand(bot))
    print('Loaded kick command')
