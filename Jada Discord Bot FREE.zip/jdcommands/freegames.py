import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
from datetime import datetime

class FreegamesCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="freegames", description="Lists current free games available on Steam, Epic Games Store, and other platforms.")
    async def freegames_command(self, interaction: discord.Interaction):
        """
        Lists current free games available on Steam, Epic Games Store, and other platforms.
        """
        try:
            # Using FreeToGame API (free, no API key required)
            async with aiohttp.ClientSession() as session:
                async with session.get('https://www.freetogame.com/api/games?platform=pc') as response:
                    if response.status != 200:
                        raise Exception('Failed to fetch data from FreeToGame API')
                    data = await response.json()

            if not data or len(data) == 0:
                await interaction.response.send_message("Could not fetch free games data right now. Please try again later.")
                return

            # Get recent games (sorted by release date)
            recent_games = [game for game in data if game.get('release_date')]
            def sort_key(game):
                if game['release_date'] == 'TBA':
                    return datetime.min
                try:
                    return datetime.fromisoformat(game['release_date'])
                except ValueError:
                    return datetime.min
            recent_games.sort(key=sort_key, reverse=True)
            recent_games = recent_games[:8]

            # Also get popular games (assuming first ones are popular)
            popular_games = [game for game in data if game.get('thumbnail')][:5]

            free_games_embed = discord.Embed(
                color=0x00FF00,
                title='🎮 Free Games Available Now',
                description='Current free-to-play games across multiple platforms',
                timestamp=interaction.created_at
            )
            free_games_embed.set_footer(text='Made by JadaDev • Powered by FreeToGame API', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            # Add recently released free games
            if recent_games:
                recent_games_text = ''
                for game in recent_games[:5]:
                    platform = '💻' if game.get('platform') == 'PC (Windows)' else '🌐' if game.get('platform') == 'Web Browser' else '🎮'
                    genre = game.get('genre') or 'Unknown'
                    recent_games_text += f"{platform} **{game['title']}**\n"
                    recent_games_text += f"   └ {genre} • Released: {game['release_date']}\n"
                    recent_games_text += f"   └ [Play Now]({game['game_url']})\n\n"

                free_games_embed.add_field(name='🆕 Recently Released Free Games', value=recent_games_text or 'None', inline=False)

            # Add popular games
            if popular_games:
                popular_games_text = ''
                for game in popular_games[:4]:
                    platform = '💻' if game.get('platform') == 'PC (Windows)' else '🌐' if game.get('platform') == 'Web Browser' else '🎮'
                    genre = game.get('genre') or 'Unknown'
                    desc = game.get('short_description')[:60] + '...' if game.get('short_description') else 'No description'
                    popular_games_text += f"{platform} **{game['title']}**\n"
                    popular_games_text += f"   └ {genre} • {desc}\n"
                    popular_games_text += f"   └ [Play Now]({game['game_url']})\n\n"

                free_games_embed.add_field(name='🔥 Popular Free Games', value=popular_games_text or 'None', inline=False)

            # Add additional resources
            resources_text = """
            🎮 **Steam Free Games**: [Store Page](https://store.steampowered.com/genre/Free%20to%20Play/)
            🎮 **Epic Games Free**: [Weekly Free Games](https://store.epicgames.com/en-US/free-games)
            🎮 **GOG Free Games**: [Free Games Collection](https://www.gog.com/en/games?priceRange=0,0)
            🎮 **Itch.io Free**: [Free Games](https://itch.io/games/free)
            📱 **Mobile Free**: Google Play & App Store
            """
            free_games_embed.add_field(name='🔗 More Free Games Platforms', value=resources_text, inline=False)

            # Pro tip
            free_games_embed.add_field(name='💡 Pro Tip', value='Check Epic Games Store weekly for rotating free games!\nSteam also offers free weekends and permanent free games.', inline=False)

            # Add a featured game image if available
            if recent_games and recent_games[0].get('thumbnail'):
                free_games_embed.set_image(url=recent_games[0]['thumbnail'])

            await interaction.response.send_message(embed=free_games_embed)

            # Send a follow-up message with game categories
            categories_embed = discord.Embed(
                color=0x0099FF,
                title='🎯 Free Games by Category',
                description='Popular free game categories you can explore:'
            )
            categories_embed.add_field(name='⚔️ Battle Royale', value='Fortnite, Apex Legends, Warzone', inline=True)
            categories_embed.add_field(name='🎯 FPS', value='Valorant, CS2, Team Fortress 2', inline=True)
            categories_embed.add_field(name='🏆 MOBA', value='League of Legends, Dota 2, Smite', inline=True)
            categories_embed.add_field(name='🚗 Racing', value='Trackmania Nations, World of Speed', inline=True)
            categories_embed.add_field(name='⚔️ MMO', value='World of Warcraft (Starter), SWTOR', inline=True)
            categories_embed.add_field(name='🎮 Indie', value='Check itch.io for unique indie games', inline=True)
            categories_embed.set_footer(text='Made by JadaDev', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.followup.send(embed=categories_embed)

        except Exception as e:
            print(f"Error fetching free games data: {e}")

            # Fallback with manual curated list
            fallback_embed = discord.Embed(
                color=0x00FF00,
                title='🎮 Free Games Available Now',
                description='Popular free-to-play games (manually curated)',
                timestamp=interaction.created_at
            )
            fallback_embed.add_field(
                name='⚔️ Battle Royale',
                value='• [Fortnite](https://www.epicgames.com/fortnite)\n• [Apex Legends](https://www.ea.com/games/apex-legends)\n• [Call of Duty: Warzone](https://www.callofduty.com/warzone)',
                inline=True
            )
            fallback_embed.add_field(
                name='🎯 Competitive FPS',
                value='• [Valorant](https://playvalorant.com)\n• [CS2](https://store.steampowered.com/app/730)\n• [Team Fortress 2](https://store.steampowered.com/app/440)',
                inline=True
            )
            fallback_embed.add_field(
                name='🏆 MOBA',
                value='• [League of Legends](https://www.leagueoflegends.com)\n• [Dota 2](https://store.steampowered.com/app/570)\n• [Smite](https://store.steampowered.com/app/386360)',
                inline=True
            )
            fallback_embed.add_field(
                name='🔗 Free Game Stores',
                value='• [Steam Free Games](https://store.steampowered.com/genre/Free%20to%20Play/)\n• [Epic Games Free](https://store.epicgames.com/en-US/free-games)\n• [GOG Free Games](https://www.gog.com/en/games?priceRange=0,0)',
                inline=False
            )
            fallback_embed.set_footer(text='Made by JadaDev', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=fallback_embed)

async def setup(bot):
    await bot.add_cog(FreegamesCommand(bot))
    print('Loaded freegames command')
