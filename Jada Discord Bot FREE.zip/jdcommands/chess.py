import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
from datetime import datetime

class ChessCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="chess", description="Fetches chess player stats from Chess.com and recent match history.")
    @app_commands.describe(username="Chess.com username to look up")
    async def chess_command(self, interaction: discord.Interaction, username: str):
        """
        Fetch chess player profile and game statistics
        """
        tag = f"<@{interaction.user.id}>"

        if not username:
            await interaction.response.send_message(f"{tag} Please specify a chess username!")
            return

        username = username.lower().strip()

        try:
            # Chess.com API base URL
            base_url = "https://api.chess.com/pub/player"

            async with aiohttp.ClientSession() as session:
                # Get player profile
                async with session.get(f"{base_url}/{username}") as resp:
                    if resp.status == 404:
                        # Try Lichess fallback
                        await self._lichess_fallback(interaction, username, tag)
                        return
                    elif resp.status != 200:
                        await interaction.response.send_message("❌ Could not access Chess.com!", ephemeral=True)
                        return

                    profile_data = await resp.json()

                # Get player stats
                async with session.get(f"{base_url}/{username}/stats") as resp:
                    stats_data = await resp.json() if resp.status == 200 else None

                # Get recent games
                current_date = datetime.now()
                year = current_date.year
                month = f"{current_date.month:02d}"

                recent_games = []
                try:
                    async with session.get(f"{base_url}/{username}/games/{year}/{month}") as resp:
                        if resp.status == 200:
                            games_data = await resp.json()
                            recent_games = games_data.get('games', [])[-5:] if games_data.get('games') else []
                except:
                    pass

            # Extract profile information
            player_name = profile_data.get('name', username)
            country = profile_data.get('country', 'Unknown')

            # Convert country code to full name if available
            if country and country.startswith('https://api.chess.com/pub/country/'):
                country_code = country.split('/')[-1].upper()
                country_name = {
                    'US': 'United States',
                    'GB': 'United Kingdom',
                    'DE': 'Germany',
                    'FR': 'France',
                    'IT': 'Italy',
                    'ES': 'Spain',
                    'RU': 'Russia',
                    'JP': 'Japan',
                    'CN': 'China',
                    'IN': 'India',
                    'BR': 'Brazil',
                    'CA': 'Canada',
                    'AU': 'Australia'
                }.get(country_code, country_code)
            else:
                country_name = 'Unknown'

            # Join date
            joined_timestamp = profile_data.get('joined', 0)
            joined_date = datetime.fromtimestamp(joined_timestamp).strftime('%m/%d/%Y') if joined_timestamp else 'Unknown'

            # Last online
            last_online_timestamp = profile_data.get('last_online', 0)
            last_online_date = datetime.fromtimestamp(last_online_timestamp).strftime('%m/%d/%Y') if last_online_timestamp else 'Unknown'

            # Avatar URL
            avatar_url = profile_data.get('avatar')

            # Create embed
            embed = discord.Embed(
                title=f"♟️ {player_name}",
                description=f"Chess.com Profile Statistics",
                color=0x769656,
                url=profile_data.get('url', f"https://chess.com/member/{username}"),
                timestamp=interaction.created_at
            )

            if avatar_url:
                embed.set_thumbnail(url=avatar_url)

            # Add ratings
            rapid_rating = self._format_rating(stats_data, 'chess_rapid')
            blitz_rating = self._format_rating(stats_data, 'chess_blitz')
            bullet_rating = self._format_rating(stats_data, 'chess_bullet')
            embed.add_field(name="🏆 Rapid Rating", value=rapid_rating, inline=True)
            embed.add_field(name="⚡ Blitz Rating", value=blitz_rating, inline=True)
            embed.add_field(name="🏃 Bullet Rating", value=bullet_rating, inline=True)
            embed.add_field(name="📅 Joined", value=joined_date, inline=True)
            embed.add_field(name="🕐 Last Online", value=last_online_date, inline=True)
            embed.add_field(name="🌍 Country", value=country_name, inline=True)

            # Add detailed stats for main time controls
            if stats_data:
                if stats_data.get('chess_rapid') and 'record' in stats_data['chess_rapid']:
                    rapid = stats_data['chess_rapid']
                    embed.add_field(
                        name="🏆 Rapid Stats",
                        value=f"W: {rapid['record']['win'] or 0} | L: {rapid['record']['loss'] or 0} | D: {rapid['record']['draw'] or 0}",
                        inline=True
                    )

                if stats_data.get('chess_blitz') and 'record' in stats_data['chess_blitz']:
                    blitz = stats_data['chess_blitz']
                    embed.add_field(
                        name="⚡ Blitz Stats",
                        value=f"W: {blitz['record']['win'] or 0} | L: {blitz['record']['loss'] or 0} | D: {blitz['record']['draw'] or 0}",
                        inline=True
                    )

                if stats_data.get('chess_bullet') and 'record' in stats_data['chess_bullet']:
                    bullet = stats_data['chess_bullet']
                    embed.add_field(
                        name="🏃 Bullet Stats",
                        value=f"W: {bullet['record']['win'] or 0} | L: {bullet['record']['loss'] or 0} | D: {bullet['record']['draw'] or 0}",
                        inline=True
                    )

            # Add recent games if available
            if recent_games:
                recent_games_text = ''
                for game in recent_games[-3:]:  # Show last 3 games
                    is_white = game['white']['username'].lower() == username
                    opponent = game['black']['username'] if is_white else game['white']['username']
                    result = game['white']['result'] if is_white else game['black']['result']
                    result_emoji = "🟢" if result == 'win' else "🔴" if result in ['checkmated', 'timeout'] else "🟡"
                    recent_games_text += f"{result_emoji} vs {opponent} ({result})\n"

                if recent_games_text:
                    embed.add_field(
                        name="🎮 Recent Games",
                        value=recent_games_text.strip(),
                        inline=False
                    )

            # Add tactics rating if available
            if stats_data and stats_data.get('tactics') and 'highest' in stats_data['tactics']:
                tactics = stats_data['tactics']
                embed.add_field(
                    name="🧩 Tactics Rating",
                    value=f"{tactics['highest'].get('rating', 'N/A')} (Best)",
                    inline=True
                )

            embed.set_footer(
                text="Made by JadaDev • Powered by Chess.com API",
                icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_n0p1KocToJVP_Sw&s"
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

    def _format_rating(self, stats_data, game_type):
        """Format rating string or return 'Unrated'"""
        if not stats_data or not stats_data.get(game_type):
            return 'Unrated'
        rating = stats_data[game_type]
        return f"{rating['last']['rating']} (Best: {rating['best']['rating'] or 'N/A'})"

    async def _lichess_fallback(self, interaction, username, tag):
        """Fallback to Lichess if Chess.com user not found"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://lichess.org/api/user/{username}") as resp:
                    if resp.status != 200:
                        await interaction.response.send_message(f"{tag} Chess player \"{username}\" not found on Chess.com or Lichess. Please check the username and try again.")
                        return

                    lichess_data = await resp.json()

            lichess_embed = discord.Embed(
                title=f"♟️ {lichess_data['username']}",
                description="Lichess Profile Statistics",
                color=0x000000,
                url=f"https://lichess.org/@/{username}",
                timestamp=interaction.created_at
            )

            # Add ratings
            lichess_embed.add_field(
                name="🏆 Classical",
                value=f"{lichess_data['perfs'].get('classical', {}).get('rating', 'Unrated')}" if lichess_data['perfs'].get('classical') else "Unrated",
                inline=True
            )
            lichess_embed.add_field(
                name="🏃 Rapid",
                value=f"{lichess_data['perfs'].get('rapid', {}).get('rating', 'Unrated')}" if lichess_data['perfs'].get('rapid') else "Unrated",
                inline=True
            )
            lichess_embed.add_field(
                name="⚡ Blitz",
                value=f"{lichess_data['perfs'].get('blitz', {}).get('rating', 'Unrated')}" if lichess_data['perfs'].get('blitz') else "Unrated",
                inline=True
            )
            lichess_embed.add_field(
                name="🏃 Bullet",
                value=f"{lichess_data['perfs'].get('bullet', {}).get('rating', 'Unrated')}" if lichess_data['perfs'].get('bullet') else "Unrated",
                inline=True
            )

            # Dates
            joined_date = datetime.fromtimestamp(lichess_data['createdAt'] / 1000).strftime('%m/%d/%Y') if lichess_data.get('createdAt') else 'Unknown'
            seen_date = datetime.fromtimestamp(lichess_data['seenAt'] / 1000).strftime('%m/%d/%Y') if lichess_data.get('seenAt') else 'Unknown'
            lichess_embed.add_field(name="📅 Joined", value=joined_date, inline=True)
            lichess_embed.add_field(name="🕐 Last Seen", value=seen_date, inline=True)

            # Country if available
            if lichess_data.get('profile', {}).get('country'):
                lichess_embed.add_field(name="🌍 Country", value=lichess_data['profile']['country'], inline=True)

            lichess_embed.set_footer(
                text="Made by JadaDev • Powered by Lichess API",
                icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_n0p1KocToJVP_Sw&s"
            )

            await interaction.response.send_message(embed=lichess_embed)

        except Exception as e:
            await interaction.response.send_message(f"{tag} Chess player \"{username}\" not found on Chess.com or Lichess. Please check the username and try again.")

async def setup(bot):
    await bot.add_cog(ChessCommand(bot))
    print('Loaded chess command')
