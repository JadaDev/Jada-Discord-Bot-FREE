import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import re

class ShortenCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def is_valid_url(self, url: str) -> bool:
        """Check if URL is valid"""
        url_pattern = re.compile(
            r'^https?://'  # http:// or https://
            r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain
            r'localhost|'  # localhost
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # or IP
            r'(?::\d+)?'  # optional port
            r'(?:/?|[/?]\S+)$', re.IGNORECASE
        )
        return url_pattern.match(url) is not None

    @app_commands.command(
        name="shorten",
        description="Shorten a URL using TinyURL"
    )
    @app_commands.describe(
        url="The URL to shorten"
    )
    async def shorten_command(self, interaction: discord.Interaction, url: str):
        await interaction.response.defer()
        try:
            # Ensure URL has http:// or https://
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url

            # Validate URL
            if not self.is_valid_url(url):
                embed = discord.Embed(
                    title="❌ Invalid URL",
                    description="Please provide a valid URL. Example: `https://example.com`",
                    color=discord.Color.red()
                )
                embed.set_footer(
                    text='Made by JadaDev • URL Shortener Command',
                    icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
                )
                await interaction.followup.send(embed=embed)
                return

            # TinyURL API
            api_url = "https://tinyurl.com/api-create.php"
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url, params={'url': url}) as response:
                    if response.status != 200:
                        raise Exception("Failed to reach TinyURL API.")
                    shortened_url = await response.text()

            # Length reduction info
            original_length = len(url)
            shortened_length = len(shortened_url)
            savings = original_length - shortened_length
            if savings > 0:
                percent = (savings / original_length) * 100
                length_text = f"{original_length} → {shortened_length} chars\n({percent:.1f}% shorter)"
            else:
                percent = (abs(savings) / original_length) * 100
                length_text = f"{original_length} → {shortened_length} chars\n({percent:.1f}% longer)"

            # Clean display for original URL if very long
            if len(url) > 50:
                original_display = url[:47] + "..."
                original_value = f"[{original_display}]({url})"
            else:
                original_value = f"`{url}`"

            # Build embed
            embed = discord.Embed(
                title="🏷️ URL Shortened Successfully!",
                color=discord.Color.green(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="Original URL", value=original_value, inline=False)
            embed.add_field(name="Shortened URL", value=f"<{shortened_url}>", inline=False)  # Discord-safe clickable link
            embed.add_field(name="Length Info", value=length_text, inline=True)
            embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
            embed.add_field(name="Quick Copy", value=f"`{shortened_url}`", inline=False)
            embed.set_footer(
                text='Made by JadaDev • URL Shortener Command • Powered by TinyURL',
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.followup.send(embed=embed)

        except aiohttp.ClientError:
            embed = discord.Embed(
                title="❌ Connection Error",
                description="Failed to connect to TinyURL service. Please try again later.",
                color=discord.Color.red()
            )
            embed.set_footer(
                text='Made by JadaDev • URL Shortener Command',
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )
            await interaction.followup.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(
                text='Made by JadaDev • URL Shortener Command',
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )
            await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(ShortenCommand(bot))
    print('Loaded shorten command')
