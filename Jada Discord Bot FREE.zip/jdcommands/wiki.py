import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json

class WikiCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="wiki", description="Search for information on Wikipedia")
    @app_commands.describe(
        query="What to search for on Wikipedia"
    )
    async def wiki_command(self, interaction: discord.Interaction, query: str):
        """
        Wikipedia search command
        """
        try:
            await interaction.response.defer()

            # Add User-Agent header to prevent blocking
            headers = {'User-Agent': 'JadaDev Discord Bot 1.0'}

            # Wikipedia API endpoint
            search_url = "https://en.wikipedia.org/api/rest_v1/page/summary/"

            async with aiohttp.ClientSession() as session:
                # First, search for the article
                search_api_url = f"https://en.wikipedia.org/w/api.php"
                search_params = {
                    'action': 'query',
                    'list': 'search',
                    'srsearch': query,
                    'format': 'json',
                    'srlimit': 1
                }
                
                async with session.get(search_api_url, params=search_params, headers=headers) as search_response:
                    search_data = await search_response.json()
                    
                    if not search_data.get('query', {}).get('search'):
                        embed = discord.Embed(
                            title="❌ No Results Found",
                            description=f"No Wikipedia articles found for '{query}'",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Wikipedia Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    # Get the first search result title
                    article_title = search_data['query']['search'][0]['title']
                
                # Now get the summary for that article
                summary_url = f"{search_url}{article_title.replace(' ', '_')}"
                
                async with session.get(summary_url, headers=headers) as response:
                    if response.status == 404:
                        embed = discord.Embed(
                            title="❌ Article Not Found",
                            description=f"Wikipedia article for '{query}' could not be found",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Wikipedia Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    data = await response.json()
                    
                    # Create embed
                    embed = discord.Embed(
                        title=f"📖 {data.get('title', 'Wikipedia Article')}",
                        url=data.get('content_urls', {}).get('desktop', {}).get('page', ''),
                        color=discord.Color.blue(),
                        timestamp=interaction.created_at
                    )
                    
                    # Add description (limit to 1024 characters for Discord)
                    description = data.get('extract', 'No description available.')
                    if len(description) > 1020:
                        description = description[:1020] + "..."
                    
                    embed.description = description
                    
                    # Add thumbnail if available
                    if data.get('thumbnail', {}).get('source'):
                        embed.set_thumbnail(url=data['thumbnail']['source'])
                    
                    embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
                    
                    if data.get('content_urls', {}).get('desktop', {}).get('page'):
                        embed.add_field(name="Read More", value=f"[Full Article]({data['content_urls']['desktop']['page']})", inline=True)
                    
                    embed.set_footer(text='Made by JadaDev • Wikipedia Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                    
                    await interaction.followup.send(embed=embed)
                    
        except aiohttp.ClientError:
            embed = discord.Embed(
                title="❌ Connection Error",
                description="Failed to connect to Wikipedia. Please try again later.",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Wikipedia Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Wikipedia Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(WikiCommand(bot))
    print('Loaded wiki command')
