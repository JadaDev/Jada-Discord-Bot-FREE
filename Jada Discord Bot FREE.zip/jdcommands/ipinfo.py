import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import os
import socket
from typing import Optional

class IPInfoCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _resolve_domain(self, domain: str) -> str:
        """Resolve domain to IP address"""
        try:
            # Get IPv4 address
            ip_address = socket.gethostbyname(domain)
            return ip_address
        except socket.gaierror:
            return None
        except Exception:
            return None

    @app_commands.command(name="ipinfo", description="Get information about an IP address or domain")
    @app_commands.describe(query="IP address or domain name (e.g., google.com or 8.8.8.8)")
    async def ipinfo_command(self, interaction: discord.Interaction, query: str):
        """
        Get geographical and ISP information for an IP address or domain
        """
        try:
            # Clean input
            query = query.strip()

            # Determine if it's a domain or IP
            try:
                # Try to parse as IP
                socket.inet_aton(query)
                ip_address = query
                domain = None
            except socket.error:
                # It's likely a domain, try to resolve
                domain = query
                ip_address = await self._resolve_domain(query)

                if not ip_address:
                    await interaction.response.send_message(f"❌ Could not resolve domain '{query}'!", ephemeral=True)
                    return

            # Use ipapi.co for geolocation (free tier)
            url = f"https://ipapi.co/{ip_address}/json"

            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message("❌ Could not fetch IP information!", ephemeral=True)
                        return

                    data = await resp.json()

                    if data.get('error'):
                        await interaction.response.send_message(f"❌ Error: {data.get('reason', 'Unknown error')}", ephemeral=True)
                        return

            # Extract information
            domain_display = domain or query
            ip_addr = data.get('ip', ip_address)
            completed = data.get('completed_requests', 0)

            # Check if we're hitting rate limits (ipapi.co free tier has limits)
            if completed > 900:  # Close to limit
                embed_footer = "Made by JadaDev • ⚠️ Warning: Approaching API limit"
            else:
                embed_footer = f"Made by JadaDev • IP geolocation data from ipapi.co"

            # Geography
            country_code = data.get('country_code', 'Unknown')
            country_name = data.get('country_name', 'Unknown')
            region = data.get('region', 'Unknown')
            city = data.get('city', 'Unknown')
            postal = data.get('postal', 'Unknown')
            timezone = data.get('timezone', 'Unknown')

            # Coordinates
            latitude = data.get('latitude')
            longitude = data.get('longitude')

            # ISP/Network Info
            isp = data.get('org', 'Unknown')
            asn = data.get('asn')

            # Create embed
            embed = discord.Embed(
                title="🌐 Domain/IP Information",
                description=f"Information for **{domain_display}**",
                color=discord.Color.blue(),
                timestamp=interaction.created_at
            )

            # IP Address
            embed.add_field(
                name="📍 IP Address",
                value=f"`{ip_addr}`",
                inline=True
            )

            # Country with flag emoji
            flag_emoji = f":flag_{country_code.lower()}:" if country_code != 'Unknown' else '🌍'
            embed.add_field(
                name="🌍 Country",
                value=f"{flag_emoji} {country_name}",
                inline=True
            )

            # City
            embed.add_field(
                name="🏙️ City",
                value=city,
                inline=True
            )

            # Region/State
            embed.add_field(
                name="📍 Region",
                value=region,
                inline=True
            )

            # Postal Code
            embed.add_field(
                name="📮 Postal Code",
                value=postal,
                inline=True
            )

            # ISP
            isp_short = isp[:45] + "..." if len(isp) > 45 else isp
            embed.add_field(
                name="🌐 ISP",
                value=isp_short,
                inline=False
            )

            # Timezone
            embed.add_field(
                name="⏰ Timezone",
                value=timezone,
                inline=True
            )

            # Coordinates
            if latitude and longitude:
                embed.add_field(
                    name="🗺️ Coordinates",
                    value=f"{latitude:.4f}, {longitude:.4f}",
                    inline=True
                )

            # ASN (Autonomous System Number) if available
            if asn:
                embed.add_field(
                    name="🔢 ASN",
                    value=f"AS{asn}",
                    inline=True
                )

            embed.set_footer(
                text=embed_footer,
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(IPInfoCommand(bot))
    print('Loaded IP info command')
