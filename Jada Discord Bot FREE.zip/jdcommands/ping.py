import discord
from discord.ext import commands
from discord import app_commands
import time

class PingCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="ping", description="Check bot latency and response time")
    async def ping_command(self, interaction: discord.Interaction):
        """
        Simple ping command to test bot responsiveness
        """
        try:
            start_time = time.time()
            await interaction.response.defer()
            end_time = time.time()
            
            response_time = round((end_time - start_time) * 1000, 2)
            websocket_latency = round(self.bot.latency * 1000, 2)
            
            embed = discord.Embed(
                title="🏓 Pong!",
                color=discord.Color.green(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="Response Time", value=f"{response_time}ms", inline=True)
            embed.add_field(name="WebSocket Latency", value=f"{websocket_latency}ms", inline=True)
            embed.set_footer(
                text=f"Made by JadaDev • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.followup.send(embed=embed)
        except Exception as e:
            await interaction.followup.send(f"An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(PingCommand(bot))
    print('Loaded ping command')
