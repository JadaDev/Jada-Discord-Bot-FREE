import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json

class CountryInfoCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="countryinfo", description="Get information about any country")
    @app_commands.describe(
        country="Name of the country to search for"
    )
    async def countryinfo_command(self, interaction: discord.Interaction, country: str):
        """
        Country information command using REST Countries API
        """
        try:
            await interaction.response.defer()
            
            # REST Countries API endpoint
            api_url = f"https://restcountries.com/v3.1/name/{country}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url) as response:
                    if response.status == 404:
                        embed = discord.Embed(
                            title="❌ Country Not Found",
                            description=f"No country found for '{country}'. Please check the spelling and try again.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Country Info Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    if response.status != 200:
                        embed = discord.Embed(
                            title="❌ API Error",
                            description="Failed to fetch country information. Please try again later.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Country Info Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    data = await response.json()
                    country_data = data[0]  # Take first result
                    
                    # Create embed
                    embed = discord.Embed(
                        title=f"🗺️ {country_data.get('name', {}).get('common', 'Unknown')}",
                        color=discord.Color.blue(),
                        timestamp=interaction.created_at
                    )
                    
                    # Add flag as thumbnail
                    if country_data.get('flags', {}).get('png'):
                        embed.set_thumbnail(url=country_data['flags']['png'])
                    
                    # Basic information
                    embed.add_field(
                        name="Official Name",
                        value=country_data.get('name', {}).get('official', 'N/A'),
                        inline=False
                    )
                    
                    embed.add_field(
                        name="Capital",
                        value=', '.join(country_data.get('capital', ['N/A'])),
                        inline=True
                    )
                    
                    embed.add_field(
                        name="Region",
                        value=country_data.get('region', 'N/A'),
                        inline=True
                    )
                    
                    embed.add_field(
                        name="Subregion",
                        value=country_data.get('subregion', 'N/A'),
                        inline=True
                    )
                    
                    # Population with formatting
                    population = country_data.get('population', 0)
                    if population:
                        population_str = f"{population:,}"
                    else:
                        population_str = "N/A"
                    
                    embed.add_field(
                        name="Population",
                        value=population_str,
                        inline=True
                    )
                    
                    # Area
                    area = country_data.get('area')
                    if area:
                        area_str = f"{area:,} km²"
                    else:
                        area_str = "N/A"
                    
                    embed.add_field(
                        name="Area",
                        value=area_str,
                        inline=True
                    )
                    
                    # Languages
                    languages = country_data.get('languages', {})
                    if languages:
                        lang_list = list(languages.values())[:5]  # Limit to 5 languages
                        embed.add_field(
                            name="Languages",
                            value=', '.join(lang_list),
                            inline=True
                        )
                    
                    # Currencies
                    currencies = country_data.get('currencies', {})
                    if currencies:
                        currency_list = []
                        for code, info in currencies.items():
                            name = info.get('name', code)
                            symbol = info.get('symbol', '')
                            if symbol:
                                currency_list.append(f"{name} ({symbol})")
                            else:
                                currency_list.append(name)
                        
                        embed.add_field(
                            name="Currency",
                            value=', '.join(currency_list[:3]),  # Limit to 3 currencies
                            inline=True
                        )
                    
                    # Timezone
                    timezones = country_data.get('timezones', [])
                    if timezones:
                        embed.add_field(
                            name="Timezone(s)",
                            value=', '.join(timezones[:3]),  # Limit to 3 timezones
                            inline=True
                        )
                    
                    # Borders
                    borders = country_data.get('borders', [])
                    if borders:
                        embed.add_field(
                            name="Bordering Countries",
                            value=', '.join(borders[:10]),  # Limit to 10 borders
                            inline=False
                        )
                    
                    # Calling codes
                    calling_codes = country_data.get('idd', {})
                    if calling_codes.get('root') and calling_codes.get('suffixes'):
                        root = calling_codes['root']
                        suffixes = calling_codes['suffixes']
                        codes = [f"{root}{suffix}" for suffix in suffixes[:3]]
                        embed.add_field(
                            name="Calling Code(s)",
                            value=', '.join(codes),
                            inline=True
                        )
                    
                    embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
                    
                    embed.set_footer(text='Made by JadaDev • Country Info Command • Data from REST Countries', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                    
                    await interaction.followup.send(embed=embed)
                    
        except aiohttp.ClientError:
            embed = discord.Embed(
                title="❌ Connection Error",
                description="Failed to connect to country database. Please try again later.",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Country Info Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Country Info Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(CountryInfoCommand(bot))
    print('Loaded countryinfo command')