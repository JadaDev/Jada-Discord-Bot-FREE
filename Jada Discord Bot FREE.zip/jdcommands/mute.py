import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta

class MuteCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="mute", description="Mute or unmute a member")
    @app_commands.describe(
        member="The member to mute/unmute",
        time="Duration in minutes (0 to unmute, max 40320 = 28 days)",
        reason="Reason for muting the member"
    )
    async def mute_command(self, interaction: discord.Interaction, member: discord.Member, time: int, reason: str = "No reason provided"):
        """
        Mute/unmute command with proper permission checks
        """
        try:
            # Check if the user has moderate members permissions
            if not interaction.user.guild_permissions.moderate_members:
                await interaction.response.send_message("❌ You don't have permission to moderate members!", ephemeral=True)
                return
            
            # Check if the bot has moderate members permissions
            if not interaction.guild.me.guild_permissions.moderate_members:
                await interaction.response.send_message("❌ I don't have permission to moderate members!", ephemeral=True)
                return
            
            # Validate time (Discord's limit is 28 days = 40320 minutes)
            if time < 0 or time > 40320:
                await interaction.response.send_message("❌ Time must be between 0 and 40320 minutes (28 days)!", ephemeral=True)
                return
            
            # Check role hierarchy
            if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
                await interaction.response.send_message("❌ You cannot mute someone with a higher or equal role!", ephemeral=True)
                return
            
            if member.top_role >= interaction.guild.me.top_role:
                await interaction.response.send_message("❌ I cannot mute someone with a higher or equal role than me!", ephemeral=True)
                return
            
            # Cannot mute the server owner
            if member == interaction.guild.owner:
                await interaction.response.send_message("❌ Cannot mute the server owner!", ephemeral=True)
                return
            
            # Cannot mute yourself
            if member == interaction.user:
                await interaction.response.send_message("❌ You cannot mute yourself!", ephemeral=True)
                return
            
            if time == 0:
                # Unmute the member
                await member.timeout(None, reason=f"Unmuted by {interaction.user} - {reason}")
                
                title = "🔊 Member Unmuted"
                color = discord.Color.green()
                duration_text = "Unmuted"
                action = "unmuted"
            else:
                # Calculate timeout duration
                timeout_until = datetime.utcnow() + timedelta(minutes=time)
                
                # Mute the member
                await member.timeout(timeout_until, reason=f"Muted by {interaction.user} - {reason}")
                
                title = "🔇 Member Muted"
                color = discord.Color.red()
                
                # Format duration display
                if time < 60:
                    duration_text = f"{time} minutes"
                elif time < 1440:  # Less than 24 hours
                    hours = time // 60
                    minutes = time % 60
                    if minutes > 0:
                        duration_text = f"{hours} hours {minutes} minutes"
                    else:
                        duration_text = f"{hours} hours"
                else:  # 24+ hours
                    days = time // 1440
                    hours = (time % 1440) // 60
                    if hours > 0:
                        duration_text = f"{days} days {hours} hours"
                    else:
                        duration_text = f"{days} days"
                
                action = "muted"
            
            # Create embed response
            embed = discord.Embed(
                title=title,
                color=color,
                timestamp=interaction.created_at
            )
            embed.add_field(name="Member", value=f"{member.mention} ({member})", inline=False)
            embed.add_field(name="Duration", value=duration_text, inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)
            
            # Try to DM the member
            try:
                dm_embed = discord.Embed(
                    title=f"You have been {action}",
                    description=f"You were {action} in {interaction.guild.name}",
                    color=color
                )
                dm_embed.add_field(name="Duration", value=duration_text, inline=False)
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
                dm_embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled or blocked the bot
                
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to timeout this member!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(MuteCommand(bot))
    print('Loaded mute command')