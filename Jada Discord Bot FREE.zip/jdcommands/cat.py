import discord
from discord.ext import commands
from discord import app_commands
import aiohttp

class CatCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="cat", description="Get a random cat picture")
    async def cat_command(self, interaction: discord.Interaction):
        """
        Get a random cat picture from TheCatAPI
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("https://api.thecatapi.com/v1/images/search", headers={'User-Agent': 'DiscordBot/1.0'}) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message("❌ Could not fetch cat picture!", ephemeral=True)
                        return

                    data = await resp.json()
        except Exception:
            await interaction.response.send_message("❌ Could not fetch cat picture!", ephemeral=True)
            return

        if not data:
            await interaction.response.send_message("❌ No cat picture available!", ephemeral=True)
            return

        cat_url = data[0].get('url')
        if not cat_url:
            await interaction.response.send_message("❌ No cat picture available!", ephemeral=True)
            return

        embed = discord.Embed(
            title="🐱 Random Cat",
            color=discord.Color.orange(),
            timestamp=interaction.created_at
        )

        embed.set_image(url=cat_url)
        embed.set_footer(
            text="Made by JadaDev • Powered by TheCatAPI",
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(CatCommand(bot))
    print('Loaded cat command')
