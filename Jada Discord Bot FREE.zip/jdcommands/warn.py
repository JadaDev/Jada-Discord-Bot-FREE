import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional

class WarnCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="warn", description="Issue a warning to a user")
    @app_commands.describe(
        member="The member to warn",
        reason="Reason for the warning"
    )
    async def warn_command(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """
        Warn a user with proper permission checks
        """
        try:
            # Check if the user has warn permissions
            if not interaction.user.guild_permissions.manage_messages:
                await interaction.response.send_message("❌ You don't have permission to warn members!", ephemeral=True)
                return

            # Check if the bot has necessary permissions
            if not interaction.guild.me.guild_permissions.manage_messages:
                await interaction.response.send_message("❌ I don't have permission to warn members!", ephemeral=True)
                return

            # Cannot warn the server owner
            if member == interaction.guild.owner:
                await interaction.response.send_message("❌ Cannot warn the server owner!", ephemeral=True)
                return

            # Cannot warn themselves
            if member == interaction.user:
                await interaction.response.send_message("❌ You cannot warn yourself!", ephemeral=True)
                return

            # Cannot warn the bot
            if member == interaction.guild.me:
                await interaction.response.send_message("❌ You cannot warn me!", ephemeral=True)
                return

            # Create embed response
            embed = discord.Embed(
                title="⚠️ Member Warned",
                color=discord.Color.orange(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="Member", value=f"{member.mention} ({member})", inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)

            # Try to DM the warned member
            try:
                dm_embed = discord.Embed(
                    title="You have been warned",
                    description=f"You were warned in {interaction.guild.name}",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
                dm_embed.add_field(name="Server", value=interaction.guild.name, inline=False)
                dm_embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled or blocked the bot

        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to warn this member!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(WarnCommand(bot))
    print('Loaded warn command')
