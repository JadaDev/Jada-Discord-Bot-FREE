import discord
from discord.ext import commands
from discord import app_commands

class SlowmodeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="slowmode", description="Set slowmode for a channel")
    @app_commands.describe(
        channel="The channel to set slowmode for",
        time="Time in seconds (0 to disable, max 21600)"
    )
    @app_commands.choices(time=[
        app_commands.Choice(name="Disable", value=0),
        app_commands.Choice(name="5 seconds", value=5),
        app_commands.Choice(name="10 seconds", value=10),
        app_commands.Choice(name="15 seconds", value=15),
        app_commands.Choice(name="30 seconds", value=30),
        app_commands.Choice(name="1 minute", value=60),
        app_commands.Choice(name="2 minutes", value=120),
        app_commands.Choice(name="5 minutes", value=300),
        app_commands.Choice(name="10 minutes", value=600),
        app_commands.Choice(name="15 minutes", value=900),
        app_commands.Choice(name="30 minutes", value=1800),
        app_commands.Choice(name="1 hour", value=3600),
        app_commands.Choice(name="2 hours", value=7200),
        app_commands.Choice(name="6 hours", value=21600)
    ])
    async def slowmode_command(self, interaction: discord.Interaction, channel: discord.TextChannel, time: int):
        """
        Slowmode command with proper permission checks
        """
        try:
            # Check if the user has manage channels permissions
            if not interaction.user.guild_permissions.manage_channels:
                await interaction.response.send_message("❌ You don't have permission to manage channels!", ephemeral=True)
                return
            
            # Check if the bot has manage channels permissions
            if not interaction.guild.me.guild_permissions.manage_channels:
                await interaction.response.send_message("❌ I don't have permission to manage channels!", ephemeral=True)
                return
            
            # Validate time (Discord's limit is 21600 seconds = 6 hours)
            if time < 0 or time > 21600:
                await interaction.response.send_message("❌ Time must be between 0 and 21600 seconds (6 hours)!", ephemeral=True)
                return
            
            # Set the slowmode
            await channel.edit(slowmode_delay=time)
            
            # Format time display
            if time == 0:
                time_display = "Disabled"
                title = "⚡ Slowmode Disabled"
                color = discord.Color.green()
            else:
                if time < 60:
                    time_display = f"{time} seconds"
                elif time < 3600:
                    time_display = f"{time // 60} minutes"
                else:
                    hours = time // 3600
                    minutes = (time % 3600) // 60
                    if minutes > 0:
                        time_display = f"{hours} hours {minutes} minutes"
                    else:
                        time_display = f"{hours} hours"
                title = "🐌 Slowmode Enabled"
                color = discord.Color.orange()
            
            # Create embed response
            embed = discord.Embed(
                title=title,
                description=f"Slowmode for {channel.mention} has been set",
                color=color,
                timestamp=interaction.created_at
            )
            embed.add_field(name="Channel", value=channel.mention, inline=False)
            embed.add_field(name="Slowmode", value=time_display, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)
                
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to modify this channel!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(SlowmodeCommand(bot))
    print('Loaded slowmode command')