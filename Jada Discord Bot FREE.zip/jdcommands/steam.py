import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import urllib.parse

class SteamCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="steam", description="Shows game info, price, and reviews from the Steam API.")
    @app_commands.describe(game_name="Name of the game to search for")
    async def steam_command(self, interaction: discord.Interaction, game_name: str):
        """
        Shows game info, price, and reviews from the Steam API.
        """
        tag = f"<@{interaction.user.id}>"
        
        if not game_name.strip():
            await interaction.response.send_message(f"{tag} Please specify a game name!", ephemeral=True)
            return

        game_name_encoded = urllib.parse.quote(game_name.strip())

        try:
            # First, search for the game to get its Steam ID
            search_url = f"https://store.steampowered.com/api/storesearch/?term={game_name_encoded}&l=english&cc=US"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(search_url) as response:
                    if response.status != 200:
                        await interaction.response.send_message(f"{tag} Could not access Steam Store API.", ephemeral=True)
                        return
                    
                    search_data = await response.json()
            
            if not search_data.get('items') or len(search_data['items']) == 0:
                await interaction.response.send_message(f"{tag} Game \"{game_name}\" not found on Steam. Please check the spelling and try again.", ephemeral=True)
                return

            game = search_data['items'][0]
            appid = game['id']

            # Get detailed game information
            details_url = f"https://store.steampowered.com/api/appdetails?appids={appid}&l=english"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(details_url) as details_response:
                    if details_response.status != 200:
                        await interaction.response.send_message(f"{tag} Could not retrieve game details.", ephemeral=True)
                        return
                    
                    details_data = await details_response.json()
            
            if str(appid) not in details_data or not details_data[str(appid)].get('success', False):
                await interaction.response.send_message(f"{tag} Could not retrieve detailed information for \"{game_name}\".", ephemeral=True)
                return

            game_data = details_data[str(appid)]['data']

            # Format price
            def format_price():
                if game_data.get('is_free', False):
                    return 'Free to Play'
                elif 'price_overview' in game_data:
                    return game_data['price_overview']['final_formatted']
                else:
                    return 'Price not available'

            # Format platforms
            platforms = []
            if 'platforms' in game_data:
                if game_data['platforms'].get('windows', False):
                    platforms.append('Windows')
                if game_data['platforms'].get('mac', False):
                    platforms.append('Mac')
                if game_data['platforms'].get('linux', False):
                    platforms.append('Linux')

            # Format genres
            genres = ', '.join([g['description'] for g in game_data.get('genres', [])[:3]]) if game_data.get('genres') else 'N/A'

            # Format developers
            developers = ', '.join(game_data.get('developers', [])[:2]) if game_data.get('developers') else 'N/A'

            # Format publishers
            publishers = ', '.join(game_data.get('publishers', [])[:2]) if game_data.get('publishers') else 'N/A'

            # Format release date
            release_date = game_data.get('release_date', {}).get('date', 'N/A')

            # Truncate description
            description = game_data.get('short_description', 'No description available.')
            if len(description) > 500:
                description = description[:497] + '...'

            # Create embed
            embed = discord.Embed(
                title=f"🎮 {game_data['name']}",
                description=description,
                url=f"https://store.steampowered.com/app/{appid}",
                color=0x1B2838,
                timestamp=interaction.created_at
            )
            
            embed.add_field(name='💰 Price', value=format_price(), inline=True)
            embed.add_field(name='🏷️ Genres', value=genres, inline=True)
            embed.add_field(name='💻 Platforms', value=', '.join(platforms) if platforms else 'N/A', inline=True)
            embed.add_field(name='👨‍💻 Developer', value=developers, inline=True)
            embed.add_field(name='🏢 Publisher', value=publishers, inline=True)
            embed.add_field(name='📅 Release Date', value=release_date, inline=True)

            # Add game image if available
            if 'header_image' in game_data:
                embed.set_image(url=game_data['header_image'])

            # Add metacritic score if available
            if 'metacritic' in game_data and game_data['metacritic'].get('score'):
                embed.add_field(name='⭐ Metacritic Score', value=f"{game_data['metacritic']['score']}/100", inline=True)

            # Add recommendation info if available
            if 'recommendations' in game_data and game_data['recommendations'].get('total'):
                embed.add_field(name='👍 Recommendations', value=str(game_data['recommendations']['total']), inline=True)

            embed.set_footer(text='Made by JadaDev • Powered by Steam', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)

        except aiohttp.ClientError as e:
            await interaction.response.send_message(f"{tag} Sorry, I couldn't fetch Steam data right now. Please try again later.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{tag} An unexpected error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(SteamCommand(bot))
    print('Loaded steam command')
