import discord
from discord.ext import commands
from discord import app_commands
import psutil
import platform
import datetime
from typing import Optional

class UptimeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = datetime.datetime.utcnow()

    @app_commands.command(name="uptime", description="Show bot uptime and system statistics")
    async def uptime_command(self, interaction: discord.Interaction):
        """
        Display bot uptime, system info, and usage statistics
        """
        try:
            # Calculate uptime
            current_time = datetime.datetime.utcnow()
            uptime_duration = current_time - self.start_time

            # Format uptime
            days = uptime_duration.days
            hours, remainder = divmod(uptime_duration.seconds, 3600)
            minutes, seconds = divmod(remainder, 60)

            uptime_str = ""
            if days > 0:
                uptime_str += f"{days}d "
            if hours > 0:
                uptime_str += f"{hours}h "
            if minutes > 0:
                uptime_str += f"{minutes}m "
            uptime_str += f"{seconds}s"

            # System information
            system = platform.system()
            python_version = platform.python_version()

            # Memory usage (if psutil available)
            memory_percent = psutil.virtual_memory().percent
            cpu_percent = psutil.cpu_percent(interval=1)

            # Bot statistics
            server_count = len(self.bot.guilds)
            total_members = sum(guild.member_count for guild in self.bot.guilds if guild.member_count)

            # Discord.py version (try to get it)
            discord_version = discord.__version__

            # Create embed
            embed = discord.Embed(
                title="⏱️ Bot Uptime & Statistics",
                color=discord.Color.green(),
                timestamp=interaction.created_at
            )

            # Set bot avatar if available
            if interaction.client.user and interaction.client.user.avatar:
                embed.set_thumbnail(url=interaction.client.user.avatar.url)

            # Uptime information
            embed.add_field(
                name="🕒 Bot Uptime",
                value=f"**{uptime_str}**\nStarted: {self.start_time.strftime('%B %d, %Y at %H:%M UTC')}",
                inline=False
            )

            # Server statistics
            embed.add_field(
                name="🏠 Server Stats",
                value=f"**Servers:** {server_count:,}\n**Total Members:** {total_members:,}",
                inline=True
            )

            # System information
            embed.add_field(
                name="💻 System Info",
                value=f"**OS:** {system}\n**Python:** {python_version}",
                inline=True
            )

            # Performance
            memory_emoji = "🟢" if memory_percent < 70 else "🟡" if memory_percent < 90 else "🔴"
            cpu_emoji = "🟢" if cpu_percent < 70 else "🟡" if cpu_percent < 90 else "🔴"

            embed.add_field(
                name="⚡ Performance",
                value=f"{memory_emoji} **Memory:** {memory_percent:.1f}%\n{cpu_emoji} **CPU:** {cpu_percent:.1f}%",
                inline=True
            )

            # Discord.py version
            embed.add_field(
                name="🔧 Discord.py",
                value=f"**Version:** {discord_version}",
                inline=True
            )

            # Ping/latency if available
            if self.bot.latency:
                ping = round(self.bot.latency * 1000, 1)
                ping_emoji = "🟢" if ping < 100 else "🟡" if ping < 200 else "🔴"
                embed.add_field(
                    name="🌐 API Latency",
                    value=f"{ping_emoji} **{ping}ms**",
                    inline=True
                )

            # Footer
            embed.set_footer(
                text=f"Made by JadaDev • Bot status as of {datetime.datetime.utcnow().strftime('%H:%M:%S UTC')}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(UptimeCommand(bot))
    print('Loaded uptime command')
