import discord
from discord.ext import commands
from discord import app_commands

class ClearCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="clear", description="Delete messages from the channel")
    @app_commands.describe(
        amount="Number of messages to delete (2-20)"
    )
    async def clear_command(self, interaction: discord.Interaction, amount: int):
        """
        Clear messages command with proper permission checks
        """
        try:
            # Check if the user has manage messages permissions
            if not interaction.user.guild_permissions.manage_messages:
                await interaction.response.send_message("❌ You don't have permission to manage messages!", ephemeral=True)
                return
            
            # Check if the bot has manage messages permissions
            if not interaction.guild.me.guild_permissions.manage_messages:
                await interaction.response.send_message("❌ I don't have permission to manage messages!", ephemeral=True)
                return
            
            # Validate amount
            if amount < 2 or amount > 20:
                await interaction.response.send_message("❌ You can only delete between 2 and 20 messages!", ephemeral=True)
                return
            
            # Send initial response
            await interaction.response.send_message("🗑️ Clearing messages...", ephemeral=True)
            
            # Get the channel
            channel = interaction.channel
            
            # Delete messages
            deleted = await channel.purge(limit=amount)
            deleted_count = len(deleted)
            
            # Create embed response
            embed = discord.Embed(
                title="🗑️ Messages Cleared",
                description=f"Successfully deleted {deleted_count} messages",
                color=discord.Color.red(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="Channel", value=channel.mention, inline=False)
            embed.add_field(name="Messages Deleted", value=str(deleted_count), inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            # Send the result message and delete it after 5 seconds
            result_message = await channel.send(embed=embed)
            await result_message.delete(delay=5)
                
        except discord.Forbidden:
            try:
                await interaction.response.send_message("❌ I don't have permission to delete messages in this channel!", ephemeral=True)
            except:
                await interaction.channel.send("❌ I don't have permission to delete messages in this channel!", delete_after=5)
        except discord.HTTPException as e:
            if "bulk delete" in str(e).lower():
                error_msg = "❌ Cannot delete messages older than 14 days!"
            else:
                error_msg = f"❌ An HTTP error occurred: {str(e)}"
            
            try:
                await interaction.response.send_message(error_msg, ephemeral=True)
            except:
                await interaction.channel.send(error_msg, delete_after=5)
        except Exception as e:
            error_msg = f"❌ An error occurred: {str(e)}"
            try:
                await interaction.response.send_message(error_msg, ephemeral=True)
            except:
                await interaction.channel.send(error_msg, delete_after=5)

async def setup(bot):
    await bot.add_cog(ClearCommand(bot))
    print('Loaded clear command')