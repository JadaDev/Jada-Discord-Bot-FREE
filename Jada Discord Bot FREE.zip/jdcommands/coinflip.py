import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional
import random

class CoinFlipCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="coinflip", description="Flip a virtual coin")
    @app_commands.describe(bet="Your bet (heads or tails, optional)")
    async def coinflip_command(self, interaction: discord.Interaction, bet: Optional[str] = None):
        """
        Fun coin flip command that users can bet on
        """
        try:
            # Available choices
            choices = ["heads", "tails"]

            # Flip the coin
            result = random.choice(choices)
            emoji = "🪙" if result == "heads" else "💀"

            # Check if bet was correct
            bet_result = None
            if bet:
                bet = bet.lower().strip()
                if bet in choices:
                    if bet == result:
                        bet_result = "won"
                    else:
                        bet_result = "lost"
                else:
                    bet_result = "invalid"

            # Create embed
            embed = discord.Embed(
                title="🪙 Coin Flip",
                color=discord.Color.gold(),
                timestamp=interaction.created_at
            )

            embed.add_field(name="Result", value=f"{emoji} **{result.title()}**", inline=True)

            if bet_result == "won":
                embed.add_field(name="Your Bet", value=f"✅ You won! ({bet.title()})", inline=True)
                embed.color = discord.Color.green()
            elif bet_result == "lost":
                embed.add_field(name="Your Bet", value=f"❌ You lost! ({bet.title()})", inline=True)
                embed.color = discord.Color.red()
            elif bet_result == "invalid" and bet:
                embed.add_field(name="Your Bet", value=f"🤔 Invalid bet: {bet}", inline=True)
            else:
                embed.add_field(name="Your Bet", value="No bet placed", inline=True)

            embed.set_footer(
                text=f"Made by JadaDev • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(CoinFlipCommand(bot))
    print('Loaded coinflip command')
