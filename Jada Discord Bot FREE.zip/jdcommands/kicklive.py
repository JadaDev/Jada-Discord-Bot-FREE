# kicklive.py
import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import asyncio
import random
from datetime import datetime, timezone
from typing import Optional, Dict, Any

class KickLiveCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

        # Working Kick.com endpoints - using private API like Node.js example
        self.KICK_ENDPOINTS = {
            'PRIVATE_CHANNEL': 'https://api.kick.com/private/v1/channels/{username}',
            'LIVESTREAM_PRIVATE': 'https://api.kick.com/private/v1/channels/{username}/livestream'
        }

        # User agents to avoid detection
        self.USER_AGENTS = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0'
        ]

    def get_random_user_agent(self) -> str:
        """Get random user agent"""
        return random.choice(self.USER_AGENTS)

    def create_headers(self, user_agent: Optional[str] = None) -> Dict[str, str]:
        """Create request headers"""
        ua = user_agent or self.get_random_user_agent()

        return {
            'User-Agent': ua,
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }

    async def make_request(self, url: str, retries: int = 2) -> Dict[str, Any]:
        """Make API request with retries"""
        last_exception = None
        for attempt in range(retries + 1):
            try:
                timeout = aiohttp.ClientTimeout(total=10)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    headers = self.create_headers()
                    async with session.get(url, headers=headers) as response:
                        # 200 => OK
                        if response.status == 200:
                            try:
                                return await response.json()
                            except Exception:
                                # If response is not JSON but still 200, return raw text as fallback
                                return {'raw_text': await response.text()}
                        elif response.status == 404:
                            raise Exception('CHANNEL_NOT_FOUND')
                        elif response.status == 403:
                            # try again with different UA
                            if attempt < retries:
                                await asyncio.sleep(1 + random.uniform(0, 2))
                                continue
                            raise Exception('API_BLOCKED')
                        else:
                            response.raise_for_status()

            except Exception as e:
                last_exception = e
                # propagate specific ones immediately
                if str(e) in ('CHANNEL_NOT_FOUND', 'API_BLOCKED'):
                    raise e
                # otherwise retry
                if attempt < retries:
                    await asyncio.sleep(1.5 + random.uniform(0, 1.5))
                    continue
                raise last_exception

        raise Exception('MAX_RETRIES_EXCEEDED')

    async def calculate_uptime(self, started_at: Optional[str], created_at: Optional[str] = None) -> str:
        """Calculate stream uptime"""
        try:
            stream_time_str = started_at or created_at
            if not stream_time_str:
                return 'Unknown'

            # convert ISO string to datetime
            stream_start_time = datetime.fromisoformat(stream_time_str.replace('Z', '+00:00'))
            now = datetime.now(timezone.utc)
            uptime_seconds = (now - stream_start_time).total_seconds()

            if uptime_seconds > 0:
                hours = int(uptime_seconds // 3600)
                minutes = int((uptime_seconds % 3600) // 60)
                return f'{hours}h {minutes}m' if hours > 0 else f'{minutes}m'

        except Exception as e:
            print(f'Error calculating uptime: {e}')

        return 'Unknown'

    @app_commands.command(name="kicklive", description="Provides quick access to Kick.com streamers and live stream information")
    @app_commands.describe(username="Kick username to check")
    async def kicklive_command(self, interaction: discord.Interaction, username: str):
        """Check if a Kick streamer is live using working private API endpoints"""

        username = username.lower().strip()
        response_sent = False

        # Defer immediately to avoid Unknown Interaction when doing long API calls
        try:
            await interaction.response.defer()
        except Exception:
            # If defer fails, ignore and continue; we'll try followups and handle errors gracefully
            pass

        # Small random delay to avoid being rate-detected
        await asyncio.sleep(random.uniform(0.5, 1.2))

        try:
            print(f'[INFO] Checking stream status for: {username}')
            channel_data = None
            livestream_data = None

            # Primary private API channel endpoint
            try:
                url = self.KICK_ENDPOINTS['PRIVATE_CHANNEL'].format(username=username)
                channel_data = await self.make_request(url)
                print('[OK] Private API endpoint worked!')

                # Try livestream-specific endpoint if present
                try:
                    livestream_url = self.KICK_ENDPOINTS['LIVESTREAM_PRIVATE'].format(username=username)
                    livestream_data = await self.make_request(livestream_url)
                    print('[OK] Livestream data retrieved!')
                except Exception as e:
                    print(f'[WARNING] Livestream endpoint failed: {e} — using channel data only')

            except Exception as error:
                print(f'[ERROR] Private API endpoint failed: {error}')
                raise Exception('PRIVATE_API_FAILED')

            if not channel_data:
                raise Exception('NO_DATA_RECEIVED')

            print('[OK] Successfully retrieved data using: Kick Private API')

            # Normalize nested structures (safe get)
            account_data = channel_data.get('data', {}).get('account', channel_data) if isinstance(channel_data, dict) else channel_data
            user_info = {}
            channel_info = {}
            if isinstance(account_data, dict):
                user_info = account_data.get('user', account_data.get('user', {})) or {}
                channel_info = account_data.get('channel', account_data.get('channel', {})) or {}

            # Determine if live
            is_live = False
            stream_info = None

            if livestream_data and isinstance(livestream_data, dict):
                liv = livestream_data.get('data', {}).get('livestream') or livestream_data.get('livestream')
                if liv:
                    stream_info = liv
                    is_live = bool(
                        (liv.get('viewers_count') or liv.get('viewer_count') or 0) > 0 or
                        liv.get('started_at') or
                        (liv.get('metadata', {}).get('title') if isinstance(liv.get('metadata', {}), dict) else None)
                    )

            # fallback to channel_data shapes
            if not is_live:
                maybe = channel_data.get('livestream') or channel_data.get('current_livestream') or channel_data.get('live_stream')
                if maybe:
                    stream_info = maybe
                    is_live = bool(
                        maybe.get('is_live') is True or
                        maybe.get('session_title') or
                        (maybe.get('viewer_count') or maybe.get('viewers') or 0) > 0 or
                        maybe.get('created_at')
                    )

            # Additional fallback: user_info flags
            if not is_live and isinstance(user_info, dict):
                is_live = bool(user_info.get('is_live'))

            # Prepare embed(s)
            if is_live and stream_info:
                uptime = await self.calculate_uptime(
                    stream_info.get('started_at'),
                    stream_info.get('created_at')
                )

                title_text = stream_info.get('metadata', {}).get('title') if isinstance(stream_info.get('metadata', {}), dict) else None
                title_text = title_text or stream_info.get('session_title') or stream_info.get('title') or 'Live Stream'

                kick_embed = discord.Embed(
                    color=0x53FC18,  # green
                    title=f"🟢 {username} - LIVE on Kick",
                    description=title_text,
                    url=f"https://kick.com/{username}",
                    timestamp=interaction.created_at if interaction.created_at else None
                )

                # Category
                category_name = None
                try:
                    category_name = (stream_info.get('metadata', {}).get('category', {}).get('name')
                                     if isinstance(stream_info.get('metadata', {}), dict) else None)
                except Exception:
                    category_name = None

                if not category_name:
                    # try other locations
                    try:
                        category_name = (stream_info.get('category', {}).get('name') if isinstance(stream_info.get('category', {}), dict) else None)
                    except Exception:
                        category_name = None

                if not category_name:
                    try:
                        categories = stream_info.get('categories')
                        if isinstance(categories, list) and len(categories) > 0:
                            category_name = categories[0].get('name')
                    except Exception:
                        category_name = None

                if not category_name:
                    try:
                        category_name = channel_info.get('category', {}).get('name')
                    except Exception:
                        category_name = None

                kick_embed.add_field(name='🎮 Category', value=category_name or 'Unknown', inline=True)

                # Viewers safe formatting
                viewers = 0
                try:
                    viewers = int(stream_info.get('viewers_count') or stream_info.get('viewer_count') or stream_info.get('viewers') or 0)
                except Exception:
                    viewers = 0
                kick_embed.add_field(name='👁️ Viewers', value=f"{viewers:,}", inline=True)

                kick_embed.add_field(name='⏱️ Uptime', value=uptime, inline=True)
                kick_embed.add_field(name='🔗 Watch Now', value=f"[View Stream](https://kick.com/{username})", inline=True)
                kick_embed.add_field(name='🔌 API Source', value='Kick Private API', inline=True)
                kick_embed.add_field(name='✅ Status', value='**LIVE - Working Endpoint!**', inline=True)

                # Thumbnail / image handling (use url=)
                # Prefer stream image then user avatar
                try:
                    thumb_url = None
                    if stream_info.get('thumbnail_url'):
                        thumb_url = stream_info.get('thumbnail_url')
                    elif isinstance(stream_info.get('thumbnail', {}), dict):
                        thumb_url = stream_info.get('thumbnail', {}).get('url') or stream_info.get('thumbnail', {}).get('responsive')
                    elif stream_info.get('image'):
                        thumb_url = stream_info.get('image')
                    elif stream_info.get('preview'):
                        thumb_url = stream_info.get('preview')

                    if thumb_url:
                        kick_embed.set_image(url=thumb_url)
                except Exception as e:
                    print(f'[WARN] Could not set image: {e}')

                # Set avatar as thumbnail if available
                try:
                    avatar_url = user_info.get('profile_picture') or channel_data.get('user', {}).get('profile_pic') or channel_data.get('profile_pic')
                    if avatar_url:
                        kick_embed.set_thumbnail(url=avatar_url)
                except Exception as e:
                    print(f'[WARN] Could not set thumbnail: {e}')

                kick_embed.set_footer(
                    text='Made by JadaDev • Kick Private API',
                    icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
                )

                # send via followup (we already deferred)
                await interaction.followup.send(embed=kick_embed)
                response_sent = True
                return

            # OFFLINE case
            # Try multiple places for follower count
            follower_count_value = None
            try:
                cand = channel_info.get('followers_count') or channel_data.get('followers_count') or channel_data.get('user', {}).get('followers_count') or channel_data.get('follower_count') or channel_data.get('user', {}).get('follower_count')
                if cand is not None:
                    follower_count_value = int(cand)
            except Exception:
                follower_count_value = None

            follower_count = f"{follower_count_value:,}" if follower_count_value is not None else 'Unknown'

            kick_embed = discord.Embed(
                color=0x808080,
                title=f"⚫ {username} - Offline",
                description=f"{username} is currently not streaming on Kick.",
                url=f"https://kick.com/{username}",
                timestamp=interaction.created_at if interaction.created_at else None
            )

            kick_embed.add_field(name='👥 Followers', value=follower_count, inline=True)
            kick_embed.add_field(name='🔗 Channel', value=f"[Visit Channel](https://kick.com/{username})", inline=True)
            kick_embed.add_field(name='🔌 API Source', value='Kick Private API', inline=True)
            kick_embed.add_field(name='✅ Status', value='**Endpoint Working!**', inline=True)

            # avatar thumbnail
            try:
                avatar_url = user_info.get('profile_picture') or channel_data.get('user', {}).get('profile_pic') or channel_data.get('profile_pic')
                if avatar_url:
                    kick_embed.set_thumbnail(url=avatar_url)
            except Exception:
                pass

            kick_embed.set_footer(
                text='Made by JadaDev • Kick Private API',
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.followup.send(embed=kick_embed)
            response_sent = True
            return

        except Exception as error:
            print(f'[ERROR] Error: {error}')

            # If we haven't sent a followup yet, use followup to send error message
            try:
                if str(error) == 'CHANNEL_NOT_FOUND':
                    await interaction.followup.send(content=f"❌ Kick channel '{username}' not found. Please check the username and try again.")
                    return

                if str(error) in ['PRIVATE_API_FAILED', 'NO_DATA_RECEIVED']:
                    await interaction.followup.send(content=f"❌ Unable to retrieve data for '{username}'. The channel might not exist or there's a temporary issue. Try again later or check manually: https://kick.com/{username}")
                    return

                # General fallback embed
                error_embed = discord.Embed(
                    color=0xE74C3C,
                    title=f"❌ Unable to Check {username}",
                    description="There was an issue checking this Kick channel.",
                    timestamp=interaction.created_at if interaction.created_at else None
                )
                error_embed.add_field(name='🔍 Manual Check', value=f"[Visit {username} on Kick](https://kick.com/{username})", inline=False)
                error_embed.add_field(name='🔤 What to look for', value="Look for the red 'LIVE' badge on their channel page", inline=False)
                error_embed.set_footer(text='Made by JadaDev • Manual check recommended',
                                      icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

                await interaction.followup.send(embed=error_embed)
                response_sent = True
            except Exception as send_err:
                # if even followup fails, log it
                print(f'[ERROR] Failed to send followup/error message: {send_err}')

async def setup(bot):
    await bot.add_cog(KickLiveCommand(bot))
    print('Loaded enhanced kicklive command')
