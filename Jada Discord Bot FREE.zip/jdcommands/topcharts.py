import discord
from discord.ext import commands
from discord import app_commands
import aiohttp

class TopChartsCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="topcharts", description="Get trending music charts")
    @app_commands.describe(country="Country code (e.g., US, GB, FR) - leave empty for global")
    async def topcharts_command(self, interaction: discord.Interaction, country: str = ""):
        await interaction.response.defer()
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            country_code = country.upper() if country else "US"
            api_url = f"https://itunes.apple.com/{country_code.lower()}/rss/topsongs/limit=10/json"

            async with aiohttp.ClientSession() as session:
                async with session.get(api_url, headers=headers) as resp:
                    if resp.status != 200:
                        # fallback to US charts
                        api_url = "https://itunes.apple.com/us/rss/topsongs/limit=10/json"
                        async with session.get(api_url, headers=headers) as fallback_resp:
                            if fallback_resp.status != 200:
                                raise Exception("Could not fetch music charts.")
                            data = await fallback_resp.json(content_type=None)
                            country_code = "US"
                    else:
                        data = await resp.json(content_type=None)

            feed = data.get('feed', {})
            entries = feed.get('entry', [])
            if isinstance(entries, dict):
                entries = [entries]  # single entry case

            if not entries:
                raise Exception("No chart data available.")

            country_names = {
                'US': 'United States', 'GB': 'United Kingdom', 'FR': 'France',
                'DE': 'Germany', 'IT': 'Italy', 'ES': 'Spain', 'CA': 'Canada',
                'AU': 'Australia', 'JP': 'Japan', 'KR': 'South Korea'
            }
            country_display = country_names.get(country_code, country_code)

            embed = discord.Embed(
                title=f"🎶 Top Charts - {country_display}",
                color=discord.Color.purple(),
                timestamp=interaction.created_at
            )

            chart_text = ""
            for i, entry in enumerate(entries[:10], 1):
                title = entry.get('im:name', {}).get('label', 'Unknown Title')
                artist = entry.get('im:artist', {}).get('label', 'Unknown Artist')

                # Get link if available
                song_url = None
                link_data = entry.get('link')
                if isinstance(link_data, dict):
                    song_url = link_data.get('attributes', {}).get('href')
                elif isinstance(link_data, list) and link_data:
                    song_url = link_data[0].get('attributes', {}).get('href')

                # Shorten long titles / artists
                if len(title) > 25:
                    title = title[:22] + "..."
                if len(artist) > 20:
                    artist = artist[:17] + "..."

                # Clickable link if available
                if song_url:
                    chart_text += f"`{i:2}.` **[{title}]({song_url})**\n     *by {artist}*\n\n"
                else:
                    chart_text += f"`{i:2}.` **{title}**\n     *by {artist}*\n\n"

            embed.description = chart_text
            embed.add_field(name="Source", value="iTunes Charts", inline=True)
            embed.add_field(name="Updated", value=feed.get('updated', {}).get('label', 'Recently'), inline=True)
            embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)

            # Add thumbnail from first song if available
            if entries and entries[0].get('im:image'):
                images = entries[0]['im:image']
                if isinstance(images, list) and images:
                    largest_image = images[-1].get('label', '')
                    if largest_image:
                        embed.set_thumbnail(url=largest_image)

            embed.set_footer(
                text='Made by JadaDev • Top Charts Command • Data from iTunes',
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(
                text='Made by JadaDev • Top Charts Command',
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )
            await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(TopChartsCommand(bot))
    print('Loaded topcharts command')
