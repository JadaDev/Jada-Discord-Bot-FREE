import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json
import re

class LyricsCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="lyrics", description="Search for song lyrics")
    @app_commands.describe(
        song="Name of the song to search for (can include artist name)"
    )
    async def lyrics_command(self, interaction: discord.Interaction, song: str):
        """
        Song lyrics search command using Lyrics.ovh API
        """
        try:
            await interaction.response.defer()
            
            # Try to parse artist and song if formatted as "Artist - Song"
            if ' - ' in song:
                parts = song.split(' - ', 1)
                artist = parts[0].strip()
                title = parts[1].strip()
                search_query = song
            else:
                # If no clear separation, use the whole string as search
                artist = None
                title = song
                search_query = song
            
            async with aiohttp.ClientSession() as session:
                # First, try to search using a lyrics search API
                # Using a different approach - search for the song first
                if artist and title:
                    # Direct search if we have both artist and title
                    lyrics_url = f"https://api.lyrics.ovh/v1/{artist}/{title}"
                    
                    async with session.get(lyrics_url) as response:
                        if response.status == 200:
                            data = await response.json()
                            if data.get('lyrics'):
                                await self.send_lyrics_embed(interaction, data['lyrics'], f"{artist} - {title}", song)
                                return
                
                # If direct search failed or we don't have artist/title, try alternative search
                # Using a free search API (this is a fallback approach)
                search_url = "https://some-random-api.com/lyrics"
                search_params = {"title": search_query}
                
                async with session.get(search_url, params=search_params) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data.get('lyrics'):
                            song_title = f"{data.get('author', 'Unknown Artist')} - {data.get('title', title)}"
                            await self.send_lyrics_embed(interaction, data['lyrics'], song_title, search_query, data.get('thumbnail', {}).get('genius'))
                            return
                
                # If all APIs fail, show no results message
                embed = discord.Embed(
                    title="❌ No Lyrics Found",
                    description=f"No lyrics found for '{song}'. Try:\n"
                               "• Including the artist name\n"
                               "• Using format: `Artist - Song Title`\n"
                               "• Checking the spelling\n"
                               "• Trying a more common song title",
                    color=discord.Color.red()
                )
                embed.set_footer(text='Made by JadaDev • Lyrics Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                await interaction.followup.send(embed=embed)
                    
        except aiohttp.ClientError:
            embed = discord.Embed(
                title="❌ Connection Error",
                description="Failed to connect to lyrics database. Please try again later.",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Lyrics Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred while searching for lyrics: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Lyrics Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)
    
    async def send_lyrics_embed(self, interaction, lyrics, song_title, original_query, thumbnail_url=None):
        """
        Send lyrics in a formatted embed
        """
        # Clean up lyrics
        lyrics = lyrics.strip()
        
        # Discord embed description limit is 4096 characters
        if len(lyrics) > 4000:
            lyrics = lyrics[:4000] + "\n\n*[Lyrics truncated due to length limit]*"
        
        # Create embed
        embed = discord.Embed(
            title=f"🎵 {song_title}",
            description=f"```\n{lyrics}\n```",
            color=discord.Color.green(),
            timestamp=interaction.created_at
        )
        
        if thumbnail_url:
            embed.set_thumbnail(url=thumbnail_url)
        
        embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
        embed.add_field(name="Search Query", value=original_query, inline=True)
        
        embed.set_footer(text='Made by JadaDev • Lyrics Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
        
        await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(LyricsCommand(bot))
    print('Loaded lyrics command')