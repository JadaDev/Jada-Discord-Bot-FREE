import discord
from discord.ext import commands
from discord import app_commands

class BanCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(
        member="The member to ban",
        reason="Reason for banning the member",
        delete_message_days="Number of days of messages to delete (0-7)"
    )
    async def ban_command(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided", delete_message_days: int = 0):
        """
        Ban command with proper permission checks and message deletion options
        """
        try:
            # Validate delete_message_days parameter
            if delete_message_days < 0 or delete_message_days > 7:
                await interaction.response.send_message("❌ Delete message days must be between 0 and 7!", ephemeral=True)
                return
            
            # Check if the user has ban permissions
            if not interaction.user.guild_permissions.ban_members:
                await interaction.response.send_message("❌ You don't have permission to ban members!", ephemeral=True)
                return
            
            # Check if the bot has ban permissions
            if not interaction.guild.me.guild_permissions.ban_members:
                await interaction.response.send_message("❌ I don't have permission to ban members!", ephemeral=True)
                return
            
            # Check role hierarchy
            if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
                await interaction.response.send_message("❌ You cannot ban someone with a higher or equal role!", ephemeral=True)
                return
            
            if member.top_role >= interaction.guild.me.top_role:
                await interaction.response.send_message("❌ I cannot ban someone with a higher or equal role than me!", ephemeral=True)
                return
            
            # Cannot ban the server owner
            if member == interaction.guild.owner:
                await interaction.response.send_message("❌ Cannot ban the server owner!", ephemeral=True)
                return
            
            # Try to DM the member before banning
            try:
                dm_embed = discord.Embed(
                    title="You have been banned",
                    description=f"You were banned from {interaction.guild.name}",
                    color=discord.Color.red()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
                dm_embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled or blocked the bot
            
            # Perform the ban
            await member.ban(reason=f"Banned by {interaction.user} - {reason}", delete_message_days=delete_message_days)
            
            # Create embed response
            embed = discord.Embed(
                title="🔨 Member Banned",
                color=discord.Color.red(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="Member", value=f"{member.mention} ({member})", inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            if delete_message_days > 0:
                embed.add_field(name="Messages Deleted", value=f"{delete_message_days} day(s)", inline=False)
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)
                
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to ban this member!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)
    
    @app_commands.command(name="unban", description="Unban a user from the server")
    @app_commands.describe(
        user_id="The ID of the user to unban",
        reason="Reason for unbanning the user"
    )
    async def unban_command(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason provided"):
        """
        Unban command to remove a user from the ban list
        """
        try:
            # Check if the user has ban permissions
            if not interaction.user.guild_permissions.ban_members:
                await interaction.response.send_message("❌ You don't have permission to unban members!", ephemeral=True)
                return
            
            # Check if the bot has ban permissions
            if not interaction.guild.me.guild_permissions.ban_members:
                await interaction.response.send_message("❌ I don't have permission to unban members!", ephemeral=True)
                return
            
            # Validate user ID
            try:
                user_id_int = int(user_id)
            except ValueError:
                await interaction.response.send_message("❌ Invalid user ID!", ephemeral=True)
                return
            
            # Get the banned user
            try:
                banned_user = await self.bot.fetch_user(user_id_int)
            except discord.NotFound:
                await interaction.response.send_message("❌ User not found!", ephemeral=True)
                return
            
            # Check if user is actually banned
            try:
                await interaction.guild.fetch_ban(banned_user)
            except discord.NotFound:
                await interaction.response.send_message("❌ This user is not banned!", ephemeral=True)
                return
            
            # Perform the unban
            await interaction.guild.unban(banned_user, reason=f"Unbanned by {interaction.user} - {reason}")
            
            # Create embed response
            embed = discord.Embed(
                title="✅ Member Unbanned",
                color=discord.Color.green(),
                timestamp=interaction.created_at
            )
            embed.add_field(name="User", value=f"{banned_user.mention} ({banned_user})", inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.set_thumbnail(url=banned_user.display_avatar.url)
            embed.set_footer(text='Made by JadaDev • Moderation Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)
                
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to unban members!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(BanCommand(bot))
    print('Loaded ban command')
