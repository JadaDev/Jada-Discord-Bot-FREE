import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import io

class ImageTools(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # 🖼️ Generate image with Pollinations API
    @app_commands.command(name="generate_image", description="Generate an AI image from a text prompt")
    @app_commands.describe(prompt="The description of the image you want to generate")
    async def generate_image_command(self, interaction: discord.Interaction, prompt: str):
        await interaction.response.defer()
        try:
            api_url = f"https://image.pollinations.ai/prompt/{prompt.replace(' ', '%20')}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url) as resp:
                    if resp.status != 200:
                        return await interaction.followup.send(f"❌ Failed (status {resp.status})")

                    data = await resp.read()
                    file = discord.File(io.BytesIO(data), filename="generated.png")

            await interaction.followup.send(
                content=f"🎨 Generated image for: **{prompt}**",
                file=file
            )
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {str(e)}", ephemeral=True)

    # ☁️ Upload image to FileUp.tn (no key required)
    @app_commands.command(name="upload_image", description="Upload an image to FileUp.tn and get a shareable link")
    @app_commands.describe(image="The image file you want to upload")
    async def upload_image_command(self, interaction: discord.Interaction, image: discord.Attachment):
        await interaction.response.defer()
        try:
            upload_url = "https://fileup.tn/img/api.php"
            img_bytes = await image.read()

            async with aiohttp.ClientSession() as session:
                form = aiohttp.FormData()
                form.add_field("image", img_bytes, filename=image.filename, content_type="application/octet-stream")

                async with session.post(upload_url, data=form) as resp:
                    result = await resp.json()

            if result.get("success"):
                link = result["url"]
                await interaction.followup.send(f"✅ Uploaded: {link}")
            else:
                error_msg = result.get("error", "Unknown error")
                await interaction.followup.send(f"❌ Upload failed: {error_msg}")

        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {str(e)}", ephemeral=True)

    # 🌍 Random placeholder image
    @app_commands.command(name="random_image", description="Fetch a random placeholder image")
    async def random_image_command(self, interaction: discord.Interaction):
        await interaction.response.defer()
        try:
            api_url = "https://picsum.photos/600/400"

            async with aiohttp.ClientSession() as session:
                async with session.get(api_url) as resp:
                    data = await resp.read()
                    file = discord.File(io.BytesIO(data), filename="random.png")

            await interaction.followup.send(
                content="📸 Here's a random image from Lorem Picsum",
                file=file
            )
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ImageTools(bot))
    print("Loaded image commands")
