import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional

class AvatarCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="avatar", description="Get a user's profile picture")
    @app_commands.describe(member="The user to get avatar for (defaults to yourself)")
    async def avatar_command(self, interaction: discord.Interaction, member: Optional[discord.Member] = None):
        """
        Display a user's Discord avatar in high quality
        """
        try:
            # Default to caller if no member specified
            if member is None:
                member = interaction.user

            # Get the member's avatar URL
            avatar_url = member.display_avatar.url

            # Create embed
            embed = discord.Embed(
                title=f"{member.display_name}'s Avatar",
                color=member.color if isinstance(member, discord.Member) and member.color != discord.Color.default() else discord.Color.blue(),
                timestamp=interaction.created_at
            )

            # Set the avatar as the main image
            embed.set_image(url=avatar_url)

            # Add some metadata
            embed.add_field(
                name="🤖 User Info",
                value=f"**Username:** {member.name}#{member.discriminator}\n**ID:** `{member.id}`",
                inline=False
            )

            # Avatar format and size info
            embed.add_field(
                name="🖼️ Avatar Info",
                value="High-quality image available for download",
                inline=True
            )

            # Add a download link
            embed.add_field(
                name="⬇️ Download",
                value=f"[Click Here]({avatar_url})",
                inline=True
            )

            embed.set_footer(
                text=f"Made by JadaDev • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            # Add the member's avatar as thumbnail (smaller version)
            embed.set_thumbnail(url=member.display_avatar.url)

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(AvatarCommand(bot))
    print('Loaded avatar command')
