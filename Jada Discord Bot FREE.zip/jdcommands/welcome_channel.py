import discord
from discord.ext import commands
from discord import app_commands
import json
import os
from PIL import Image, ImageDraw, ImageFont
import io
import aiohttp

WELCOME_JSON = "welcome_channel.json"

if os.path.exists(WELCOME_JSON):
    with open(WELCOME_JSON, "r") as f:
        WELCOME_DATA = json.load(f)
else:
    WELCOME_DATA = {}

def save_welcome_data():
    with open(WELCOME_JSON, "w") as f:
        json.dump(WELCOME_DATA, f, indent=4)

# Predefined colors
COLOR_MAP = {
    "white": "#FFFFFF",
    "red": "#FF0000",
    "green": "#00FF00",
    "blue": "#0000FF",
    "yellow": "#FFFF00",
    "cyan": "#00FFFF",
    "magenta": "#FF00FF",
    "black": "#000000",
    "orange": "#FFA500",
    "purple": "#800080",
    "pink": "#FFC0CB"
}

def parse_color(color_input: str):
    """Convert color name or hex string to a valid hex code"""
    if not color_input:
        return "#FFFFFF"
    color_input = color_input.lower()
    if color_input in COLOR_MAP:
        return COLOR_MAP[color_input]
    if color_input.startswith("#") and len(color_input) == 7:
        return color_input
    return "#FFFFFF"

class Welcomer(commands.Cog):
    """Professional Welcome System with top-centered text and dynamic images"""

    def __init__(self, bot):
        self.bot = bot
        self.bot.http_session = aiohttp.ClientSession()

    # ------------------ /welcome_channel ------------------
    @app_commands.command(name="welcome_channel", description="Set up a welcome channel")
    @app_commands.describe(
        channel="Channel to send welcome messages",
        message="Welcome message (use {user}, {server}, {count})",
        image="Optional background image URL",
        color="Text color (name like 'red', 'white' or hex like #FFFFFF)",
        enabled="Enable/disable the welcome system"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def welcome_channel(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        message: str = None,
        image: str = None,
        color: str = "white",
        enabled: bool = True
    ):
        await interaction.response.defer(ephemeral=True)
        try:
            guild_id = str(interaction.guild.id)
            if not message:
                message = "Welcome {user} to {server}! We now have {count} members."
            color_hex = parse_color(color)
            WELCOME_DATA[guild_id] = {
                "channel_id": channel.id,
                "message": message,
                "image": image,
                "color": color_hex,
                "enabled": enabled
            }
            save_welcome_data()
            await interaction.followup.send(f"✅ Welcome channel set to {channel.mention}", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {e}", ephemeral=True)

    # ------------------ /welcome_edit ------------------
    @app_commands.command(name="welcome_edit", description="Edit the welcome settings")
    @app_commands.describe(
        message="New welcome message (optional)",
        image="New embed image URL (optional)",
        color="Text color (name or hex, optional)",
        enabled="Enable/disable welcome messages (optional)"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def welcome_edit(
        self,
        interaction: discord.Interaction,
        message: str = None,
        image: str = None,
        color: str = None,
        enabled: bool = None
    ):
        await interaction.response.defer(ephemeral=True)
        try:
            guild_id = str(interaction.guild.id)
            if guild_id not in WELCOME_DATA:
                return await interaction.followup.send("⚠️ No welcome setup found.", ephemeral=True)
            data = WELCOME_DATA[guild_id]
            if message is not None:
                data["message"] = message
            if image is not None:
                data["image"] = image
            if color is not None:
                data["color"] = parse_color(color)
            if enabled is not None:
                data["enabled"] = enabled
            save_welcome_data()
            await interaction.followup.send("✅ Welcome settings updated.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ Error: {e}", ephemeral=True)

    # ------------------ /welcome_status ------------------
    @app_commands.command(name="welcome_status", description="Check current welcome settings")
    @app_commands.checks.has_permissions(administrator=True)
    async def welcome_status(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        if guild_id not in WELCOME_DATA:
            return await interaction.response.send_message("⚠️ No welcome setup found.", ephemeral=True)
        data = WELCOME_DATA[guild_id]
        channel = interaction.guild.get_channel(data["channel_id"])
        embed = discord.Embed(title="Welcome Settings", color=discord.Color.blue())
        embed.add_field(name="Channel", value=channel.mention if channel else "Not found")
        embed.add_field(name="Message", value=data.get("message", ""))
        embed.add_field(name="Image", value=data.get("image") or "None")
        embed.add_field(name="Text Color", value=data.get("color", "#FFFFFF"))
        embed.add_field(name="Enabled", value=str(data.get("enabled", True)))
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ------------------ Generate welcome image ------------------
    async def generate_welcome_image(self, member: discord.Member, base_image_url=None, text_color="#FFFFFF"):
        try:
            # Default size if no image
            width, height = 900, 300

            # Load base image
            if base_image_url:
                async with self.bot.http_session.get(base_image_url) as resp:
                    data = await resp.read()
                img = Image.open(io.BytesIO(data)).convert("RGBA")
                width, height = img.size  # Keep original size
            else:
                img = Image.new("RGBA", (width, height), (54, 57, 63, 255))

            draw = ImageDraw.Draw(img)

            font_path = "arial.ttf"
            font_large = ImageFont.truetype(font_path, max(40, width // 15))
            font_small = ImageFont.truetype(font_path, max(25, width // 30))

            welcome_text = f"Welcome {member.name}"
            server_text = member.guild.name

            bbox_welcome = draw.textbbox((0, 0), welcome_text, font=font_large)
            w_welcome = bbox_welcome[2] - bbox_welcome[0]
            h_welcome = bbox_welcome[3] - bbox_welcome[1]

            bbox_server = draw.textbbox((0, 0), server_text, font=font_small)
            w_server = bbox_server[2] - bbox_server[0]
            h_server = bbox_server[3] - bbox_server[1]

            # Top-centered placement
            padding_top = 20  # distance from top
            gap = 60          # distance between welcome and server name

            x_welcome = (width - w_welcome) // 2
            y_welcome = padding_top
            x_server = (width - w_server) // 2
            y_server = padding_top + h_welcome + gap  # server name slightly below welcome

            shadow_offset = 2
            draw.text((x_welcome + shadow_offset, y_welcome + shadow_offset), welcome_text, font=font_large, fill=(0,0,0))
            draw.text((x_server + shadow_offset, y_server + shadow_offset), server_text, font=font_small, fill=(0,0,0))

            draw.text((x_welcome, y_welcome), welcome_text, font=font_large, fill=text_color)
            draw.text((x_server, y_server), server_text, font=font_small, fill=(255, 255, 255))

            buffer = io.BytesIO()
            img.save(buffer, format="PNG")
            buffer.seek(0)
            return buffer

        except Exception as e:
            print(f"Error generating image: {e}")
            return None

    # ------------------ Event listener ------------------
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild_id = str(member.guild.id)
        if guild_id not in WELCOME_DATA:
            return
        data = WELCOME_DATA[guild_id]
        if not data.get("enabled", True):
            return

        channel = member.guild.get_channel(data["channel_id"])
        if not channel:
            return

        message = data.get(
            "message",
            "Welcome {user} to {server}! We now have {count} members."
        )
        message = message.replace("{user}", member.mention)\
                         .replace("{server}", member.guild.name)\
                         .replace("{count}", str(len(member.guild.members)))

        text_color = data.get("color", "#FFFFFF")
        img_file = await self.generate_welcome_image(member, data.get("image"), text_color)

        if img_file:
            file = discord.File(fp=img_file, filename="welcome.png")
            embed = discord.Embed(color=discord.Color.green())
            embed.set_image(url="attachment://welcome.png")
            await channel.send(content=message, file=file, embed=embed)
        else:
            await channel.send(content=message)

async def setup(bot):
    await bot.add_cog(Welcomer(bot))
    print("Loaded welcome_channel command")
