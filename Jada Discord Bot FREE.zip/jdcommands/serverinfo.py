import discord
from discord.ext import commands
from discord import app_commands
import datetime

class ServerInfoCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="serverinfo", description="Get detailed server information")
    async def serverinfo_command(self, interaction: discord.Interaction):
        """
        Display comprehensive server statistics and information
        """
        guild = interaction.guild
        if not guild:
            await interaction.response.send_message(
                "❌ This command can only be used in a server!", ephemeral=True
            )
            return

        try:
            # Ensure all members are cached for accurate status counts
            if not guild.chunked:
                await guild.chunk()

            # Basic guild info
            owner = guild.owner
            total_members = len(guild.members)
            bot_count = len([m for m in guild.members if m.bot])

            # Member status
            status_counts = {
                "online": 0,
                "idle": 0,
                "dnd": 0,
                "offline": 0
            }
            for member in guild.members:
                if member.status == discord.Status.online:
                    status_counts["online"] += 1
                elif member.status == discord.Status.idle:
                    status_counts["idle"] += 1
                elif member.status == discord.Status.dnd:
                    status_counts["dnd"] += 1
                else:
                    status_counts["offline"] += 1

            # Channels
            text_channels = len([c for c in guild.channels if isinstance(c, discord.TextChannel)])
            voice_channels = len([c for c in guild.channels if isinstance(c, discord.VoiceChannel)])
            category_channels = len([c for c in guild.channels if isinstance(c, discord.CategoryChannel)])

            # Roles
            role_count = len(guild.roles)

            # Server age
            created_at = guild.created_at
            days_since_creation = (datetime.datetime.now(datetime.timezone.utc) - created_at).days

            # Features & boosts
            features = guild.features or []
            boost_count = guild.premium_subscription_count
            boost_level = guild.premium_tier
            verification_level = str(guild.verification_level).title().replace('_', ' ')
            icon_url = guild.icon.url if guild.icon else None

            # Create embed
            embed = discord.Embed(
                title=f"🏠 {guild.name}",
                color=guild.owner.color if owner and owner.color != discord.Color.default() else discord.Color.blue(),
                timestamp=interaction.created_at
            )

            if icon_url:
                embed.set_thumbnail(url=icon_url)

            # Add fields
            embed.add_field(name="👑 Owner", value=f"{owner.mention}" if owner else "Unknown", inline=True)
            embed.add_field(name="🆔 Server ID", value=f"`{guild.id}`", inline=True)
            embed.add_field(name="📅 Created", value=f"{created_at.strftime('%B %d, %Y')}", inline=True)

            embed.add_field(
                name="👥 Members",
                value=f"**Total:** {total_members:,}\n**Humans:** {total_members - bot_count:,}\n**Bots:** {bot_count:,}",
                inline=True
            )

            embed.add_field(
                name="🌐 Online Status",
                value=f"🟢 {status_counts['online']:,}\n🟡 {status_counts['idle']:,}\n🔴 {status_counts['dnd']:,}\n⚫ {status_counts['offline']:,}",
                inline=True
            )

            embed.add_field(
                name="📺 Channels",
                value=f"💬 {text_channels:,}\n🔊 {voice_channels:,}\n📂 {category_channels:,}",
                inline=True
            )

            embed.add_field(name="🏷️ Roles", value=f"{role_count:,}", inline=True)
            embed.add_field(name="🛡️ Verification", value=verification_level, inline=True)

            if boost_count > 0:
                embed.add_field(name="🚀 Boosts", value=f"Level {boost_level}\n{boost_count} boosts", inline=True)

            embed.add_field(name="📆 Server Age", value=f"{days_since_creation:,} days", inline=True)

            if hasattr(guild, 'preferred_locale'):
                embed.add_field(name="🌍 Locale", value=str(guild.preferred_locale), inline=True)

            # Server features
            feature_map = {
                'COMMUNITY': 'Community Server',
                'VERIFIED': 'Verified',
                'PARTNERED': 'Partnered',
                'DISCOVERABLE': 'Discoverable',
                'PREVIEW_ENABLED': 'Preview Enabled',
                'ANIMATED_ICON': 'Animated Icon',
                'BANNER': 'Banner'
            }
            feature_list = [feature_map[f] for f in features if f in feature_map]
            if feature_list:
                embed.add_field(name="💎 Features", value=", ".join(feature_list[:3]), inline=False)

            # Description
            if guild.description:
                description = (guild.description[:500] + "...") if len(guild.description) > 500 else guild.description
                embed.add_field(name="ℹ️ Description", value=description, inline=False)

            # Vanity URL
            if guild.vanity_url_code:
                embed.add_field(name="🔗 Vanity URL", value=f"(discord.gg/{guild.vanity_url_code})", inline=True)

            embed.set_footer(
                text=f"Made by JadaDev • Server Information • Requested by {interaction.user.display_name}",
                icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s"
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(ServerInfoCommand(bot))
    print("Loaded serverinfo command")
