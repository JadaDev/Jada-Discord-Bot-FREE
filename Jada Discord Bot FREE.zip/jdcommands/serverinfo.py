import discord
from discord.ext import commands
from discord import app_commands
import datetime
from typing import Optional

class ServerInfoCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="serverinfo", description="Get detailed server information")
    async def serverinfo_command(self, interaction: discord.Interaction):
        """
        Display comprehensive server statistics and information
        """
        try:
            guild = interaction.guild
            if not guild:
                await interaction.response.send_message("❌ This command can only be used in a server!", ephemeral=True)
                return

            # Get server owner
            owner = guild.owner

            # Count members by status
            total_members = len(guild.members)
            online_members = len([m for m in guild.members if str(m.status) == 'online'])
            idle_members = len([m for m in guild.members if str(m.status) == 'idle'])
            dnd_members = len([m for m in guild.members if str(m.status) == 'dnd'])
            offline_members = total_members - online_members - idle_members - dnd_members
            bot_count = len([m for m in guild.members if m.bot])

            # Count channels
            text_channels = len([c for c in guild.channels if isinstance(c, discord.TextChannel)])
            voice_channels = len([c for c in guild.channels if isinstance(c, discord.VoiceChannel)])
            category_channels = len([c for c in guild.channels if isinstance(c, discord.CategoryChannel)])
            total_channels = len(guild.channels)

            # Count roles
            role_count = len(guild.roles)

            # Server creation date
            created_at = guild.created_at
            days_since_creation = (datetime.datetime.now(datetime.timezone.utc) - created_at).days

            # Server features
            features = guild.features or []
            premium_tier = guild.premium_tier

            # Nitro boost information
            boost_count = guild.premium_subscription_count
            boost_level = guild.premium_tier

            # Server verification level
            verification_level = str(guild.verification_level).title().replace('_', ' ')

            # Server icon URL
            icon_url = guild.icon.url if guild.icon else None

            # Create main embed
            embed = discord.Embed(
                title=f"🏠 {guild.name}",
                color=guild.owner.color if owner and owner.color != discord.Color.default() else discord.Color.blue(),
                timestamp=interaction.created_at
            )

            # Set server icon as thumbnail
            if icon_url:
                embed.set_thumbnail(url=icon_url)

            # Basic Info
            embed.add_field(name="👑 Owner", value=f"{owner.mention}" if owner else "Unknown", inline=True)
            embed.add_field(name="🆔 Server ID", value=f"`{guild.id}`", inline=True)
            embed.add_field(name="📅 Created", value=f"{created_at.strftime('%B %d, %Y')}", inline=True)

            # Member Statistics
            embed.add_field(
                name="👥 Members",
                value=f"**Total:** {total_members:,}\n**Humans:** {total_members - bot_count:,}\n**Bots:** {bot_count:,}",
                inline=True
            )

            # Online Status
            embed.add_field(
                name="🌐 Online Status",
                value=f"🟢 {online_members:,}\n🟡 {idle_members:,}\n🔴 {dnd_members:,}\n⚫ {offline_members:,}",
                inline=True
            )

            # Channel Count
            embed.add_field(
                name="📺 Channels",
                value=f"💬 {text_channels:,}\n🔊 {voice_channels:,}\n📂 {category_channels:,}",
                inline=True
            )

            # Additional Info
            embed.add_field(name="🏷️ Roles", value=f"{role_count:,}", inline=True)
            embed.add_field(name="🛡️ Verification", value=verification_level, inline=True)

            if boost_count > 0:
                embed.add_field(name="🚀 Boosts", value=f"Level {boost_level}\n{boost_count} boosts", inline=True)

            # Server Age
            embed.add_field(
                name="📆 Server Age",
                value=f"{days_since_creation:,} days",
                inline=True
            )

            # Server Region (if available)
            if hasattr(guild, 'preferred_locale'):
                embed.add_field(name="🌍 Locale", value=str(guild.preferred_locale), inline=True)

            # Server Features (premium features)
            feature_list = []
            if 'COMMUNITY' in features:
                feature_list.append('Community Server')
            if 'VERIFIED' in features:
                feature_list.append('Verified')
            if 'PARTNERED' in features:
                feature_list.append('Partnered')
            if 'DISCOVERABLE' in features:
                feature_list.append('Discoverable')
            if 'PREVIEW_ENABLED' in features:
                feature_list.append('Preview Enabled')
            if 'ANIMATED_ICON' in features:
                feature_list.append('Animated Icon')
            if 'BANNER' in features:
                feature_list.append('Banner')

            if feature_list:
                embed.add_field(
                    name="💎 Features",
                    value=", ".join(feature_list[:3]),  # Limit to 3 features
                    inline=False
                )

            # Description if exists
            if guild.description:
                description = guild.description[:500] + "..." if len(guild.description) > 500 else guild.description
                embed.add_field(
                    name="ℹ️ Description",
                    value=description,
                    inline=False
                )

            # Vanity URL if exists
            if guild.vanity_url_code:
                embed.add_field(
                    name="🔗 Vanity URL",
                    value=f"(discord.gg/{guild.vanity_url_code})",
                    inline=True
                )

            embed.set_footer(
                text=f"Made by JadaDev • Server Information • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ServerInfoCommand(bot))
    print('Loaded serverinfo command')
