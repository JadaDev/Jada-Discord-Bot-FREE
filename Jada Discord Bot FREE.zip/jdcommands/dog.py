import discord
from discord.ext import commands
from discord import app_commands
import aiohttp

class DogCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="dog", description="Get a random dog picture")
    async def dog_command(self, interaction: discord.Interaction):
        """
        Get a random dog picture from Dog CEO API
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("https://dog.ceo/api/breeds/image/random", headers={'User-Agent': 'DiscordBot/1.0'}) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message("❌ Could not fetch dog picture!", ephemeral=True)
                        return

                    data = await resp.json()
        except Exception:
            await interaction.response.send_message("❌ Could not fetch dog picture!", ephemeral=True)
            return

        if data.get('status') != 'success':
            await interaction.response.send_message("❌ Failed to get dog picture!", ephemeral=True)
            return

        dog_url = data.get('message')
        if not dog_url:
            await interaction.response.send_message("❌ No dog picture available!", ephemeral=True)
            return

        embed = discord.Embed(
            title="🐕 Random Dog",
            color=discord.Color.blue(),
            timestamp=interaction.created_at
        )

        embed.set_image(url=dog_url)
        embed.set_footer(
            text="Made by JadaDev • Powered by Dog CEO API",
            icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
        )

        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(DogCommand(bot))
    print('Loaded dog command')
