import discord
from discord.ext import commands
from discord import app_commands
import aiohttp

class WeatherCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="weather", description="Shows current weather information for a specified city.")
    @app_commands.describe(city="City name (e.g., London, New York)")
    async def weather_command(self, interaction: discord.Interaction, city: str):
        """
        Fetch current weather data using wttr.in API (no API key required)
        """
        await interaction.response.defer()

        if not city:
            await interaction.edit_original_response(content="Please specify a city name!")
            return

        try:
            # Using wttr.in API (no key required)
            async with aiohttp.ClientSession() as session:
                url = f"https://wttr.in/{city.replace(' ', '%20')}?format=j1"
                async with session.get(url) as resp:
                    if resp.status != 200:
                        await interaction.followup.send(f"❌ Weather data not found for \"{city}\". Please check the city name and try again.", ephemeral=True)
                        return
                    weatherData = await resp.json()

            if not weatherData.get('current_condition') or not weatherData['current_condition']:
                await interaction.followup.send(f"❌ Weather data not found for \"{city}\". Please check the city name and try again.", ephemeral=True)
                return

            if not weatherData.get('nearest_area') or not weatherData['nearest_area']:
                await interaction.followup.send(f"❌ Location data not found for \"{city}\". Please check the city name and try again.", ephemeral=True)
                return

            current = weatherData['current_condition'][0]
            location = weatherData['nearest_area'][0]

            # Extract weather data
            areaName = location['areaName'][0]['value']
            country = location['country'][0]['value']
            temp_c = float(current['temp_C'])
            temp_f = float(current['temp_F'])
            feels_like_c = float(current['FeelsLikeC'])
            feels_like_f = float(current['FeelsLikeF'])
            humidity = current['humidity']
            weather_desc = current['weatherDesc'][0]['value']
            wind_speed_kmph = current['windspeedKmph']
            wind_dir = current['winddir16Point']
            visibility_km = current['visibility']
            pressure_mb = current['pressure']
            precip_mm = current['precipMM']
            uv_index = current['uvIndex']

            # Get weather icon emoji based on weather description
            def get_weather_emoji(desc):
                description = desc.lower()
                if 'sunny' in description or 'clear' in description:
                    return '☀️'
                if 'cloud' in description:
                    return '☁️'
                if 'rain' in description:
                    return '🌧️'
                if 'snow' in description:
                    return '❄️'
                if 'storm' in description or 'thunder' in description:
                    return '⛈️'
                if 'fog' in description or 'mist' in description:
                    return '🌫️'
                return '🌤️'

            icon = get_weather_emoji(weather_desc)

            # Create embed
            embed = discord.Embed(
                title=f"{icon} Weather in {areaName}, {country}",
                description=weather_desc,
                color=0x87CEEB,  # Sky blue color
                timestamp=interaction.created_at
            )

            embed.add_field(name="🌡️ Temperature", value=f"{temp_c:.1f}°C / {temp_f:.1f}°F", inline=True)
            embed.add_field(name="🌡️ Feels Like", value=f"{feels_like_c:.1f}°C / {feels_like_f:.1f}°F", inline=True)
            embed.add_field(name="💧 Humidity", value=f"{humidity}%", inline=True)
            embed.add_field(name="💨 Wind Speed", value=f"{wind_speed_kmph} km/h", inline=True)
            embed.add_field(name="🧭 Wind Direction", value=wind_dir, inline=True)
            embed.add_field(name="👁️ Visibility", value=f"{visibility_km} km", inline=True)
            embed.add_field(name="🌊 Pressure", value=f"{pressure_mb} mb", inline=True)
            embed.add_field(name="☔ Precipitation", value=f"{precip_mm} mm", inline=True)
            embed.add_field(name="☀️ UV Index", value=str(uv_index), inline=True)

            embed.set_footer(
                text="Made by JadaDev • Powered by wttr.in",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.edit_original_response(embed=embed)

        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(WeatherCommand(bot))
    print('Loaded weather command')
