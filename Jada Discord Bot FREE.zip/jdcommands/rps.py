import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional
import random

class RockPaperScissorsCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="rps", description="Play rock, paper, scissors against the bot")
    @app_commands.describe(choice="Your choice (rock, paper, or scissors)")
    async def rps_command(self, interaction: discord.Interaction, choice: str):
        """
        Play a game of rock, paper, scissors against the bot
        """
        try:
            # Available choices and emojis
            choices = {
                "rock": {"emoji": "🗿", "beats": "scissors"},
                "paper": {"emoji": "📄", "beats": "rock"},
                "scissors": {"emoji": "✂️", "beats": "paper"}
            }

            # Normalize input
            user_choice = choice.lower().strip()

            # Validate choice
            if user_choice not in choices:
                await interaction.response.send_message("❌ Please choose rock, paper, or scissors!", ephemeral=True)
                return

            # Bot's choice
            bot_choice = random.choice(list(choices.keys()))

            # Determine winner
            if user_choice == bot_choice:
                result = "tie"
                color = discord.Color.greyple()
            elif choices[user_choice]["beats"] == bot_choice:
                result = "win"
                color = discord.Color.green()
            else:
                result = "lose"
                color = discord.Color.red()

            # Create embed
            embed = discord.Embed(
                title="✂️ Rock, Paper, Scissors",
                color=color,
                timestamp=interaction.created_at
            )

            embed.add_field(
                name="You Chose",
                value=f"{choices[user_choice]['emoji']} {user_choice.title()}",
                inline=True
            )

            embed.add_field(
                name="Bot Chose",
                value=f"{choices[bot_choice]['emoji']} {bot_choice.title()}",
                inline=True
            )

            embed.add_field(
                name="Result",
                value=f"**{result.title()}!**",
                inline=True
            )

            # Add some fun messages
            if result == "win":
                embed.set_footer(text="Made by JadaDev • Nice one! 🎉", icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            elif result == "lose":
                embed.set_footer(text="Made by JadaDev • Better luck next time! 😢", icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            else:
                embed.set_footer(text="Made by JadaDev • A fair match! 🤝", icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(RockPaperScissorsCommand(bot))
    print('Loaded rps command')
