import discord
from discord.ext import commands
from discord import app_commands, Embed
import aiohttp
import os
from urllib.parse import quote
from typing import Optional


class MovieCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.omdb_api_key = os.getenv('OMDB_API_KEY')
        self.tmdb_api_key = os.getenv('TMDB_API_KEY')

        # Free demo keys for fallback
        self.omdb_demo_keys = ['b6003d8a', '2edf0976', '3c6e0b8e']
        self.tmdb_demo_keys = ['3fd2be6f0c70a2a598f084ddfb75487c', 'your_api_key_here']

    @app_commands.command(name="movie", description="Gets movie details, ratings, and information using multiple movie APIs.")
    @app_commands.describe(title="Movie title to search for")
    async def movie_command(self, interaction: discord.Interaction, title: str):
        """
        Gets movie details, ratings, and information using OMDB/TMDb APIs with fallback options.
        """
        if not title:
            await interaction.response.send_message("Please specify a movie title!", ephemeral=True)
            return

        movie_title = title

        try:
            movie_data = None

            # Try multiple movie APIs with working free endpoints
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }

            # Method 1: Try OMDB API with demo keys
            omdb_success = False
            for api_key in self.omdb_demo_keys:
                try:
                    print(f"Trying OMDB with key: {api_key[:4]}...")
                    omdb_url = f"https://www.omdbapi.com/?apikey={api_key}&t={quote(movie_title)}"
                    async with aiohttp.ClientSession() as session:
                        async with session.get(omdb_url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as response:
                            if response.status == 200:
                                data = await response.json()
                                if data.get('Response') == 'True':
                                    movie_data = {
                                        'title': data.get('Title', 'N/A'),
                                        'year': data.get('Year', 'N/A'),
                                        'rated': data.get('Rated', 'N/A'),
                                        'released': data.get('Released', 'N/A'),
                                        'runtime': data.get('Runtime', 'N/A'),
                                        'genre': data.get('Genre', 'N/A'),
                                        'director': data.get('Director', 'N/A'),
                                        'writer': data.get('Writer', 'N/A'),
                                        'actors': data.get('Actors', 'N/A'),
                                        'plot': data.get('Plot', 'No plot available.'),
                                        'language': data.get('Language', 'N/A'),
                                        'country': data.get('Country', 'N/A'),
                                        'awards': data.get('Awards', 'None'),
                                        'poster': data.get('Poster') if data.get('Poster') != 'N/A' else None,
                                        'ratings': data.get('Ratings', []),
                                        'imdb_rating': data.get('imdbRating', 'N/A'),
                                        'imdb_votes': data.get('imdbVotes', 'N/A'),
                                        'imdb_id': data.get('imdbID'),
                                        'type': data.get('Type'),
                                        'box_office': data.get('BoxOffice'),
                                        'source': 'OMDB'
                                    }
                                    omdb_success = True
                                    print("OMDB API worked!")
                                    break
                except Exception as e:
                    print(f"OMDB key {api_key[:4]}... failed: {str(e)}")
                    continue

            # Method 2: Try TMDb API with demo keys
            tmdb_success = False
            if not omdb_success:
                for api_key in self.tmdb_demo_keys:
                    try:
                        print(f"Trying TMDb with key: {api_key[:8]}...")
                        search_url = f"https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={quote(movie_title)}"
                        async with aiohttp.ClientSession() as session:
                            async with session.get(search_url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as search_resp:
                                if search_resp.status == 200:
                                    search_data = await search_resp.json()
                                    if search_data.get('results') and len(search_data['results']) > 0:
                                        movie = search_data['results'][0]

                                        # Get detailed info
                                        detail_url = f"https://api.themoviedb.org/3/movie/{movie['id']}?api_key={api_key}"
                                        async with session.get(detail_url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as detail_resp:
                                            if detail_resp.status == 200:
                                                details = await detail_resp.json()

                                                movie_data = {
                                                    'title': details.get('title', 'N/A'),
                                                    'year': str(details.get('release_date', 'N/A'))[:4] if details.get('release_date') else 'N/A',
                                                    'rated': 'N/A',
                                                    'released': details.get('release_date', 'N/A'),
                                                    'runtime': f"{details.get('runtime', 0)} min" if details.get('runtime') else 'N/A',
                                                    'genre': ', '.join([g['name'] for g in details.get('genres', [])]) if details.get('genres') else 'N/A',
                                                    'director': 'N/A',
                                                    'plot': details.get('overview', 'No plot available.'),
                                                    'language': details.get('original_language', 'N/A').upper(),
                                                    'country': ', '.join([c['name'] for c in details.get('production_countries', [])]) if details.get('production_countries') else 'N/A',
                                                    'poster': f"https://image.tmdb.org/t/p/w500{details['poster_path']}" if details.get('poster_path') else None,
                                                    'tmdb_rating': details.get('vote_average'),
                                                    'tmdb_votes': details.get('vote_count'),
                                                    'popularity': details.get('popularity'),
                                                    'budget': details.get('budget'),
                                                    'revenue': details.get('revenue'),
                                                    'source': 'TMDb'
                                                }
                                                tmdb_success = True
                                                print("TMDb API worked!")
                                                break
                    except Exception as e:
                        print(f"TMDb key {api_key[:8]}... failed: {str(e)}")
                        continue

            if not omdb_success and not tmdb_success:
                # Method 3: Alternative OMDB API
                try:
                    print("Trying alternative OMDB API...")
                    alt_url = f"https://www.omdbapi.com/?apikey=trilogy&t={quote(movie_title)}"
                    async with aiohttp.ClientSession() as session:
                        async with session.get(alt_url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as response:
                            if response.status == 200:
                                data = await response.json()
                                if data.get('Response') == 'True':
                                    movie_data = {
                                        'title': data.get('Title', 'N/A'),
                                        'year': data.get('Year', 'N/A'),
                                        'rated': data.get('Rated', 'N/A'),
                                        'released': data.get('Released', 'N/A'),
                                        'runtime': data.get('Runtime', 'N/A'),
                                        'genre': data.get('Genre', 'N/A'),
                                        'director': data.get('Director', 'N/A'),
                                        'plot': data.get('Plot', 'No plot available.'),
                                        'poster': data.get('Poster') if data.get('Poster') != 'N/A' else None,
                                        'imdb_rating': data.get('imdbRating', 'N/A'),
                                        'imdb_id': data.get('imdbID'),
                                        'source': 'OMDB Alternative'
                                    }
                                    print("Alternative OMDB API worked!")
                except Exception as e:
                    print(f"Alternative OMDB API failed: {str(e)}")
                    # All APIs failed - provide search links
                    embed = Embed(
                        color=0xF5C518,
                        title=f"🎬 Movie Search: \"{movie_title}\"",
                        description=f"I couldn't fetch detailed movie data, but here are multiple ways to find \"{movie_title}\":"
                    )
                    embed.add_field(
                        name="🔗 IMDb",
                        value=f"[Search on IMDb](https://www.imdb.com/find?q={quote(movie_title)})",
                        inline=True
                    )
                    embed.add_field(
                        name="🔗 Rotten Tomatoes",
                        value=f"[Search on RT](https://www.rottentomatoes.com/search?search={quote(movie_title)})",
                        inline=True
                    )
                    embed.add_field(
                        name="🔗 The Movie Database",
                        value=f"[Search on TMDb](https://www.themoviedb.org/search?query={quote(movie_title)})",
                        inline=True
                    )
                    embed.add_field(
                        name="🔍 Google Search",
                        value=f"[Google \"{movie_title}\" movie](https://www.google.com/search?q={quote(movie_title + ' movie')})",
                        inline=True
                    )
                    embed.add_field(
                        name="🎭 Letterboxd",
                        value=f"[Search on Letterboxd](https://letterboxd.com/search/films/{quote(movie_title)}/)",
                        inline=True
                    )
                    embed.add_field(
                        name="📺 JustWatch",
                        value=f"[Find where to watch](https://www.justwatch.com/us/search?q={quote(movie_title)})",
                        inline=True
                    )
                    embed.add_field(
                        name="ℹ️ API Status",
                        value="All movie APIs are currently unavailable. This is usually temporary.",
                        inline=False
                    )
                    embed.add_field(
                        name="🔧 For Developers",
                        value="Get free API keys from [OMDb](http://www.omdbapi.com/) or [TMDb](https://www.themoviedb.org/settings/api)",
                        inline=False
                    )
                    embed.set_footer(
                        text="Made by JadaDev • Multiple fallback options available",
                        icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s"
                    )
                    await interaction.response.send_message(embed=embed)
                    return

            if not movie_data:
                await interaction.response.send_message(f"Movie \"{movie_title}\" not found. Please check the spelling and try again.", ephemeral=True)
                return

            # Format ratings
            ratings_text = ''
            if movie_data.get('imdb_rating') and movie_data['imdb_rating'] != 'N/A':
                ratings_text += f"IMDb: {movie_data['imdb_rating']}/10"
                if movie_data.get('imdb_votes') and movie_data['imdb_votes'] != 'N/A':
                    ratings_text += f" ({movie_data['imdb_votes']})"
            elif movie_data.get('tmdb_rating'):
                ratings_text += f"TMDb: {movie_data['tmdb_rating']}/10"
                if movie_data.get('tmdb_votes'):
                    ratings_text += f" ({movie_data['tmdb_votes']:,})"

            if not ratings_text:
                ratings_text = 'N/A'

            # Truncate plot
            plot = movie_data.get('plot', 'No plot available.')
            if len(plot) > 600:
                plot = plot[:597] + '...'

            # Create embed
            embed = Embed(
                color=0xF5C518,
                title=f"🎬 {movie_data['title']} ({movie_data['year']})",
                description=plot,
                timestamp=interaction.created_at
            )

            # Basic fields
            embed.add_field(name="⭐ Rating", value=ratings_text, inline=True)
            embed.add_field(name="🎭 Genre", value=movie_data.get('genre', 'N/A'), inline=True)
            embed.add_field(name="⏱️ Runtime", value=movie_data.get('runtime', 'N/A'), inline=True)
            embed.add_field(name="📅 Released", value=movie_data.get('released', 'N/A'), inline=True)
            embed.add_field(name="🎬 Director", value=movie_data.get('director', 'N/A'), inline=True)
            embed.add_field(name="🌍 Country", value=movie_data.get('country', 'N/A'), inline=True)
            embed.add_field(name="🔌 API Source", value=movie_data.get('source', 'Movie Database'), inline=True)

            # Add poster
            if movie_data.get('poster'):
                embed.set_thumbnail(url=movie_data['poster'])

            # Add actors if available
            if movie_data.get('actors') and movie_data['actors'] != 'N/A':
                actors_text = movie_data['actors']
                if len(actors_text) > 200:
                    actors_text = actors_text[:197] + '...'
                embed.add_field(name="👥 Cast", value=actors_text, inline=False)

            # Add box office if available
            if movie_data.get('box_office') and movie_data['box_office'] != 'N/A':
                embed.add_field(name="💰 Box Office", value=movie_data['box_office'], inline=True)

            # Add awards if available
            if movie_data.get('awards') and movie_data['awards'] != 'N/A' and movie_data['awards'] != 'None':
                awards_text = movie_data['awards']
                if len(awards_text) > 200:
                    awards_text = awards_text[:197] + '...'
                embed.add_field(name="🏆 Awards", value=awards_text, inline=False)

            # Add IMDb link if available
            if movie_data.get('imdb_id'):
                embed.add_field(
                    name="🔗 IMDb",
                    value=f"[View on IMDb](https://www.imdb.com/title/{movie_data['imdb_id']}/)",
                    inline=True
                )

            embed.set_footer(
                text="Made by JadaDev • Multiple Movie APIs",
                icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB1KocToJVP_Sw&s"
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            print(f"Error fetching movie data: {str(e)}")
            await interaction.response.send_message("Sorry, I couldn't fetch movie data right now. Please try again later.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(MovieCommand(bot))
    print('Loaded movie command')
