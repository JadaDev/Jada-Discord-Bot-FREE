import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import os
from typing import Optional

class CryptoCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

        # Popular cryptocurrency IDs for CoinGecko
        self.crypto_ids = {
            'btc': 'bitcoin',
            'bitcoin': 'bitcoin',
            'eth': 'ethereum',
            'ethereum': 'ethereum',
            'ada': 'cardano',
            'cardano': 'cardano',
            'bnb': 'binancecoin',
            'binancecoin': 'binancecoin',
            'sol': 'solana',
            'solana': 'solana',
            'dot': 'polkadot',
            'polkadot': 'polkadot',
            'dogecoin': 'dogecoin',
            'doge': 'dogecoin',
            'shiba': 'shiba-inu',
            'matic': 'matic-network',
            'polygon': 'matic-network',
            'avax': 'avalanche-2',
            'avalanche': 'avalanche-2',
            'luna': 'terra-luna',
            'terra': 'terra-luna'
        }

    @app_commands.command(name="crypto", description="Get cryptocurrency information")
    @app_commands.describe(symbol="Crypto symbol (e.g., BTC, ETH, ADA)")
    async def crypto_command(self, interaction: discord.Interaction, symbol: str):
        """
        Get cryptocurrency price and information from CoinGecko
        """
        try:
            # Normalize symbol
            symbol = symbol.lower().strip()

            # Get full coin name
            if symbol not in self.crypto_ids:
                await interaction.response.send_message(f"❌ Cryptocurrency '{symbol}' not found! Use: BTC, ETH, ADA, SOL, DOGE, etc.", ephemeral=True)
                return

            coin_id = self.crypto_ids[symbol]

            # CoinGecko API call (free, no API key required for basic use)
            async with aiohttp.ClientSession() as session:
                url = f"https://api.coingecko.com/api/v3/coins/{coin_id}"
                async with session.get(url) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message("❌ Could not fetch crypto data!", ephemeral=True)
                        return

                    data = await resp.json()

            # Extract price data
            usd_price = data['market_data']['current_price']['usd']
            usd_change_24h = data['market_data']['price_change_percentage_24h'] or 0
            usd_change_7d = data['market_data']['price_change_percentage_7d'] or 0

            # Market data
            market_cap = data['market_data']['market_cap']['usd']
            volume_24h = data['market_data']['total_volume']['usd']
            rank = data['market_data']['market_cap_rank']

            # Coin details
            name = data['name']
            symbol_display = data['symbol'].upper()

            # Determine color based on 24h change
            if usd_change_24h > 0:
                color = discord.Color.green()
                trend_emoji = "📈"
            elif usd_change_24h < 0:
                color = discord.Color.red()
                trend_emoji = "📉"
            else:
                color = discord.Color.blue()
                trend_emoji = "➡️"

            # Create embed
            embed = discord.Embed(
                title=f"{trend_emoji} {name} ({symbol_display})",
                color=color,
                timestamp=interaction.created_at
            )

            # Add thumbnail
            if 'image' in data and data['image'].get('large'):
                embed.set_thumbnail(url=data['image']['large'])

            # Price information
            embed.add_field(
                name="💰 Current Price",
                value=f"${usd_price:,.2f}",
                inline=True
            )

            # 24h change
            change_color = "🟢" if usd_change_24h >= 0 else "🔴"
            embed.add_field(
                name="📊 24h Change",
                value=f"{change_color} {usd_change_24h:.2f}%",
                inline=True
            )

            # 7d change if available
            if usd_change_7d != 0:
                change_7d_color = "🟢" if usd_change_7d >= 0 else "🔴"
                embed.add_field(
                    name="📈 7d Change",
                    value=f"{change_7d_color} {usd_change_7d:.2f}%",
                    inline=True
                )

            # Market data
            embed.add_field(
                name="🏆 Market Rank",
                value=f"#{rank}",
                inline=True
            )

            embed.add_field(
                name="💼 Market Cap",
                value=f"${market_cap:,.2f}",
                inline=True
            )

            embed.add_field(
                name="📊 24h Volume",
                value=f"${volume_24h:,.2f}",
                inline=True
            )

            # Additional info
            if 'description' in data and data['description'].get('en'):
                description = data['description']['en'][:300]
                if len(data['description']['en']) > 300:
                    description += "..."
                embed.add_field(
                    name="ℹ️ About",
                    value=description,
                    inline=False
                )

            embed.set_footer(
                text=f"Made by JadaDev • Data from CoinGecko • Powered by CoinGecko API",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(CryptoCommand(bot))
    print('Loaded crypto command')
