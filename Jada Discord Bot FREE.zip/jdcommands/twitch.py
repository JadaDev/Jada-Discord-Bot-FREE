import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import os
from typing import Optional
import datetime

class TwitchCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.client_id = os.getenv('TWITCH_CLIENT_ID')
        self.client_secret = os.getenv('TWITCH_CLIENT_SECRET')

    async def _get_twitch_token(self):
        """Get OAuth token for Twitch API"""
        if not self.client_id or not self.client_secret:
            return None

        try:
            async with aiohttp.ClientSession() as session:
                url = "https://id.twitch.tv/oauth2/token"
                data = {
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                    'grant_type': 'client_credentials'
                }
                async with session.post(url, data=data) as resp:
                    if resp.status == 200:
                        token_data = await resp.json()
                        return token_data.get('access_token')
        except Exception as e:
            print(f"Twitch token error: {e}")
            return None
        return None

    @app_commands.command(name="twitch", description="Check if a Twitch streamer is live")
    @app_commands.describe(username="Twitch username to check")
    async def twitch_command(self, interaction: discord.Interaction, username: str):
        """
        Check Twitch stream status and provide stream information
        """
        try:
            # Normalize username
            username = username.lower().strip()

            if not username:
                await interaction.response.send_message(f"<@{interaction.user.id}> Please specify a Twitch username!", ephemeral=True)
                return

            # Try main Twitch API first
            if self.client_id and self.client_secret:
                await self._check_with_twitch_api(interaction, username)
            else:
                # Fallback to public APIs
                await self._check_with_fallback_api(interaction, username)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

    async def _check_with_twitch_api(self, interaction: discord.Interaction, username: str):
        """Check using official Twitch API"""
        try:
            # Get access token
            token = await self._get_twitch_token()
            if not token:
                await interaction.response.send_message("❌ Could not authenticate with Twitch!", ephemeral=True)
                return

            # Get user ID first
            async with aiohttp.ClientSession() as session:
                headers = {
                    'Client-ID': self.client_id,
                    'Authorization': f'Bearer {token}'
                }

                # Get user info
                user_url = f"https://api.twitch.tv/helix/users?login={username}"
                async with session.get(user_url, headers=headers) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message(f"❌ Could not find Twitch user '{username}'!", ephemeral=True)
                        return

                    user_data = await resp.json()

                    if not user_data['data']:
                        await interaction.response.send_message(f"❌ Twitch user '{username}' not found!", ephemeral=True)
                        return

                    user = user_data['data'][0]
                    user_id = user['id']
                    display_name = user['display_name']
                    profile_image = user.get('profile_image_url')

                # Check streaming status
                stream_url = f"https://api.twitch.tv/helix/streams?user_login={username}"
                async with session.get(stream_url, headers=headers) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message("❌ Error checking stream status!", ephemeral=True)
                        return

                    stream_data = await resp.json()

                    # If user is live
                    if stream_data['data']:
                        stream = stream_data['data'][0]

                        # Live stream info
                        title = stream['title']
                        game = stream['game_name']
                        viewer_count = stream['viewer_count']
                        started_at = stream['started_at']  # ISO 8601 format

                        # Calculate uptime
                        started_dt = datetime.datetime.fromisoformat(started_at.replace('Z', '+00:00'))
                        uptime_seconds = int((datetime.datetime.now(datetime.timezone.utc) - started_dt).total_seconds())
                        uptime = self._format_uptime(uptime_seconds)

                        embed = discord.Embed(
                            title=f"🔴 {display_name} - LIVE",
                            url=f"https://www.twitch.tv/{username}",
                            description=title or "No title",
                            color=0x9146FF,
                            timestamp=interaction.created_at
                        )

                        if profile_image:
                            embed.set_thumbnail(url=profile_image)

                        embed.add_field(name="🎮 Game", value=game or "No game", inline=True)
                        embed.add_field(name="👁️ Viewers", value=f"{viewer_count:,}", inline=True)
                        embed.add_field(name="⏱️ Uptime", value=uptime, inline=True)

                        # Set image
                        thumbnail_url = stream.get('thumbnail_url')
                        if thumbnail_url:
                            thumbnail_url = thumbnail_url.replace('{width}', '1280').replace('{height}', '720')
                            embed.set_image(url=thumbnail_url)

                        embed.set_footer(text="Made by JadaDev • Powered by Twitch", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s")

                    else:
                        # User is offline
                        embed = discord.Embed(
                            title=f"📺 {username} - Offline",
                            url=f"https://www.twitch.tv/{username}",
                            description=f"{username} is currently not streaming.",
                            color=0x9146FF,
                            timestamp=interaction.created_at
                        )

                        if profile_image:
                            embed.set_thumbnail(url=profile_image)

                        # Try to get channel description
                        try:
                            channel_url = f"https://api.twitch.tv/helix/channels?broadcaster_id={user_id}"
                            async with session.get(channel_url, headers=headers) as channel_resp:
                                if channel_resp.status == 200:
                                    channel_data = await channel_resp.json()
                                    if channel_data['data']:
                                        description = channel_data['data'][0].get('description', '')
                                        if description:
                                            embed.add_field(name="📝 Bio", value=description[:200] + "..." if len(description) > 200 else description, inline=False)

                        except:
                            pass

                        embed.add_field(name="🔗 Channel", value=f"[Visit Channel](https://twitch.tv/{username})", inline=True)
                        embed.set_footer(text="Made by JadaDev • Powered by Twitch", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s")

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            # If main API fails, try fallback
            await self._check_with_fallback_api(interaction, username)

    async def _check_with_fallback_api(self, interaction: discord.Interaction, username: str):
        """Fallback to decapi.me public APIs"""
        try:
            async with aiohttp.ClientSession() as session:
                # Check uptime first
                uptime_url = f"https://decapi.me/twitch/uptime/{username}"
                async with session.get(uptime_url) as resp:
                    if resp.status != 200:
                        await interaction.response.send_message(f"<@{interaction.user.id}> Twitch user '{username}' not found. Please check the username and try again.", ephemeral=True)
                        return

                    uptime = await resp.text()

                    if "not live" in uptime.lower() or "offline" in uptime.lower():
                        # Stream is offline
                        embed = discord.Embed(
                            title=f"📺 {username} - Offline",
                            description=f"{username} is currently not streaming.",
                            url=f"https://twitch.tv/{username}",
                            color=0x9146FF,
                            timestamp=interaction.created_at
                        )
                        embed.add_field(name="🔗 Channel", value=f"[Visit Channel](https://twitch.tv/{username})", inline=True)
                        embed.set_footer(text="Made by JadaDev • Powered by Twitch", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s")

                        await interaction.response.send_message(embed=embed)
                        return

                    else:
                        # Stream is live
                        embed = discord.Embed(
                            title=f"🔴 {username} - LIVE",
                            description=f"{username} is currently streaming!",
                            url=f"https://twitch.tv/{username}",
                            color=0x9146FF,
                            timestamp=interaction.created_at
                        )

                        embed.add_field(name="⏱️ Uptime", value=uptime, inline=True)
                        embed.add_field(name="🔗 Watch Now", value=f"[View Stream](https://twitch.tv/{username})", inline=True)

                        # Try to get additional info
                        try:
                            title_response = await session.get(f"https://decapi.me/twitch/title/{username}")
                            game_response = await session.get(f"https://decapi.me/twitch/game/{username}")
                            viewers_response = await session.get(f"https://decapi.me/twitch/viewercount/{username}")

                            if title_response.status == 200:
                                title = await title_response.text()
                                if title and not title.lower().startswith("user not found"):
                                    embed.add_field(name="📝 Title", value=title if len(title) <= 75 else title[:75] + "...", inline=False)
                                    embed.description = title

                            if game_response.status == 200:
                                game = await game_response.text()
                                if game and not game.lower().startswith("user not found"):
                                    embed.add_field(name="🎮 Game", value=game, inline=True)

                            if viewers_response.status == 200:
                                viewers = await viewers_response.text()
                                if viewers and viewers.isdigit():
                                    embed.add_field(name="👁️ Viewers", value=f"{int(viewers):,}", inline=True)

                        except:
                            pass

                        embed.set_footer(text="Made by JadaDev • Powered by Twitch", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s")

                        await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message("❌ An error occurred while fetching Twitch data. Please try again later.", ephemeral=True)

    def _format_uptime(self, seconds):
        """Format uptime in a human-readable way"""
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        if hours > 0:
            return f"{hours}h {minutes}m"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"

async def setup(bot):
    await bot.add_cog(TwitchCommand(bot))
    print('Loaded twitch command')
