import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json
import re

class ColorCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def hex_to_rgb(self, hex_color):
        """Convert hex to RGB"""
        hex_color = hex_color.lstrip('#')
        if len(hex_color) == 3:
            hex_color = ''.join([c*2 for c in hex_color])
        try:
            return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        except ValueError:
            return None
    
    def rgb_to_hsl(self, r, g, b):
        """Convert RGB to HSL"""
        r, g, b = r/255.0, g/255.0, b/255.0
        max_val = max(r, g, b)
        min_val = min(r, g, b)
        h, s, l = 0, 0, (max_val + min_val) / 2
        
        if max_val == min_val:
            h = s = 0  # achromatic
        else:
            d = max_val - min_val
            s = d / (2 - max_val - min_val) if l > 0.5 else d / (max_val + min_val)
            if max_val == r:
                h = (g - b) / d + (6 if g < b else 0)
            elif max_val == g:
                h = (b - r) / d + 2
            elif max_val == b:
                h = (r - g) / d + 4
            h /= 6
        
        return int(h*360), int(s*100), int(l*100)
    
    def is_valid_hex(self, hex_color):
        """Validate hex color"""
        hex_pattern = re.compile(r'^#?([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$')
        return hex_pattern.match(hex_color) is not None
    
    @app_commands.command(name="color", description="Get color information from hex code")
    @app_commands.describe(
        hex_code="Hex color code (e.g., #FF5733 or FF5733)"
    )
    async def color_command(self, interaction: discord.Interaction, hex_code: str):
        """
        Color information command with color preview
        """
        try:
            await interaction.response.defer()
            
            # Clean and validate hex code
            original_hex = hex_code
            hex_code = hex_code.strip().upper()
            if not hex_code.startswith('#'):
                hex_code = '#' + hex_code
            
            if not self.is_valid_hex(hex_code):
                embed = discord.Embed(
                    title="❌ Invalid Hex Code",
                    description="Please provide a valid hex color code.\n"
                               "Examples: `#FF5733`, `FF5733`, `#f73`, `f73`",
                    color=discord.Color.red()
                )
                embed.set_footer(text='Made by JadaDev • Color Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                await interaction.followup.send(embed=embed)
                return
            
            # Convert to RGB
            rgb = self.hex_to_rgb(hex_code)
            if not rgb:
                embed = discord.Embed(
                    title="❌ Invalid Color",
                    description="Could not parse the provided hex color code.",
                    color=discord.Color.red()
                )
                embed.set_footer(text='Made by JadaDev • Color Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                await interaction.followup.send(embed=embed)
                return
            
            r, g, b = rgb
            
            # Convert to HSL
            h, s, l = self.rgb_to_hsl(r, g, b)
            
            # Convert hex to Discord color integer
            discord_color = int(hex_code.lstrip('#'), 16)
            
            # Create embed with the color
            embed = discord.Embed(
                title=f"🎨 Color Information",
                color=discord_color,
                timestamp=interaction.created_at
            )
            
            # Generate color preview using an API
            color_api_url = f"https://singlecolorimage.com/get/{hex_code.lstrip('#')}/400x200"
            embed.set_image(url=color_api_url)
            
            # Add color information
            embed.add_field(
                name="Hex Code",
                value=f"`{hex_code}`",
                inline=True
            )
            
            embed.add_field(
                name="RGB",
                value=f"`rgb({r}, {g}, {b})`",
                inline=True
            )
            
            embed.add_field(
                name="HSL",
                value=f"`hsl({h}°, {s}%, {l}%)`",
                inline=True
            )
            
            # Color brightness (perceived luminance)
            luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
            brightness = "Bright" if luminance > 0.5 else "Dark"
            
            embed.add_field(
                name="Brightness",
                value=f"{brightness} ({luminance:.2f})",
                inline=True
            )
            
            # Complementary color
            comp_r = 255 - r
            comp_g = 255 - g
            comp_b = 255 - b
            comp_hex = f"#{comp_r:02X}{comp_g:02X}{comp_b:02X}"
            
            embed.add_field(
                name="Complementary",
                value=f"`{comp_hex}`",
                inline=True
            )
            
            # CSS formats
            embed.add_field(
                name="CSS Formats",
                value=f"```css\ncolor: {hex_code};\ncolor: rgb({r}, {g}, {b});\ncolor: hsl({h}, {s}%, {l}%);\n```",
                inline=False
            )
            
            # Color name (approximation)
            color_names = {
                (255, 0, 0): "Red", (0, 255, 0): "Green", (0, 0, 255): "Blue",
                (255, 255, 0): "Yellow", (255, 0, 255): "Magenta", (0, 255, 255): "Cyan",
                (255, 255, 255): "White", (0, 0, 0): "Black", (128, 128, 128): "Gray",
                (255, 165, 0): "Orange", (128, 0, 128): "Purple", (165, 42, 42): "Brown",
                (255, 192, 203): "Pink", (0, 128, 0): "Dark Green", (0, 0, 139): "Dark Blue"
            }
            
            # Find closest color name (basic approximation)
            closest_name = "Unknown"
            min_distance = float('inf')
            for (cr, cg, cb), name in color_names.items():
                distance = ((r - cr) ** 2 + (g - cg) ** 2 + (b - cb) ** 2) ** 0.5
                if distance < min_distance:
                    min_distance = distance
                    closest_name = name
            
            embed.add_field(
                name="Approximate Name",
                value=closest_name,
                inline=True
            )
            
            embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
            
            embed.set_footer(text='Made by JadaDev • Color Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            
            await interaction.followup.send(embed=embed)
                    
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Color Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(ColorCommand(bot))
    print('Loaded color command')