import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json

class TrendingCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="trending", description="Get trending topics from various sources")
    @app_commands.describe(
        source="Source to get trending topics from"
    )
    @app_commands.choices(source=[
        app_commands.Choice(name="Reddit - Hot Posts", value="reddit_hot"),
        app_commands.Choice(name="Reddit - Top Daily", value="reddit_top"),
        app_commands.Choice(name="GitHub - Trending Repos", value="github"),
        app_commands.Choice(name="Hacker News - Top Stories", value="hackernews"),
        app_commands.Choice(name="Product Hunt - Info", value="producthunt")
    ])
    async def trending_command(self, interaction: discord.Interaction, source: str = "reddit_hot"):
        """
        Trending topics command using various free APIs
        """
        try:
            await interaction.response.defer()
            
            if source.startswith("reddit"):
                await self.get_reddit_trending(interaction, source)
            elif source == "github":
                await self.get_github_trending(interaction)
            elif source == "hackernews":
                await self.get_hackernews_trending(interaction)
            elif source == "producthunt":
                await self.get_producthunt_trending(interaction)
                    
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)
    
    async def get_reddit_trending(self, interaction, source_type):
        """Get trending posts from Reddit"""
        try:
            # Reddit API endpoint
            if source_type == "reddit_hot":
                api_url = "https://www.reddit.com/hot.json?limit=10"
                title_prefix = "🔥 Reddit Hot Posts"
            else:  # reddit_top
                api_url = "https://www.reddit.com/top.json?t=day&limit=10"
                title_prefix = "⬆️ Reddit Top Daily"
            
            async with aiohttp.ClientSession() as session:
                headers = {'User-Agent': 'Discord Bot 1.0'}
                async with session.get(api_url, headers=headers) as response:
                    if response.status != 200:
                        embed = discord.Embed(
                            title="❌ Reddit Unavailable",
                            description="Could not fetch Reddit data. Please try again later.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    data = await response.json()
                    posts = data.get('data', {}).get('children', [])
                    
                    if not posts:
                        embed = discord.Embed(
                            title="❌ No Trending Posts",
                            description="No trending posts found at the moment.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    embed = discord.Embed(
                        title=title_prefix,
                        color=discord.Color.orange(),
                        timestamp=interaction.created_at
                    )
                    
                    trending_text = ""
                    for i, post in enumerate(posts[:8], 1):
                        post_data = post.get('data', {})
                        title = post_data.get('title', 'No Title')
                        subreddit = post_data.get('subreddit', 'unknown')
                        score = post_data.get('score', 0)
                        comments = post_data.get('num_comments', 0)
                        permalink = post_data.get('permalink', '')
                        post_url = f"https://reddit.com{permalink}"

                        # Truncate long titles
                        if len(title) > 60:
                            title = title[:57] + "..."

                        trending_text += f"`{i}.` **[{title}]({post_url})**\n"
                        trending_text += f"     📊 {score:,} ↑ | 💬 {comments:,} | r/{subreddit}\n\n"
                    
                    embed.description = trending_text
                    embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
                    embed.set_footer(text='Made by JadaDev • Trending Command • Data from Reddit', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                    
                    await interaction.followup.send(embed=embed)
        except Exception as e:
            await self.send_error(interaction, str(e))
    
    async def get_github_trending(self, interaction):
        """Get trending repositories from GitHub"""
        try:
            # GitHub Search API for trending repos
            api_url = "https://api.github.com/search/repositories"
            params = {
                'q': 'created:>2024-01-01',
                'sort': 'stars',
                'order': 'desc',
                'per_page': 8
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url, params=params) as response:
                    if response.status != 200:
                        embed = discord.Embed(
                            title="❌ GitHub Unavailable",
                            description="Could not fetch GitHub trending data. Please try again later.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    data = await response.json()
                    repos = data.get('items', [])
                    
                    if not repos:
                        embed = discord.Embed(
                            title="❌ No Trending Repos",
                            description="No trending repositories found at the moment.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    embed = discord.Embed(
                        title="⭐ GitHub Trending Repositories",
                        color=discord.Color.dark_gray(),
                        timestamp=interaction.created_at
                    )
                    
                    trending_text = ""
                    for i, repo in enumerate(repos[:8], 1):
                        name = repo.get('full_name', 'Unknown')
                        description = repo.get('description', 'No description')
                        stars = repo.get('stargazers_count', 0)
                        language = repo.get('language', 'Unknown')
                        html_url = repo.get('html_url', '')

                        # Truncate long descriptions
                        if description and len(description) > 50:
                            description = description[:47] + "..."

                        trending_text += f"`{i}.` **[{name}]({html_url})**\n"
                        trending_text += f"     {description}\n"
                        trending_text += f"     ⭐ {stars:,} | 💻 {language}\n\n"
                    
                    embed.description = trending_text
                    embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
                    embed.set_footer(text='Made by JadaDev • Trending Command • Data from GitHub', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                    
                    await interaction.followup.send(embed=embed)
        except Exception as e:
            await self.send_error(interaction, str(e))
    
    async def get_hackernews_trending(self, interaction):
        """Get trending stories from Hacker News"""
        try:
            # Hacker News API
            top_stories_url = "https://hacker-news.firebaseio.com/v0/topstories.json"
            
            async with aiohttp.ClientSession() as session:
                # Get top story IDs
                async with session.get(top_stories_url) as response:
                    if response.status != 200:
                        embed = discord.Embed(
                            title="❌ Hacker News Unavailable",
                            description="Could not fetch Hacker News data. Please try again later.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    story_ids = await response.json()
                    
                    if not story_ids:
                        embed = discord.Embed(
                            title="❌ No Stories Found",
                            description="No trending stories found at the moment.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    # Get details for top 8 stories
                    stories = []
                    for story_id in story_ids[:8]:
                        story_url = f"https://hacker-news.firebaseio.com/v0/item/{story_id}.json"
                        async with session.get(story_url) as story_response:
                            if story_response.status == 200:
                                story_data = await story_response.json()
                                if story_data and story_data.get('type') == 'story':
                                    stories.append(story_data)
                    
                    embed = discord.Embed(
                        title="📰 Hacker News Top Stories",
                        color=discord.Color.orange(),
                        timestamp=interaction.created_at
                    )
                    
                    trending_text = ""
                    for i, story in enumerate(stories, 1):
                        title = story.get('title', 'No Title')
                        score = story.get('score', 0)
                        comments = story.get('descendants', 0)
                        story_id = story.get('id', 0)
                        story_url = story.get('url', f"https://news.ycombinator.com/item?id={story_id}")

                        # Truncate long titles
                        if len(title) > 60:
                            title = title[:57] + "..."

                        trending_text += f"`{i}.` **[{title}]({story_url})**\n"
                        trending_text += f"     📊 {score} points | 💬 {comments} comments\n\n"
                    
                    embed.description = trending_text
                    embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
                    embed.set_footer(text='Made by JadaDev • Trending Command • Data from Hacker News', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                    
                    await interaction.followup.send(embed=embed)
        except Exception as e:
            await self.send_error(interaction, str(e))
    
    async def get_producthunt_trending(self, interaction):
        """Get trending products (using a fallback approach since Product Hunt API requires auth)"""
        try:
            # Since Product Hunt API requires authentication, we'll provide a helpful message
            # with alternative trending tech sources
            embed = discord.Embed(
                title="🚀 Product Hunt Trending",
                description="**Product Hunt API requires authentication.**\n\n"
                           "**Alternative trending sources:**\n"
                           "• Use `/trending source:github` for trending repos\n"
                           "• Use `/trending source:hackernews` for tech news\n"
                           "• Use `/trending source:reddit_hot` for general trends\n\n"
                           "**Manual Product Hunt Access:**\n"
                           "Visit [producthunt.com](https://www.producthunt.com) directly to see today's trending products!",
                color=discord.Color.gold(),
                timestamp=interaction.created_at
            )
            
            embed.add_field(
                name="💡 Tip",
                value="Product Hunt showcases the best new products every day, voted on by the community!",
                inline=False
            )
            
            embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
            embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            
            await interaction.followup.send(embed=embed)
        except Exception as e:
            await self.send_error(interaction, str(e))
    
    async def send_error(self, interaction, error_msg):
        """Send error message"""
        embed = discord.Embed(
            title="❌ Connection Error",
            description="Failed to connect to trending data source. Please try again later.",
            color=discord.Color.red()
        )
        embed.set_footer(text='Made by JadaDev • Trending Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
        await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(TrendingCommand(bot))
    print('Loaded trending command')
