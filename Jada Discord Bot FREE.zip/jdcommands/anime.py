import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import json

class AnimeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="anime", description="Search for anime information")
    @app_commands.describe(
        name="Name of the anime to search for"
    )
    async def anime_command(self, interaction: discord.Interaction, name: str):
        """
        Anime search command using Jikan API (MyAnimeList)
        """
        try:
            await interaction.response.defer()
            
            # Jikan API endpoint for anime search
            search_url = "https://api.jikan.moe/v4/anime"
            
            async with aiohttp.ClientSession() as session:
                # Search for anime
                search_params = {
                    'q': name,
                    'limit': 1
                }
                
                async with session.get(search_url, params=search_params) as response:
                    if response.status != 200:
                        embed = discord.Embed(
                            title="❌ API Error",
                            description="Failed to connect to anime database. Please try again later.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Anime Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    data = await response.json()
                    
                    if not data.get('data') or len(data['data']) == 0:
                        embed = discord.Embed(
                            title="❌ No Results Found",
                            description=f"No anime found for '{name}'. Try a different search term.",
                            color=discord.Color.red()
                        )
                        embed.set_footer(text='Made by JadaDev • Anime Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                        await interaction.followup.send(embed=embed)
                        return
                    
                    anime = data['data'][0]
                    
                    # Create embed
                    embed = discord.Embed(
                        title=f"📺 {anime.get('title', 'Unknown Title')}",
                        url=anime.get('url', ''),
                        color=discord.Color.blue(),
                        timestamp=interaction.created_at
                    )
                    
                    # Add description (limit to 1024 characters)
                    synopsis = anime.get('synopsis', 'No synopsis available.')
                    if synopsis and len(synopsis) > 1020:
                        synopsis = synopsis[:1020] + "..."
                    
                    embed.description = synopsis
                    
                    # Add thumbnail
                    if anime.get('images', {}).get('jpg', {}).get('image_url'):
                        embed.set_thumbnail(url=anime['images']['jpg']['image_url'])
                    
                    # Add fields
                    embed.add_field(
                        name="Type", 
                        value=anime.get('type', 'Unknown'), 
                        inline=True
                    )
                    
                    embed.add_field(
                        name="Episodes", 
                        value=str(anime.get('episodes', 'Unknown')), 
                        inline=True
                    )
                    
                    embed.add_field(
                        name="Status", 
                        value=anime.get('status', 'Unknown'), 
                        inline=True
                    )
                    
                    embed.add_field(
                        name="Score", 
                        value=f"⭐ {anime.get('score', 'N/A')}/10", 
                        inline=True
                    )
                    
                    embed.add_field(
                        name="Year", 
                        value=str(anime.get('year', 'Unknown')), 
                        inline=True
                    )
                    
                    embed.add_field(
                        name="Rating", 
                        value=anime.get('rating', 'Unknown'), 
                        inline=True
                    )
                    
                    # Add genres
                    if anime.get('genres'):
                        genres = [genre['name'] for genre in anime['genres']]
                        embed.add_field(
                            name="Genres", 
                            value=', '.join(genres[:5]) + ('...' if len(genres) > 5 else ''), 
                            inline=False
                        )
                    
                    # Add studios
                    if anime.get('studios'):
                        studios = [studio['name'] for studio in anime['studios']]
                        embed.add_field(
                            name="Studios", 
                            value=', '.join(studios), 
                            inline=False
                        )
                    
                    embed.add_field(name="Requested by", value=interaction.user.mention, inline=True)
                    
                    embed.set_footer(text='Made by JadaDev • Anime Command • Data from MyAnimeList', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
                    
                    await interaction.followup.send(embed=embed)
                    
        except aiohttp.ClientError:
            embed = discord.Embed(
                title="❌ Connection Error",
                description="Failed to connect to anime database. Please try again later.",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Anime Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            embed.set_footer(text='Made by JadaDev • Anime Command', icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s')
            await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AnimeCommand(bot))
    print('Loaded anime command')