import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import asyncio
import random

CONFIG_FILE = "welcome_voice.json"
FFMPEG_PATH = r"C:\\Users\\Administrator\\Desktop\\ffmpeg-master-latest-win64-gpl\\bin\\ffmpeg.exe"
DEFAULT_VOLUME = 0.3


class WelcomeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = self.load_config()
        self.last_played = {}  # guild_id: timestamp

    # ---------------- JSON Handling ----------------
    def load_config(self):
        if not os.path.exists(CONFIG_FILE):
            return {}
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = f.read().strip()
                if not data:
                    return {}
                return json.loads(data)
        except json.JSONDecodeError:
            print(f"[WARNING] {CONFIG_FILE} is invalid JSON. Recreating it.")
            return {}

    def save_config(self):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=4)

    # ---------------- Slash Command Setup ----------------
    @app_commands.command(
        name="welcomesetup",
        description="Setup a welcome voice message for a voice channel"
    )
    @app_commands.describe(
        channel="The voice channel to play the welcome message in",
        enabled="Enable or disable welcome audio for this channel",
        volume="Playback volume (0.1 to 2.0, default 0.7)"
    )
    async def welcomesetup_command(
        self,
        interaction: discord.Interaction,
        channel: discord.VoiceChannel,
        enabled: bool = True,
        volume: float = DEFAULT_VOLUME
    ):
        channel_id = str(channel.id)

        # Clamp volume
        volume = max(0.1, min(volume, 2.0))

        # Ensure the config exists for this channel
        if channel_id not in self.config:
            self.config[channel_id] = {"urls": [], "enabled": enabled, "volume": volume}
        else:
            self.config[channel_id]["enabled"] = enabled
            self.config[channel_id]["volume"] = volume

        self.save_config()

        status = "✅ Enabled" if enabled else "⏸ Disabled"
        await interaction.response.send_message(
            f"{status} welcome audio in <#{channel_id}>\n"
            f"🔊 Volume: `{volume}`\n"
            f"🎵 Current URLs: {len(self.config[channel_id]['urls'])}",
            ephemeral=True
        )

    # ---------------- Subcommand to add MP3 URLs ----------------
    @app_commands.command(
        name="addsong",
        description="Add an MP3 URL to the welcome audio list for a channel"
    )
    @app_commands.describe(
        channel="The voice channel to add the MP3 to",
        url="The MP3 URL to add"
    )
    async def addsong_command(
        self,
        interaction: discord.Interaction,
        channel: discord.VoiceChannel,
        url: str
    ):
        channel_id = str(channel.id)

        if channel_id not in self.config:
            self.config[channel_id] = {"urls": [], "enabled": True, "volume": DEFAULT_VOLUME}

        self.config[channel_id]["urls"].append(url)
        self.save_config()

        await interaction.response.send_message(
            f"🎵 Added MP3 URL to <#{channel_id}>: `{url}`\n"
            f"Total URLs: {len(self.config[channel_id]['urls'])}",
            ephemeral=True
        )

    # ---------------- Subcommand to list MP3 URLs ----------------
    @app_commands.command(
        name="listsongs",
        description="List all MP3 URLs for a channel"
    )
    @app_commands.describe(
        channel="The voice channel to list the MP3s of"
    )
    async def listsongs_command(
        self,
        interaction: discord.Interaction,
        channel: discord.VoiceChannel
    ):
        channel_id = str(channel.id)

        if channel_id not in self.config or not self.config[channel_id].get("urls"):
            await interaction.response.send_message(
                f"❌ No MP3 URLs found for <#{channel_id}>.",
                ephemeral=True
            )
            return

        urls = self.config[channel_id]["urls"]
        msg = "\n".join(f"{i+1}. {url}" for i, url in enumerate(urls))
        await interaction.response.send_message(
            f"🎵 MP3 URLs for <#{channel_id}>:\n{msg}",
            ephemeral=True
        )

    # ---------------- Subcommand to remove MP3 URLs ----------------
    @app_commands.command(
        name="removesong",
        description="Remove an MP3 URL from a channel by its number"
    )
    @app_commands.describe(
        channel="The voice channel to remove the MP3 from",
        index="The number of the MP3 URL to remove (see /listsongs)"
    )
    async def removesong_command(
        self,
        interaction: discord.Interaction,
        channel: discord.VoiceChannel,
        index: int
    ):
        channel_id = str(channel.id)

        if channel_id not in self.config or not self.config[channel_id].get("urls"):
            await interaction.response.send_message(
                f"❌ No MP3 URLs found for <#{channel_id}>.",
                ephemeral=True
            )
            return

        urls = self.config[channel_id]["urls"]

        if index < 1 or index > len(urls):
            await interaction.response.send_message(
                f"❌ Invalid index. Please use a number between 1 and {len(urls)}.",
                ephemeral=True
            )
            return

        removed = urls.pop(index - 1)
        self.save_config()

        await interaction.response.send_message(
            f"🗑 Removed MP3 URL from <#{channel_id}>: `{removed}`\n"
            f"Remaining URLs: {len(urls)}",
            ephemeral=True
        )

    # ---------------- Voice Playback ----------------
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.bot:
            return

        if after.channel and (before.channel != after.channel):
            channel_id = str(after.channel.id)
            if channel_id not in self.config:
                return

            config = self.config[channel_id]
            if not config.get("enabled", True):
                return

            voice_channel = after.channel

            # Prevent overlapping playback (10s cooldown per guild)
            now = asyncio.get_event_loop().time()
            if self.last_played.get(member.guild.id, 0) + 10 > now:
                return
            self.last_played[member.guild.id] = now

            urls = config.get("urls", [])
            if not urls:
                return  # No URLs to play

            # Randomly pick one
            url = random.choice(urls)
            volume = config.get("volume", DEFAULT_VOLUME)

            try:
                # Connect or move VC
                vc = discord.utils.get(self.bot.voice_clients, guild=member.guild)
                if vc:
                    if vc.channel.id != voice_channel.id:
                        await vc.move_to(voice_channel)
                else:
                    vc = await voice_channel.connect(timeout=15.0, reconnect=True)

                # Wait until connected
                for _ in range(5):
                    if vc.is_connected():
                        break
                    await asyncio.sleep(0.5)
                else:
                    print(f"[WARNING] Voice client failed to connect in time for channel {channel_id}.")
                    return

                source = discord.FFmpegPCMAudio(
                    url,
                    executable=FFMPEG_PATH,
                    before_options="-nostdin -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
                    options="-vn -loglevel panic"
                )
                vc.play(discord.PCMVolumeTransformer(source, volume=volume))

                while vc.is_playing():
                    await asyncio.sleep(0.5)

                if vc.is_connected():
                    await vc.disconnect()

            except Exception as e:
                print(f"[ERROR] Voice playback failed: {e}")


# ---------------- Setup Cog ----------------
async def setup(bot):
    await bot.add_cog(WelcomeCommand(bot))
    print("Loaded welcomesetup command with song list management")
