import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional
import random

class DiceCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="dice", description="Roll a dice with customizable sides")
    @app_commands.describe(sides="Number of sides on the dice (default: 6)", count="Number of dice to roll (default: 1)")
    async def dice_command(self, interaction: discord.Interaction, sides: Optional[int] = None, count: Optional[int] = None):
        """
        Roll dice with customizable options
        """
        try:
            # Set defaults
            sides = sides or 6
            count = count or 1

            # Validate parameters
            if sides < 1:
                await interaction.response.send_message("❌ Number of sides must be at least 1!", ephemeral=True)
                return

            if count < 1 or count > 10:
                await interaction.response.send_message("❌ You can roll between 1 and 10 dice!", ephemeral=True)
                return

            # Roll the dice
            rolls = [random.randint(1, sides) for _ in range(count)]
            total = sum(rolls)

            # Create embed
            embed = discord.Embed(
                title="🎲 Dice Roll",
                color=discord.Color.blue(),
                timestamp=interaction.created_at
            )

            if count == 1:
                embed.add_field(name="Result", value=f"**{rolls[0]}** (d{sides})", inline=True)
            else:
                embed.add_field(name="Rolls", value=", ".join(str(r) for r in rolls), inline=True)
                embed.add_field(name="Total", value=f"**{total}**", inline=True)

            embed.add_field(name="Dice Type", value=f"d{sides}", inline=True)

            # Dice faces for single roll
            dice_faces = {
                1: "⚀", 2: "⚁", 3: "⚂",
                4: "⚃", 5: "⚄", 6: "⚅"
            }

            if count == 1 and sides == 6 and rolls[0] <= 6:
                embed.add_field(name="", value=dice_faces[rolls[0]], inline=False)

            embed.set_footer(
                text=f"Made by JadaDev • Requested by {interaction.user.display_name}",
                icon_url='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1XQPGhU_ynqaqATWCC_nB0p1KocToJVP_Sw&s'
            )

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(DiceCommand(bot))
    print('Loaded dice command')
