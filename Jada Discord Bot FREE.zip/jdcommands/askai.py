import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import asyncio

class AskAICommand(commands.Cog):
    """Cog for asking a free AI any question (Pollinations)"""

    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="askai",
        description="Ask a free AI any question and get a response."
    )
    @app_commands.describe(prompt="The question or prompt to ask the AI")
    async def askai_command(self, interaction: discord.Interaction, prompt: str):
        """Ask a free AI using Pollinations API (no API key needed)"""
        await interaction.response.defer(thinking=True)  # prevents 3s timeout

        try:
            # Build the API URL
            url = "https://text.pollinations.ai/" + prompt.replace(" ", "%20")

            # Timeout context to prevent hanging
            timeout = aiohttp.ClientTimeout(total=15)  # 15 seconds max
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as resp:
                    if resp.status != 200:
                        return await interaction.followup.send(
                            f"❌ Failed to get a response from AI (HTTP {resp.status})",
                            ephemeral=True
                        )
                    answer = await resp.text()

            # Handle very long responses
            max_length = 1900  # Discord message safe limit
            if len(answer) > max_length:
                answer = answer[:max_length] + "\n\n...[truncated]"

            # Send the AI response
            await interaction.followup.send(
                content=f"**❓ You asked:** {prompt}\n\n**🤖 AI says:** {answer}"
            )

        except asyncio.TimeoutError:
            await interaction.followup.send(
                "❌ AI request timed out. Please try again later.",
                ephemeral=True
            )
        except aiohttp.ClientError as e:
            await interaction.followup.send(
                f"❌ Network error occurred: {str(e)}",
                ephemeral=True
            )
        except Exception as e:
            await interaction.followup.send(
                f"⚠️ Unexpected error: {str(e)}",
                ephemeral=True
            )


async def setup(bot):
    await bot.add_cog(AskAICommand(bot))
    print("Loaded askai command")
